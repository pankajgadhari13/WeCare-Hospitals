import React, { useState, useEffect } from 'react';
import { 
  Home, 
  Users, 
  Activity, 
  CalendarCheck, 
  UserCircle2, 
  PhoneCall, 
  HeartPulse, 
  AlertTriangle,
  LogIn
} from 'lucide-react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { EmergencyModal } from './components/EmergencyModal';
import { AppointmentSlipModal } from './components/AppointmentSlipModal';
import { AuthModal } from './components/AuthModal';
import { InstallAppModal } from './components/InstallAppModal';
import { InstallAppBanner } from './components/InstallAppBanner';
import { AIChatBot } from './components/AIChatBot';
import { LiveAvailabilityTracker } from './components/LiveAvailabilityTracker';

import { HomePage } from './pages/HomePage';
import { AboutPage } from './pages/AboutPage';
import { DepartmentsPage } from './pages/DepartmentsPage';
import { DoctorsPage } from './pages/DoctorsPage';
import { BookingPage } from './pages/BookingPage';
import { DashboardPage } from './pages/DashboardPage';
import { LoginPage } from './pages/LoginPage';
import { AdminPortalPage } from './pages/AdminPortalPage';

import { 
  DEPARTMENTS, 
  DOCTORS, 
  INITIAL_APPOINTMENTS, 
  INITIAL_MEDICAL_RECORDS, 
  INITIAL_PRESCRIPTIONS, 
  DEFAULT_PATIENT_PROFILE 
} from './data/hospitalData';
import { Doctor, Appointment, MedicalRecord, Prescription, PatientProfile } from './types';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import { subscribeToAppointments, cancelAppointmentInFirestore } from './services/appointmentService';

function AppContent() {
  const { currentUser, userProfile, isAdmin, authModalOpen, authModalReason, closeAuthModal, logout } = useAuth();

  // Navigation
  const [activeTab, setActiveTab] = useState<string>(() => {
    if (typeof window !== 'undefined' && window.location.hash) {
      const h = window.location.hash.replace('#', '').trim().toLowerCase();
      if (['about', 'departments', 'doctors', 'availability', 'booking', 'dashboard', 'admin', 'login', 'register'].includes(h)) {
        return h;
      }
    }
    return 'home';
  });
  const [underlyingTab, setUnderlyingTab] = useState<string>('home');
  const [selectedDeptFilter, setSelectedDeptFilter] = useState<string>('all');
  const [selectedDoctorForBooking, setSelectedDoctorForBooking] = useState<Doctor | null>(null);

  // Keep track of underlying page so login modal can float over it with backdrop blur
  useEffect(() => {
    if (activeTab !== 'login' && activeTab !== 'register') {
      setUnderlyingTab(activeTab);
    }
  }, [activeTab]);

  // Modals
  const [emergencyModalOpen, setEmergencyModalOpen] = useState<boolean>(false);
  const [activeSlipModal, setActiveSlipModal] = useState<Appointment | null>(null);
  const [installModalOpen, setInstallModalOpen] = useState<boolean>(false);

  // Session-isolated state: strictly empty when unauthenticated
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [patientProfile, setPatientProfile] = useState<PatientProfile | null>(null);

  // History and Back button security check
  useEffect(() => {
    const handlePopState = () => {
      const hash = window.location.hash.replace('#', '');
      // Requirement: Pressing the browser Back button must NOT allow access to the previous authenticated dashboard
      if ((hash === 'dashboard' || (!hash && activeTab === 'dashboard')) && !currentUser) {
        window.history.replaceState({ tab: 'login' }, '', '#login');
        setActiveTab('login');
      } else if (hash) {
        if (hash === 'dashboard' && !currentUser) {
          window.history.replaceState({ tab: 'login' }, '', '#login');
          setActiveTab('login');
        } else {
          setActiveTab(hash);
        }
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [currentUser, activeTab]);

  // Sync route hash when activeTab changes
  useEffect(() => {
    if (activeTab === 'dashboard') {
      if (!currentUser) {
        setActiveTab('login');
        window.history.replaceState({ tab: 'login' }, '', '#login');
      } else {
        window.history.pushState({ tab: 'dashboard' }, '', '#dashboard');
      }
    } else if (activeTab === 'login') {
      window.history.replaceState({ tab: 'login' }, '', '#login');
    } else if (activeTab === 'register') {
      window.history.replaceState({ tab: 'register' }, '', '#register');
    } else if (activeTab === 'admin' || activeTab === 'admin-portal') {
      window.history.replaceState({ tab: 'admin' }, '', '#admin');
    } else if (activeTab === 'home') {
      if (typeof window !== 'undefined' && window.location.hash) {
        window.history.replaceState({ tab: 'home' }, '', window.location.pathname + window.location.search);
      }
    }
  }, [activeTab, currentUser]);

  // User session lifecycle: strictly isolate data per user and clear on logout
  useEffect(() => {
    if (!currentUser) {
      setAppointments([]);
      setPatientProfile(null);
      if (activeTab === 'dashboard') {
        setActiveTab('login');
      }
      return;
    }

    // Logged in user: load their profile
    if (userProfile) {
      setPatientProfile(userProfile);
    }

    const isDemo =
      currentUser.email?.toLowerCase() === 'patient@wecare.hospital' ||
      currentUser.email?.toLowerCase() === 'demo@wecare.hospital';

    // Subscribe to ONLY this user's appointments from Firestore
    const unsubscribe = subscribeToAppointments(currentUser.uid, (firestoreApts) => {
      if (firestoreApts && firestoreApts.length > 0) {
        setAppointments(firestoreApts);
      } else if (isDemo) {
        // Fallback for demo user
        setAppointments(INITIAL_APPOINTMENTS);
      } else {
        // New patient starts with clean zero appointments
        setAppointments([]);
      }
    });

    return () => unsubscribe();
  }, [currentUser, userProfile]);

  // Handle Logout
  const handleLogout = async () => {
    await logout();
    setAppointments([]);
    setPatientProfile(null);
    try {
      localStorage.removeItem('wecare_appointments');
      localStorage.removeItem('wecare_patient_profile');
      localStorage.removeItem('wecare_medical_records');
      localStorage.removeItem('wecare_prescriptions');
      localStorage.removeItem('wecare_auth_token');
      sessionStorage.clear();
    } catch {}
    setActiveTab('login');
    window.history.replaceState({ tab: 'login' }, '', '#login');
  };

  // Scoped medical records & prescriptions per user
  const userMedicalRecords: MedicalRecord[] = currentUser
    ? currentUser.email?.toLowerCase() === 'patient@wecare.hospital'
      ? INITIAL_MEDICAL_RECORDS
      : []
    : [];

  const userPrescriptions: Prescription[] = currentUser
    ? currentUser.email?.toLowerCase() === 'patient@wecare.hospital'
      ? INITIAL_PRESCRIPTIONS
      : []
    : [];

  // Navigation handlers
  const handleSelectDepartment = (deptId: string) => {
    setSelectedDeptFilter(deptId);
    setActiveTab('doctors');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectDoctorForBooking = (doctor: Doctor) => {
    setSelectedDoctorForBooking({ ...doctor });
    setActiveTab('booking');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAppointmentBooked = (newApt: Appointment) => {
    setAppointments((prev) => [newApt, ...prev.filter((a) => a.id !== newApt.id)]);
  };

  const handleCancelAppointment = async (appointmentId: string) => {
    setAppointments((prev) =>
      prev.map((apt) =>
        apt.id === appointmentId ? { ...apt, status: 'cancelled' } : apt
      )
    );
    try {
      await cancelAppointmentInFirestore(appointmentId);
    } catch (err) {
      console.warn('Could not cancel in Firestore:', err);
    }
  };

  const handleUpdateVitals = (newVitals: PatientProfile['vitals']) => {
    setPatientProfile((prev) => (prev ? { ...prev, vitals: newVitals } : null));
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-black text-slate-900 dark:text-slate-100 selection:bg-teal-500 selection:text-white transition-colors duration-200">
      {/* Universal Navigation Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        openEmergencyModal={() => setEmergencyModalOpen(true)}
        openInstallModal={() => setInstallModalOpen(true)}
        appointmentsCount={appointments.filter((a) => a.status === 'confirmed' || a.status === 'pending' || a.status === 'rescheduled').length}
        onLogout={handleLogout}
      />

      {/* Main Content Router */}
      <main className="flex-1 pb-20 lg:pb-0 overflow-x-hidden">
        {(() => {
          const isAuthModalTab = activeTab === 'login' || activeTab === 'register';
          const backgroundTab = isAuthModalTab
            ? (underlyingTab === 'login' || underlyingTab === 'register' ? 'home' : underlyingTab)
            : activeTab;

          return (
            <>
              {backgroundTab === 'home' && (
                <HomePage
                  departments={DEPARTMENTS}
                  doctors={DOCTORS}
                  onSelectDepartment={handleSelectDepartment}
                  onSelectDoctorForBooking={handleSelectDoctorForBooking}
                  onBookDoctor={handleSelectDoctorForBooking}
                  openEmergencyModal={() => setEmergencyModalOpen(true)}
                  setActiveTab={setActiveTab}
                />
              )}

              {backgroundTab === 'about' && (
                <AboutPage setActiveTab={setActiveTab} />
              )}

              {backgroundTab === 'departments' && (
                <DepartmentsPage
                  departments={DEPARTMENTS}
                  doctors={DOCTORS}
                  onSelectDepartmentForBooking={(deptId) => {
                    setSelectedDeptFilter(deptId);
                    setActiveTab('booking');
                  }}
                  onSelectDoctorForBooking={handleSelectDoctorForBooking}
                />
              )}

              {backgroundTab === 'doctors' && (
                <DoctorsPage
                  doctors={DOCTORS}
                  departments={DEPARTMENTS}
                  selectedDepartmentId={selectedDeptFilter}
                  onSelectDepartmentFilter={setSelectedDeptFilter}
                  onSelectDoctorForBooking={handleSelectDoctorForBooking}
                />
              )}

              {backgroundTab === 'availability' && (
                <div className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16 py-8">
                  <LiveAvailabilityTracker
                    doctors={DOCTORS}
                    departments={DEPARTMENTS}
                    onSelectDoctorForBooking={handleSelectDoctorForBooking}
                  />
                </div>
              )}

              {backgroundTab === 'booking' && (
                <BookingPage
                  departments={DEPARTMENTS}
                  doctors={DOCTORS}
                  selectedDoctor={selectedDoctorForBooking}
                  onAppointmentBooked={handleAppointmentBooked}
                  onOpenAppointmentPass={(apt) => setActiveSlipModal(apt)}
                  setActiveTab={setActiveTab}
                />
              )}

              {/* PROTECTED PATIENT DASHBOARD */}
              {backgroundTab === 'dashboard' && currentUser && patientProfile && (
                <DashboardPage
                  appointments={appointments}
                  medicalRecords={userMedicalRecords}
                  prescriptions={userPrescriptions}
                  patientProfile={patientProfile}
                  onCancelAppointment={handleCancelAppointment}
                  onOpenAppointmentPass={(apt) => setActiveSlipModal(apt)}
                  onUpdateVitals={handleUpdateVitals}
                  setActiveTab={setActiveTab}
                  onLogout={handleLogout}
                />
              )}

              {/* ADMIN PORTAL ROUTE (Strictly Admin-Only) */}
              {(backgroundTab === 'admin' || backgroundTab === 'admin-portal') && (
                isAdmin || !currentUser ? (
                  <AdminPortalPage
                    doctors={DOCTORS}
                    departments={DEPARTMENTS}
                    onOpenAppointmentPass={(apt) => setActiveSlipModal(apt)}
                    setActiveTab={setActiveTab}
                  />
                ) : (
                  <div className="min-h-[70vh] flex items-center justify-center px-4 py-16">
                    <div className="max-w-md w-full text-center space-y-4 bg-white dark:bg-black p-8 rounded-2xl border border-slate-200 dark:border-neutral-800 shadow-xl">
                      <div className="w-14 h-14 bg-rose-500/10 text-rose-500 rounded-2xl flex items-center justify-center mx-auto border border-rose-500/20">
                        <AlertTriangle className="w-7 h-7" />
                      </div>
                      <h2 className="text-xl font-bold text-slate-900 dark:text-white">Admin Privileges Required</h2>
                      <p className="text-xs text-slate-600 dark:text-slate-400">
                        The Central Hospital Console is restricted exclusively to authorized medical administrators. Normal patient accounts do not have access.
                      </p>
                      <button
                        onClick={() => {
                          setActiveTab('home');
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                        className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl transition cursor-pointer"
                      >
                        Return to Homepage
                      </button>
                    </div>
                  </div>
                )
              )}

              {/* FLOATING AESTHETIC LOGIN & REGISTRATION MODAL POPUP */}
              {isAuthModalTab && (
                <LoginPage
                  key={`login-view-${currentUser ? currentUser.uid : 'logged-out'}`}
                  initialTab={activeTab === 'register' ? 'register' : 'login'}
                  onLoginSuccess={() => {
                    setActiveTab('dashboard');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  setActiveTab={setActiveTab}
                />
              )}
            </>
          );
        })()}
      </main>

      {/* Footer */}
      <Footer
        setActiveTab={setActiveTab}
        openEmergencyModal={() => setEmergencyModalOpen(true)}
        openInstallModal={() => setInstallModalOpen(true)}
      />

      {/* Mobile App Install Floating Banner */}
      <InstallAppBanner onOpenModal={() => setInstallModalOpen(true)} />

      {/* Mobile Bottom Quick Navigation Bar */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 px-3 py-2 flex items-center justify-around shadow-lg transition-colors duration-200">
        <button
          onClick={() => {
            setActiveTab('home');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center py-1 px-2 text-[10px] font-bold cursor-pointer transition ${
            activeTab === 'home' ? 'text-teal-600 dark:text-teal-400' : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Home className="w-5 h-5 mb-0.5" />
          <span>Home</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('doctors');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center py-1 px-2 text-[10px] font-bold cursor-pointer transition ${
            activeTab === 'doctors' ? 'text-teal-600 dark:text-teal-400' : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Users className="w-5 h-5 mb-0.5" />
          <span>Doctors</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('availability');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center py-1 px-2 text-[10px] font-bold cursor-pointer transition ${
            activeTab === 'availability' ? 'text-teal-600 dark:text-teal-400' : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Activity className="w-5 h-5 mb-0.5 text-emerald-500 animate-pulse" />
          <span>Slots</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('booking');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center py-1 px-2 text-[10px] font-bold cursor-pointer transition ${
            activeTab === 'booking' ? 'text-teal-600 dark:text-teal-400' : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <CalendarCheck className="w-5 h-5 mb-0.5" />
          <span>Book</span>
        </button>

        <button
          onClick={() => {
            if (!currentUser) {
              setActiveTab('login');
            } else {
              setActiveTab('dashboard');
            }
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center py-1 px-2 text-[10px] font-bold cursor-pointer transition relative ${
            activeTab === 'dashboard' || activeTab === 'login' ? 'text-teal-600 dark:text-teal-400' : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          {currentUser ? (
            <>
              <UserCircle2 className="w-5 h-5 mb-0.5" />
              <span>Portal</span>
              {appointments.filter(a => a.status === 'confirmed').length > 0 && (
                <span className="absolute top-0 right-1 w-2 h-2 rounded-full bg-teal-500" />
              )}
            </>
          ) : (
            <>
              <LogIn className="w-5 h-5 mb-0.5" />
              <span>Login</span>
            </>
          )}
        </button>
      </div>

      {/* Modals */}
      <EmergencyModal
        isOpen={emergencyModalOpen}
        onClose={() => setEmergencyModalOpen(false)}
      />

      <AppointmentSlipModal
        appointment={activeSlipModal}
        onClose={() => setActiveSlipModal(null)}
      />

      <AuthModal
        isOpen={authModalOpen}
        onClose={closeAuthModal}
        reason={authModalReason}
      />

      <InstallAppModal
        isOpen={installModalOpen}
        onClose={() => setInstallModalOpen(false)}
      />

      {/* AI Healthcare Assistant Chatbot */}
      <AIChatBot
        setActiveTab={setActiveTab}
        openEmergencyModal={() => setEmergencyModalOpen(true)}
        openInstallModal={() => setInstallModalOpen(true)}
      />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ThemeProvider>
  );
}
