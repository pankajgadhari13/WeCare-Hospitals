import React, { useState, useEffect, useRef } from 'react';
import { 
  Send, 
  X, 
  Sparkles, 
  Bot, 
  CalendarCheck, 
  Users, 
  PhoneCall, 
  Download, 
  Minimize2, 
  Maximize2,
  RefreshCw,
  MapPin,
  ChevronRight
} from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  suggestedActions?: string[];
}

interface AIChatBotProps {
  setActiveTab: (tab: string) => void;
  openEmergencyModal: () => void;
  openInstallModal: () => void;
}

const DEFAULT_WELCOME_MESSAGE: ChatMessage = {
  id: 'welcome-1',
  sender: 'assistant',
  text: `Namaste! 🙏 Main **WeCare Hospital** ka AI Assistant hoon.\n\nAap mujhse hospital, doctors, appointment booking ke steps, ya apni health se juda koi bhi sawal pooch sakte hain. Main ek-ek karke aapki poori madad karunga!`,
  timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
  suggestedActions: [
    'Appointment kaise book karein?',
    'Doctors List & Fees',
    'Hospital Timings & Address',
    'Download Mobile App'
  ]
};

export const AIChatBot: React.FC<AIChatBotProps> = ({
  setActiveTab,
  openEmergencyModal,
  openInstallModal,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([DEFAULT_WELCOME_MESSAGE]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to latest message
  useEffect(() => {
    if (isOpen && !isMinimized) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, isMinimized, isLoading]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputText).trim();
    if (!query || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history: messages.slice(-4).map((m) => ({
            role: m.sender,
            text: m.text,
          })),
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();
      const botMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        sender: 'assistant',
        text: data.reply || 'Main aapki baat samajh gaya. Kya aapko kisi specific cheez me madad chahiye?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedActions: data.suggestedActions || ['Appointment kaise book karein?', 'Doctors List & Fees'],
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      console.warn('Chat fetch fallback error:', err);
      const botMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        sender: 'assistant',
        text: `🏥 **WeCare Hospital:**\n\nAap website par "Book Appointment" button dabakar doctor aur slot chun sakte hain. Kisi bhi emergency me turant **108** par call karein!\n\nAddress: Akhatwade, near Nagardeola, Dist Jalgaon 425001.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedActions: ['Appointment kaise book karein?', 'Doctors List & Fees'],
      };
      setMessages((prev) => [...prev, botMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleActionClick = (action: string) => {
    handleSendMessage(action);
  };

  const clearChat = () => {
    setMessages([DEFAULT_WELCOME_MESSAGE]);
  };

  return (
    <>
      {/* Floating Launcher Button */}
      {!isOpen && (
        <button
          type="button"
          id="wecare-ai-chat-btn"
          onClick={() => {
            setIsOpen(true);
            setIsMinimized(false);
          }}
          aria-label="Open WeCare Hospital AI Assistant"
          className="fixed bottom-16 lg:bottom-6 right-3 sm:right-6 z-40 p-2 sm:px-3.5 sm:py-2.5 rounded-full bg-gradient-to-r from-teal-700 via-teal-600 to-emerald-600 text-white shadow-xl hover:shadow-teal-600/30 transition-all duration-300 hover:scale-105 active:scale-95 flex items-center gap-2 cursor-pointer border border-teal-400/40 group backdrop-blur-xs"
        >
          <div className="relative">
            <Bot className="w-5 h-5 text-white group-hover:rotate-12 transition-transform" />
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400 border border-white animate-pulse" />
          </div>
          <div className="hidden sm:block text-left">
            <div className="flex items-center gap-1 leading-none">
              <span className="text-xs font-bold tracking-tight">WeCare AI</span>
              <Sparkles className="w-3 h-3 text-amber-300" />
            </div>
            <span className="text-[10px] text-teal-100 font-medium block mt-0.5">Need Help? Ask AI</span>
          </div>
        </button>
      )}

      {/* Mobile Backdrop Overlay */}
      {isOpen && (
        <div 
          onClick={() => setIsOpen(false)}
          className="sm:hidden fixed inset-0 z-40 bg-slate-950/40 backdrop-blur-[2px] animate-in fade-in duration-150"
        />
      )}

      {/* Chat Window - Compact Mobile Sheet & Desktop Card */}
      {isOpen && (
        <div 
          className={`fixed z-50 transition-all duration-200 ${
            isMinimized 
              ? 'bottom-16 lg:bottom-6 right-3 sm:right-6 w-60' 
              : 'inset-x-0 bottom-0 sm:bottom-6 sm:right-6 sm:inset-x-auto sm:w-[380px] sm:max-w-[400px] h-[72vh] max-h-[500px] sm:h-[510px]'
          } bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-2xl shadow-2xl border-t sm:border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden text-slate-900 dark:text-white animate-in slide-in-from-bottom-2 duration-200`}
        >
          {/* Mobile Sheet Drag Indicator */}
          <div className="sm:hidden flex justify-center pt-2 pb-0.5 bg-slate-900">
            <div className="w-10 h-1 bg-slate-500/50 rounded-full" />
          </div>

          {/* Header Bar */}
          <div className="px-3 py-2 sm:px-3.5 sm:py-2.5 bg-gradient-to-r from-teal-900 via-slate-900 to-slate-950 text-white flex items-center justify-between shrink-0 shadow-xs">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-teal-500/20 border border-teal-400/30 flex items-center justify-center text-teal-300 shadow-inner">
                <Bot className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h4 className="text-xs font-bold text-white leading-tight">WeCare AI Assistant</h4>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                </div>
                <p className="text-[9px] text-teal-200/80">
                  Speaks Hindi, Marathi & English
                </p>
              </div>
            </div>

            <div className="flex items-center gap-0.5 text-slate-300">
              <button
                type="button"
                onClick={clearChat}
                title="Clear Conversation"
                className="p-1 hover:text-white hover:bg-white/10 rounded-md transition cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setIsMinimized(!isMinimized)}
                title={isMinimized ? 'Expand Chat' : 'Minimize'}
                className="hidden sm:block p-1 hover:text-white hover:bg-white/10 rounded-md transition cursor-pointer"
              >
                {isMinimized ? <Maximize2 className="w-3.5 h-3.5" /> : <Minimize2 className="w-3.5 h-3.5" />}
              </button>
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                title="Close Chat"
                className="p-1 hover:text-white hover:bg-white/10 rounded-md transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Body when not minimized */}
          {!isMinimized && (
            <>
              {/* Messages Container - Compact Chatting Sizes */}
              <div className="flex-1 p-2.5 sm:p-3 overflow-y-auto space-y-2 bg-slate-50/70 dark:bg-slate-950/40 text-[11.5px] sm:text-xs min-h-[160px]">
                {messages.map((msg) => {
                  const isUser = msg.sender === 'user';
                  const isBookingRelated = !isUser && (msg.text.toLowerCase().includes('step 1') || msg.text.toLowerCase().includes('appointment book'));
                  
                  return (
                    <div 
                      key={msg.id}
                      className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} space-y-0.5 animate-in fade-in duration-150`}
                    >
                      <div className="flex items-end gap-1.5 max-w-[90%] sm:max-w-[85%]">
                        {!isUser && (
                          <div className="w-4 h-4 rounded-md bg-teal-600 text-white flex items-center justify-center shrink-0 mb-0.5">
                            <Bot className="w-2.5 h-2.5" />
                          </div>
                        )}
                        <div 
                          className={`px-3 py-1.5 sm:px-3 sm:py-2 rounded-xl leading-relaxed whitespace-pre-wrap text-[11px] sm:text-xs ${
                            isUser 
                              ? 'bg-teal-600 text-white rounded-br-none shadow-xs' 
                              : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-bl-none border border-slate-200 dark:border-slate-700 shadow-2xs'
                          }`}
                        >
                          {msg.text}

                          {/* Optional inline jump button for booking if user wants to open the form */}
                          {isBookingRelated && (
                            <div className="mt-2 pt-1.5 border-t border-slate-200 dark:border-slate-700/80 flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => {
                                  setActiveTab('booking');
                                  setIsOpen(false);
                                  window.scrollTo({ top: 0, behavior: 'smooth' });
                                }}
                                className="px-2 py-0.5 bg-teal-600 hover:bg-teal-700 text-white text-[9.5px] font-bold rounded-md flex items-center gap-1 cursor-pointer transition active:scale-95"
                              >
                                <span>Open Booking Form</span>
                                <ChevronRight className="w-2.5 h-2.5" />
                              </button>
                            </div>
                          )}
                        </div>
                      </div>

                      <span className="text-[8.5px] text-slate-400 px-1">
                        {msg.timestamp}
                      </span>

                      {/* Suggested Action Chips if available */}
                      {!isUser && msg.suggestedActions && msg.suggestedActions.length > 0 && (
                        <div className="flex flex-wrap gap-1 pt-0.5 pl-5 max-w-full">
                          {msg.suggestedActions.map((act, i) => (
                            <button
                              key={i}
                              type="button"
                              onClick={() => handleActionClick(act)}
                              className="px-2 py-0.5 bg-white dark:bg-slate-800 hover:bg-teal-50 dark:hover:bg-slate-700 text-teal-800 dark:text-teal-300 text-[9.5px] font-medium rounded-md border border-slate-200 dark:border-slate-700 transition shadow-2xs hover:border-teal-400 cursor-pointer flex items-center gap-1 active:scale-95"
                            >
                              <span>{act}</span>
                              <ChevronRight className="w-2.5 h-2.5 text-teal-500" />
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}

                {/* Loading indicator */}
                {isLoading && (
                  <div className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400 pl-1">
                    <div className="w-4 h-4 rounded-md bg-teal-600 text-white flex items-center justify-center shrink-0">
                      <Bot className="w-2.5 h-2.5 animate-spin" />
                    </div>
                    <div className="bg-white dark:bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center gap-1.5 shadow-2xs">
                      <span className="w-1.5 h-1.5 rounded-full bg-teal-500 animate-bounce" />
                      <span className="w-1.5 h-1.5 rounded-full bg-teal-500 animate-bounce [animation-delay:0.2s]" />
                      <span className="w-1.5 h-1.5 rounded-full bg-teal-500 animate-bounce [animation-delay:0.4s]" />
                      <span className="text-[9.5px] font-medium ml-1">Answering...</span>
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>

              {/* Fast Action Quick Ribbon */}
              <div className="px-2 py-1 bg-slate-100 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800 flex items-center gap-1 overflow-x-auto scrollbar-none text-[9.5px] shrink-0">
                <button
                  type="button"
                  onClick={() => handleActionClick('Appointment kaise book karein?')}
                  className="px-2 py-0.5 bg-white dark:bg-slate-700 rounded-md text-slate-700 dark:text-slate-200 whitespace-nowrap hover:text-teal-600 border border-slate-200 dark:border-slate-600 cursor-pointer flex items-center gap-1 active:scale-95"
                >
                  <CalendarCheck className="w-2.5 h-2.5 text-teal-600" />
                  <span>Book Steps</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleActionClick('Doctors List & Fees')}
                  className="px-2 py-0.5 bg-white dark:bg-slate-700 rounded-md text-slate-700 dark:text-slate-200 whitespace-nowrap hover:text-teal-600 border border-slate-200 dark:border-slate-600 cursor-pointer flex items-center gap-1 active:scale-95"
                >
                  <Users className="w-2.5 h-2.5 text-teal-600" />
                  <span>Doctors & Fees</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleActionClick('Hospital Timings & Address')}
                  className="px-2 py-0.5 bg-white dark:bg-slate-700 rounded-md text-slate-700 dark:text-slate-200 whitespace-nowrap hover:text-teal-600 border border-slate-200 dark:border-slate-600 cursor-pointer flex items-center gap-1 active:scale-95"
                >
                  <MapPin className="w-2.5 h-2.5 text-teal-600" />
                  <span>Location</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleActionClick('Emergency 108 SOS')}
                  className="px-2 py-0.5 bg-rose-50 dark:bg-rose-950/60 rounded-md text-rose-700 dark:text-rose-300 whitespace-nowrap hover:bg-rose-100 border border-rose-200 dark:border-rose-900/60 cursor-pointer flex items-center gap-1 active:scale-95"
                >
                  <PhoneCall className="w-2.5 h-2.5 text-rose-600" />
                  <span>108 SOS</span>
                </button>
              </div>

              {/* Chat Input Field */}
              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSendMessage();
                }}
                className="p-1.5 sm:p-2 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center gap-1.5 shrink-0"
              >
                <input
                  type="text"
                  placeholder="Kuch bhi poochiye (e.g. Appointment booking)..."
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  disabled={isLoading}
                  className="flex-1 px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-teal-500"
                />
                <button
                  type="submit"
                  disabled={!inputText.trim() || isLoading}
                  className="p-1.5 bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white rounded-lg transition cursor-pointer shadow-xs active:scale-95 shrink-0"
                  aria-label="Send message"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </>
          )}
        </div>
      )}
    </>
  );
};
