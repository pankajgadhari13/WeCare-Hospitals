import React from 'react';
import { 
  X, 
  Printer, 
  Calendar, 
  Clock, 
  MapPin, 
  User, 
  CheckCircle, 
  ShieldCheck, 
  Download,
  AlertCircle,
  Share2
} from 'lucide-react';
import { Appointment } from '../types';

interface AppointmentSlipModalProps {
  appointment: Appointment | null;
  onClose: () => void;
}

export const AppointmentSlipModal: React.FC<AppointmentSlipModalProps> = ({
  appointment,
  onClose,
}) => {
  if (!appointment) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 dark:bg-black/90 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="relative w-full max-w-xl bg-white dark:bg-black rounded-2xl shadow-2xl border border-slate-200 dark:border-neutral-800 overflow-hidden print:p-0 print:border-none print:shadow-none text-slate-900 dark:text-white">
        {/* Modal Action Bar (Hidden on print) */}
        <div className="bg-slate-900 dark:bg-neutral-950 text-white px-6 py-3 flex items-center justify-between print:hidden border-b border-slate-800 dark:border-neutral-800">
          <span className="text-xs font-semibold tracking-wider uppercase text-teal-400">
            Digital Outpatient Booking Pass
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1 bg-slate-800 dark:bg-neutral-900 hover:bg-slate-700 dark:hover:bg-neutral-800 text-xs font-medium rounded-lg text-slate-200 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Slip</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 text-slate-400 hover:text-white rounded-lg transition cursor-pointer"
              aria-label="Close appointment modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Ticket Content */}
        <div className="p-6 sm:p-8 space-y-6 bg-white dark:bg-black">
          {/* Header */}
          <div className="flex items-start justify-between border-b border-slate-100 dark:border-neutral-900 pb-5">
            <div>
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-teal-600 text-white flex items-center justify-center font-black text-sm">
                  W
                </div>
                <span className="text-xl font-bold text-slate-900 dark:text-white">
                  WeCare <span className="text-teal-600 dark:text-teal-400 font-normal">Hospitals</span>
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-neutral-400 mt-1">
                Akhatwade near by nagardeola dist jalgaon 425001 • Emergency: 108
              </p>
            </div>
            <div className="text-right">
              <div className="inline-block px-3 py-1 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 rounded-full text-xs font-bold uppercase tracking-wider">
                {appointment.status}
              </div>
              <p className="text-xs text-slate-400 dark:text-neutral-500 mt-1">Ref: <strong>{appointment.bookingRef}</strong></p>
            </div>
          </div>

          {/* Key Appointment Badge */}
          <div className="bg-slate-50 dark:bg-neutral-950 rounded-xl p-4 border border-slate-200 dark:border-neutral-800 grid grid-cols-2 sm:grid-cols-3 gap-4">
            <div>
              <span className="text-[11px] font-medium text-slate-400 dark:text-neutral-500 uppercase tracking-wider block">Date</span>
              <span className="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-1 mt-0.5">
                <Calendar className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                {appointment.date}
              </span>
            </div>
            <div>
              <span className="text-[11px] font-medium text-slate-400 dark:text-neutral-500 uppercase tracking-wider block">Slot Time</span>
              <span className="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-1 mt-0.5">
                <Clock className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                {appointment.timeSlot}
              </span>
            </div>
            <div className="col-span-2 sm:col-span-1">
              <span className="text-[11px] font-medium text-slate-400 dark:text-neutral-500 uppercase tracking-wider block">OPD Location</span>
              <span className="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-1 mt-0.5">
                <MapPin className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                {appointment.opdRoom}
              </span>
            </div>
          </div>

          {/* Doctor & Patient Split */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
            <div className="space-y-2 border border-slate-100 dark:border-neutral-800 rounded-xl p-4 bg-teal-50/30 dark:bg-neutral-950">
              <span className="text-xs font-semibold text-teal-800 dark:text-teal-300 uppercase tracking-wider block">
                Consulting Specialist
              </span>
              <div className="flex items-center gap-3">
                <img
                  src={appointment.doctorPhoto}
                  alt={appointment.doctorName}
                  className="w-12 h-12 rounded-full object-cover border-2 border-white dark:border-neutral-700 shadow-xs"
                />
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">{appointment.doctorName}</h4>
                  <p className="text-xs text-slate-600 dark:text-neutral-400">{appointment.doctorTitle}</p>
                  <p className="text-xs text-teal-700 dark:text-teal-400 font-medium">{appointment.departmentName}</p>
                </div>
              </div>
            </div>

            <div className="space-y-2 border border-slate-100 dark:border-neutral-800 rounded-xl p-4 dark:bg-neutral-950">
              <span className="text-xs font-semibold text-slate-500 dark:text-neutral-400 uppercase tracking-wider block">
                Patient Information
              </span>
              <div className="text-xs space-y-1 text-slate-700 dark:text-neutral-300">
                <p className="font-bold text-sm text-slate-900 dark:text-white">{appointment.patientName}</p>
                <p>Age / Gender: {appointment.patientAge} yrs • {appointment.patientGender.toUpperCase()}</p>
                <p>Phone: {appointment.patientPhone}</p>
                <p>Email: {appointment.patientEmail}</p>
              </div>
            </div>
          </div>

          {/* Reason & Payment */}
          <div className="bg-slate-50/60 dark:bg-neutral-950 rounded-xl p-4 border border-slate-100 dark:border-neutral-800 text-xs space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-500 dark:text-neutral-400">Visit Purpose / Symptoms:</span>
              <span className="font-semibold text-slate-800 dark:text-neutral-200 text-right">{appointment.reason || 'General Health Consultation'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500 dark:text-neutral-400">Mode of Consultation:</span>
              <span className="font-semibold capitalize text-slate-800 dark:text-neutral-200">{appointment.consultationType} Visit</span>
            </div>
            <div className="flex justify-between border-t border-slate-200 dark:border-neutral-800 pt-2 text-sm">
              <span className="font-semibold text-slate-700 dark:text-neutral-300">Consultation Fee:</span>
              <span className="font-bold text-teal-700 dark:text-teal-400">₹{appointment.consultationFee} ({appointment.paymentMode === 'online-paid' ? 'Paid Online' : 'Pay at Counter'})</span>
            </div>
          </div>

          {/* Instructions Box */}
          <div className="flex items-start gap-2.5 text-xs text-slate-500 dark:text-neutral-400 bg-amber-50/70 dark:bg-neutral-950 p-3 rounded-lg border border-amber-200/60 dark:border-neutral-800">
            <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <p>
              Please arrive 15 minutes before your slot time for basic vitals check at the OPD triage desk. Carry prior medical prescriptions, lab reports, and a valid photo ID.
            </p>
          </div>

          {/* Barcode Mock */}
          <div className="pt-2 text-center border-t border-dashed border-slate-200 dark:border-neutral-800">
            <div className="inline-flex flex-col items-center">
              <div className="flex items-center gap-1 h-8 opacity-70">
                {Array.from({ length: 34 }).map((_, i) => (
                  <span
                    key={i}
                    className={`h-full bg-slate-900 dark:bg-white inline-block ${i % 3 === 0 ? 'w-1' : i % 5 === 0 ? 'w-1.5' : 'w-0.5'}`}
                  />
                ))}
              </div>
              <span className="text-[10px] text-slate-400 dark:text-neutral-500 tracking-widest mt-1 font-mono">
                {appointment.bookingRef}
              </span>
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="bg-slate-50 dark:bg-neutral-950 px-6 py-4 border-t border-slate-100 dark:border-neutral-900 flex items-center justify-between print:hidden">
          <span className="text-xs text-slate-400 dark:text-neutral-500">
            Saved to your local Patient Dashboard
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-lg cursor-pointer transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
