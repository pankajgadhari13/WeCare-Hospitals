import React, { useState } from 'react';
import { 
  CalendarCheck, 
  Clock, 
  CheckCircle2, 
  Activity, 
  TrendingUp, 
  PieChart as PieChartIcon, 
  BarChart3, 
  ArrowRight,
  ShieldCheck,
  CalendarDays
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  Tooltip, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid,
  Legend
} from 'recharts';
import { Appointment } from '../types';

interface AppointmentStatsSummaryProps {
  appointments: Appointment[];
  onBookNew?: () => void;
}

export const AppointmentStatsSummary: React.FC<AppointmentStatsSummaryProps> = ({
  appointments,
  onBookNew,
}) => {
  const [chartMode, setChartMode] = useState<'status' | 'department'>('status');

  // Core metrics
  const totalBooked = appointments.length;

  const upcomingAppointments = appointments.filter((apt) => 
    apt.status === 'confirmed' || apt.status === 'pending' || apt.status === 'rescheduled'
  );
  const upcomingCount = upcomingAppointments.length;

  const completedCount = appointments.filter((apt) => apt.status === 'completed').length;
  const cancelledCount = appointments.filter((apt) => apt.status === 'cancelled').length;
  const pendingCount = appointments.filter((apt) => apt.status === 'pending').length;
  const confirmedCount = appointments.filter((apt) => apt.status === 'confirmed').length;

  // Next upcoming visit
  const sortedUpcoming = [...upcomingAppointments].sort((a, b) => {
    const dateA = new Date(`${a.date || a.appointmentDate || ''} ${a.timeSlot || a.appointmentTime || ''}`).getTime();
    const dateB = new Date(`${b.date || b.appointmentDate || ''} ${b.timeSlot || b.appointmentTime || ''}`).getTime();
    return dateA - dateB;
  });
  const nextVisit = sortedUpcoming[0];

  // Status Distribution Data for Recharts
  const statusData = [
    { name: 'Confirmed', value: confirmedCount, color: '#0d9488' },
    { name: 'Pending Review', value: pendingCount, color: '#f59e0b' },
    { name: 'Completed', value: completedCount, color: '#10b981' },
    { name: 'Cancelled', value: cancelledCount, color: '#f43f5e' },
  ].filter(d => d.value > 0);

  // Fallback demo data if patient has no appointments yet so chart is never broken
  const displayStatusData = statusData.length > 0 ? statusData : [
    { name: 'Confirmed', value: 2, color: '#0d9488' },
    { name: 'Pending Review', value: 1, color: '#f59e0b' },
    { name: 'Completed', value: 1, color: '#10b981' },
  ];

  // Department Distribution Data
  const deptCountMap: Record<string, number> = {};
  appointments.forEach((apt) => {
    const dept = apt.departmentName || apt.department || 'General Medicine';
    const cleanDept = dept.split('&')[0].trim();
    deptCountMap[cleanDept] = (deptCountMap[cleanDept] || 0) + 1;
  });

  const departmentData = Object.entries(deptCountMap).map(([dept, count]) => ({
    name: dept,
    appointments: count,
  }));

  const displayDeptData = departmentData.length > 0 ? departmentData : [
    { name: 'Cardiology', appointments: 2 },
    { name: 'Orthopedics', appointments: 1 },
    { name: 'Neurology', appointments: 1 },
  ];

  // Custom Chart Tooltip
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0];
      return (
        <div className="bg-slate-900 text-white px-3 py-2 rounded-xl text-xs shadow-lg border border-slate-700">
          <p className="font-bold">{data.name}</p>
          <p className="text-teal-300 font-semibold mt-0.5">
            {data.value} {data.value === 1 ? 'Visit' : 'Visits'}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs p-6 sm:p-8 space-y-6 transition-colors duration-200">
      {/* Top Header of Stats Section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-teal-700 dark:text-teal-400 uppercase tracking-wider">
              Patient Care Analytics
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-teal-500 animate-pulse" />
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight mt-0.5">
            Appointments & Outpatient Summary
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Real-time analytics and distribution of your scheduled visits, consultations, and completed reviews
          </p>
        </div>

        {/* Chart View Toggle Controls */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl self-start sm:self-center">
          <button
            type="button"
            onClick={() => setChartMode('status')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              chartMode === 'status'
                ? 'bg-white dark:bg-slate-700 text-teal-800 dark:text-teal-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <PieChartIcon className="w-3.5 h-3.5" />
            <span>Status Share</span>
          </button>
          <button
            type="button"
            onClick={() => setChartMode('department')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              chartMode === 'department'
                ? 'bg-white dark:bg-slate-700 text-teal-800 dark:text-teal-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>By Department</span>
          </button>
        </div>
      </div>

      {/* 4 Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Appointments Booked */}
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-teal-50/80 to-emerald-50/50 dark:from-teal-950/40 dark:to-emerald-950/20 border border-teal-100 dark:border-teal-900/60 shadow-2xs hover:shadow-md transition-all duration-300 group">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-teal-800 dark:text-teal-300 uppercase tracking-wider">
              Total Booked
            </span>
            <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform">
              <CalendarCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl sm:text-3xl font-black text-slate-950 dark:text-white tracking-tight block">
              {totalBooked}
            </span>
            <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 mt-0.5 block">
              Lifetime OPD reservations
            </span>
          </div>
        </div>

        {/* Card 2: Upcoming Visits */}
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-emerald-50/80 to-teal-50/40 dark:from-emerald-950/40 dark:to-teal-950/20 border border-emerald-100 dark:border-emerald-900/60 shadow-2xs hover:shadow-md transition-all duration-300 group">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-wider">
                Upcoming Visits
              </span>
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-600"></span>
              </span>
            </div>
            <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl sm:text-3xl font-black text-slate-950 dark:text-white tracking-tight block">
              {upcomingCount}
            </span>
            <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 mt-0.5 block truncate">
              {nextVisit 
                ? `Next: ${nextVisit.date || nextVisit.appointmentDate} (${nextVisit.timeSlot || nextVisit.appointmentTime})` 
                : 'No pending visits'}
            </span>
          </div>
        </div>

        {/* Card 3: Completed Visits */}
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-slate-50 to-blue-50/40 dark:from-slate-800/60 dark:to-blue-950/30 border border-slate-200/80 dark:border-slate-800 shadow-2xs hover:shadow-md transition-all duration-300 group">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
              Completed
            </span>
            <div className="w-9 h-9 rounded-xl bg-slate-800 dark:bg-slate-700 text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl sm:text-3xl font-black text-slate-950 dark:text-white tracking-tight block">
              {completedCount}
            </span>
            <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 mt-0.5 block">
              Consultations finalized
            </span>
          </div>
        </div>

        {/* Card 4: Action Status / Active Ratio */}
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-amber-50/60 to-orange-50/40 dark:from-amber-950/40 dark:to-orange-950/20 border border-amber-100 dark:border-amber-900/60 shadow-2xs hover:shadow-md transition-all duration-300 group">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-amber-800 dark:text-amber-300 uppercase tracking-wider">
              Pending Clearance
            </span>
            <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform">
              <Activity className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl sm:text-3xl font-black text-slate-950 dark:text-white tracking-tight block">
              {pendingCount}
            </span>
            <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 mt-0.5 block">
              Awaiting counter clearance
            </span>
          </div>
        </div>
      </div>

      {/* Visualization Chart Section using Recharts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center pt-2">
        {/* Left Side: Chart Visualization */}
        <div className="lg:col-span-8 bg-slate-50/80 dark:bg-slate-800/60 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200">
                {chartMode === 'status' 
                  ? 'Appointment Status Distribution' 
                  : 'Appointments by Specialty Department'}
              </h3>
            </div>
            {totalBooked === 0 && (
              <span className="text-[10px] text-amber-700 dark:text-amber-300 font-semibold bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 px-2 py-0.5 rounded-md">
                Preview Benchmark (0 user records)
              </span>
            )}
          </div>

          <div className="h-60 w-full">
            {chartMode === 'status' ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={displayStatusData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {displayStatusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                  <Legend 
                    verticalAlign="bottom" 
                    height={36}
                    formatter={(value) => (
                      <span className="text-xs font-medium text-slate-700 dark:text-slate-300">{value}</span>
                    )}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={displayDeptData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" opacity={0.3} />
                  <XAxis 
                    dataKey="name" 
                    tick={{ fontSize: 11, fill: '#94a3b8' }}
                    interval={0}
                    angle={-15}
                    textAnchor="end"
                  />
                  <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="appointments" fill="#0d9488" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Right Side: Key Insights & Quick Booking CTA */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-slate-900 dark:bg-slate-800 text-white rounded-2xl p-5 border border-slate-800 dark:border-slate-700 shadow-md space-y-3">
            <div className="flex items-center gap-2 text-teal-400">
              <ShieldCheck className="w-4 h-4" />
              <span className="text-[11px] font-bold uppercase tracking-wider">
                Visit Insights
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {upcomingCount > 0 ? (
                <>
                  You have <strong className="text-emerald-400">{upcomingCount} upcoming</strong> {upcomingCount === 1 ? 'consultation' : 'consultations'} scheduled at WeCare Hospital.
                  {nextVisit && (
                    <span className="block mt-1 text-[11px] text-slate-400">
                      Next appointment with <strong>{nextVisit.doctorName}</strong> on {nextVisit.date || nextVisit.appointmentDate} at {nextVisit.timeSlot || nextVisit.appointmentTime}.
                    </span>
                  )}
                </>
              ) : (
                'You currently have no pending outpatient appointments. Schedule a consultation anytime with our 140+ specialists.'
              )}
            </p>
            {onBookNew && (
              <button
                type="button"
                onClick={onBookNew}
                className="w-full mt-2 py-2.5 px-4 bg-teal-600 hover:bg-teal-500 active:scale-95 text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
              >
                <span>Book Outpatient Visit</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500 dark:text-slate-400 font-medium">Digital OPD Clearance</span>
              <span className="font-bold text-emerald-600 dark:text-emerald-400">Active</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500 dark:text-slate-400 font-medium">Average Queue Time</span>
              <span className="font-bold text-slate-800 dark:text-slate-200">&lt; 12 mins</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500 dark:text-slate-400 font-medium">Auto SMS Reminders</span>
              <span className="font-bold text-teal-700 dark:text-teal-400">Enabled</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
