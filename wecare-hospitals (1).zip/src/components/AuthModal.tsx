import React, { useState } from 'react';
import { 
  X, 
  Mail, 
  Lock, 
  User, 
  Phone, 
  Heart, 
  ShieldCheck, 
  AlertCircle, 
  Eye, 
  EyeOff, 
  CheckCircle2,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { auth } from '../lib/firebase';
import { sendPasswordResetEmail } from 'firebase/auth';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  reason?: string;
  defaultTab?: 'signin' | 'signup';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  reason,
  defaultTab = 'signin',
}) => {
  const { signInWithEmail, signUpWithEmail, signInWithGoogle } = useAuth();
  
  const [tab, setTab] = useState<'signin' | 'signup'>(defaultTab);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [resetSent, setResetSent] = useState(false);

  // Sign In State
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Sign Up State
  const [signupName, setSignupName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPhone, setSignupPhone] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [signupConfirmPassword, setSignupConfirmPassword] = useState('');
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [agreeTerms, setAgreeTerms] = useState(true);

  if (!isOpen) return null;

  const isValidEmail = (emailStr: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailStr.trim());
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const cleanEmail = loginEmail.trim();
    if (!cleanEmail || !loginPassword) {
      setError('Invalid email/phone or password.');
      return;
    }

    setLoading(true);
    try {
      await signInWithEmail(cleanEmail, loginPassword);
      onClose();
    } catch (err: any) {
      setError('Invalid email/phone or password.');
    } finally {
      setLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const cleanName = signupName.trim();
    const cleanEmail = signupEmail.trim();

    if (!cleanName) {
      setError('Please provide your full legal name.');
      return;
    }
    if (!cleanEmail || !isValidEmail(cleanEmail)) {
      setError('Please enter a valid email address.');
      return;
    }
    if (signupPassword.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    if (signupPassword !== signupConfirmPassword) {
      setError('Passwords do not match. Please re-enter confirm password.');
      return;
    }
    if (!agreeTerms) {
      setError('Please accept terms to create an electronic health record.');
      return;
    }

    setLoading(true);
    try {
      const res = await signUpWithEmail(cleanEmail, signupPassword, {
        name: cleanName,
        phone: signupPhone.trim() || '+91 98220 12345',
        age: 30,
        gender: 'other',
        bloodGroup: 'Not specified',
      });

      // Per requirement:
      // 1. Create account successfully
      // 2. Show: "Registration successful. Please login to continue."
      // 3. Redirect user to Login
      // 4. Do NOT automatically log in
      // 5. User must manually enter their registered email/phone and password
      setSuccessMsg(res.message || 'Account created successfully! Please login to continue.');
      setLoginEmail(cleanEmail);
      setLoginPassword('');
      setSignupPassword('');
      setSignupConfirmPassword('');
      setTab('signin');
    } catch (err: any) {
      const code = err?.code || '';
      if (code === 'auth/email-already-in-use') {
        setError('An account with this email already exists. Please switch to Sign In.');
      } else if (code === 'auth/weak-password') {
        setError('Password should be at least 6 characters.');
      } else {
        setError(err?.message || 'Failed to create account.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    setLoading(true);
    try {
      await signInWithGoogle();
      onClose();
    } catch (err: any) {
      const code = err?.code || '';
      if (code === 'auth/popup-closed-by-user' || code === 'auth/cancelled-popup-request') {
        setError('Google sign-in was cancelled.');
      } else {
        setError(err?.message || 'Google sign-in could not be completed.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordReset = async () => {
    const cleanEmail = loginEmail.trim();
    if (!cleanEmail) {
      setError('Please enter your email address above to receive a password reset link.');
      return;
    }
    if (!isValidEmail(cleanEmail)) {
      setError('Please enter a valid email address format to receive the reset link.');
      return;
    }
    try {
      await sendPasswordResetEmail(auth, cleanEmail);
      setResetSent(true);
      setError(null);
      setTimeout(() => setResetSent(false), 5000);
    } catch (err: any) {
      const code = err?.code || '';
      if (code === 'auth/user-not-found') {
        setError('No patient account found with this email address.');
      } else if (code === 'auth/invalid-email') {
        setError('Please enter a valid email address.');
      } else {
        setError(err?.message || 'Could not send password reset email.');
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 dark:bg-black/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-in fade-in">
      <div 
        id="auth-modal-dialog"
        className="relative bg-white dark:bg-black rounded-3xl shadow-2xl max-w-lg w-full border border-slate-200/90 dark:border-neutral-800 overflow-hidden animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Header Ribbon */}
        <div className="bg-gradient-to-r from-teal-700 via-teal-600 to-teal-800 dark:from-teal-900 dark:via-teal-800 dark:to-neutral-950 text-white p-6 relative">
          <button
            id="auth-modal-close-btn"
            onClick={onClose}
            className="absolute top-4 right-4 text-teal-100 hover:text-white bg-teal-800/40 hover:bg-teal-800/80 p-1.5 rounded-full transition cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 mb-2">
            <span className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center text-teal-200">
              <ShieldCheck className="w-5 h-5" />
            </span>
            <span className="text-xs uppercase tracking-wider font-semibold text-teal-200">
              WeCare Secure Patient Portal
            </span>
          </div>

          <h2 className="text-2xl font-bold tracking-tight text-white">
            {tab === 'signin' ? 'Welcome Back' : 'Create Patient Account'}
          </h2>
          <p className="text-teal-100 text-sm mt-1">
            {reason || 'Sign in or register to confirm your doctor appointment and manage medical records.'}
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-100 dark:border-neutral-900 bg-slate-50/70 dark:bg-neutral-950 p-1">
          <button
            id="tab-btn-signin"
            type="button"
            onClick={() => { setTab('signin'); setError(null); }}
            className={`flex-1 py-3 text-sm font-semibold rounded-xl transition cursor-pointer ${
              tab === 'signin'
                ? 'bg-white dark:bg-neutral-900 text-teal-700 dark:text-teal-400 shadow-xs border border-transparent dark:border-neutral-700 font-bold'
                : 'text-slate-600 dark:text-neutral-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Sign In to Account
          </button>
          <button
            id="tab-btn-signup"
            type="button"
            onClick={() => { setTab('signup'); setError(null); }}
            className={`flex-1 py-3 text-sm font-semibold rounded-xl transition cursor-pointer ${
              tab === 'signup'
                ? 'bg-white dark:bg-neutral-900 text-teal-700 dark:text-teal-400 shadow-xs border border-transparent dark:border-neutral-700 font-bold'
                : 'text-slate-600 dark:text-neutral-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            New Patient Registration
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 sm:p-8 max-h-[75vh] overflow-y-auto bg-white dark:bg-black">
          {successMsg && tab === 'signin' && (
            <div className="mb-5 p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 text-sm flex items-start gap-2.5 animate-in fade-in">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              <div className="flex-1 text-xs sm:text-sm font-semibold">{successMsg}</div>
            </div>
          )}

          {error && (
            <div className="mb-5 p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-300 text-sm flex items-start gap-2.5 animate-in fade-in">
              <AlertCircle className="w-5 h-5 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
              <div className="flex-1 text-xs sm:text-sm">
                <p>{error}</p>
                {tab === 'signin' && (error.includes('Invalid credentials') || error.includes('New Patient Registration')) && (
                  <button
                    type="button"
                    onClick={() => {
                      if (loginEmail) setSignupEmail(loginEmail);
                      setTab('signup');
                      setError(null);
                    }}
                    className="mt-1.5 text-xs font-semibold text-teal-700 dark:text-teal-400 hover:text-teal-800 dark:hover:text-teal-300 underline block cursor-pointer"
                  >
                    Go to New Patient Registration →
                  </button>
                )}
              </div>
            </div>
          )}

          {resetSent && (
            <div className="mb-5 p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-sm flex items-start gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              <div className="flex-1 text-xs sm:text-sm">Password reset email sent. Please check your inbox.</div>
            </div>
          )}

          {/* Social Google Sign In */}
          <button
            id="btn-google-auth"
            type="button"
            onClick={handleGoogleSignIn}
            disabled={loading}
            className="w-full flex items-center justify-center gap-3 py-2.5 px-4 rounded-xl border border-slate-300 dark:border-neutral-800 hover:bg-slate-50 dark:hover:bg-neutral-900 bg-white dark:bg-neutral-950 text-slate-700 dark:text-neutral-200 font-semibold text-sm transition shadow-2xs mb-4 cursor-pointer disabled:opacity-50"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span>Continue with Google</span>
          </button>

          <div className="relative my-5">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-200 dark:border-neutral-800"></div>
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white dark:bg-black px-2 text-slate-400 dark:text-neutral-500 font-medium">Or continue with email</span>
            </div>
          </div>

          {/* SIGN IN FORM */}
          {tab === 'signin' ? (
            <form onSubmit={handleSignIn} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-neutral-300 uppercase tracking-wider mb-1.5">
                  Email Address
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 dark:text-neutral-500">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    id="signin-input-email"
                    type="email"
                    required
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 dark:border-neutral-700 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-neutral-500 font-medium focus:outline-hidden focus:ring-2 focus:ring-teal-500 dark:focus:ring-teal-400 focus:border-teal-500 dark:focus:border-teal-400 bg-white dark:bg-neutral-950 caret-teal-500 dark:caret-teal-400 transition"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold text-slate-700 dark:text-neutral-300 uppercase tracking-wider">
                    Password
                  </label>
                  <button
                    type="button"
                    onClick={handlePasswordReset}
                    className="text-xs font-medium text-teal-600 dark:text-teal-400 hover:text-teal-700 dark:hover:text-teal-300 cursor-pointer"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 dark:text-neutral-500">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    id="signin-input-password"
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder={showPassword ? 'Enter password' : '••••••••••••'}
                    className={`w-full pl-9 pr-10 py-2.5 rounded-xl border border-slate-300 dark:border-neutral-700 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-neutral-500 font-medium focus:outline-hidden focus:ring-2 focus:ring-teal-500 dark:focus:ring-teal-400 focus:border-teal-500 dark:focus:border-teal-400 bg-white dark:bg-neutral-950 caret-teal-500 dark:caret-teal-400 transition ${
                      !showPassword && loginPassword ? 'tracking-wider' : 'tracking-normal'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 dark:text-neutral-400 hover:text-slate-700 dark:hover:text-white cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {loginPassword.length > 0 && (
                  <div className="flex items-center gap-1.5 text-[11px] text-teal-600 dark:text-teal-400 mt-1.5 px-1 animate-in fade-in">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    <span>{loginPassword.length} characters typed</span>
                  </div>
                )}
              </div>

              <button
                id="btn-submit-signin"
                type="submit"
                disabled={loading}
                className="w-full mt-2 py-3 px-4 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-sm rounded-xl shadow-xs hover:shadow-teal-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {loading ? (
                  <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                ) : (
                  <>
                    <span>Sign In to Continue</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          ) : (
            /* SIGN UP FORM */
            <form onSubmit={handleSignUp} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-neutral-300 uppercase tracking-wider mb-1">
                  Full Legal Name *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 dark:text-neutral-500">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    id="signup-input-name"
                    type="text"
                    required
                    value={signupName}
                    onChange={(e) => setSignupName(e.target.value)}
                    placeholder="Full legal name"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 dark:border-neutral-700 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-neutral-500 font-medium focus:outline-hidden focus:ring-2 focus:ring-teal-500 dark:focus:ring-teal-400 bg-white dark:bg-neutral-950 caret-teal-500 dark:caret-teal-400 transition"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-neutral-300 uppercase tracking-wider mb-1">
                    Email Address *
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 dark:text-neutral-500">
                      <Mail className="w-4 h-4" />
                    </div>
                    <input
                      id="signup-input-email"
                      type="email"
                      required
                      value={signupEmail}
                      onChange={(e) => setSignupEmail(e.target.value)}
                      placeholder="name@example.com"
                      className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 dark:border-neutral-700 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-neutral-500 font-medium focus:outline-hidden focus:ring-2 focus:ring-teal-500 dark:focus:ring-teal-400 bg-white dark:bg-neutral-950 caret-teal-500 dark:caret-teal-400 transition"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-neutral-300 uppercase tracking-wider mb-1">
                    Phone Number
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 dark:text-neutral-500">
                      <Phone className="w-4 h-4" />
                    </div>
                    <input
                      id="signup-input-phone"
                      type="tel"
                      value={signupPhone}
                      onChange={(e) => setSignupPhone(e.target.value)}
                      placeholder="+91 98220 12345"
                      className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 dark:border-neutral-700 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-neutral-500 font-medium focus:outline-hidden focus:ring-2 focus:ring-teal-500 dark:focus:ring-teal-400 bg-white dark:bg-neutral-950 caret-teal-500 dark:caret-teal-400 transition"
                    />
                  </div>
                </div>
              </div>

              {/* Create Password */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-neutral-300 uppercase tracking-wider mb-1">
                  Create Password * (min 6 characters)
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 dark:text-neutral-500">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    id="signup-input-password"
                    type={showPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={signupPassword}
                    onChange={(e) => setSignupPassword(e.target.value)}
                    placeholder={showPassword ? 'Enter password' : '••••••••••••'}
                    className={`w-full pl-9 pr-10 py-2.5 rounded-xl border border-slate-300 dark:border-neutral-700 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-neutral-500 font-medium focus:outline-hidden focus:ring-2 focus:ring-teal-500 dark:focus:ring-teal-400 bg-white dark:bg-neutral-950 caret-teal-500 dark:caret-teal-400 transition ${
                      !showPassword && signupPassword ? 'tracking-wider' : 'tracking-normal'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 dark:text-neutral-400 hover:text-slate-700 dark:hover:text-white cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {signupPassword.length > 0 && (
                  <div className="flex items-center gap-1.5 text-[11px] text-teal-600 dark:text-teal-400 mt-1 px-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    <span>{signupPassword.length} characters typed</span>
                  </div>
                )}
              </div>

              {/* Confirm Password */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-neutral-300 uppercase tracking-wider mb-1">
                  Confirm Password *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 dark:text-neutral-500">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    id="signup-input-confirm-password"
                    type={showConfirmPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={signupConfirmPassword}
                    onChange={(e) => setSignupConfirmPassword(e.target.value)}
                    placeholder={showConfirmPassword ? 'Re-enter password' : '••••••••••••'}
                    className={`w-full pl-9 pr-10 py-2.5 rounded-xl border border-slate-300 dark:border-neutral-700 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-neutral-500 font-medium focus:outline-hidden focus:ring-2 focus:ring-teal-500 dark:focus:ring-teal-400 bg-white dark:bg-neutral-950 caret-teal-500 dark:caret-teal-400 transition ${
                      !showConfirmPassword && signupConfirmPassword ? 'tracking-wider' : 'tracking-normal'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 dark:text-neutral-400 hover:text-slate-700 dark:hover:text-white cursor-pointer"
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {signupConfirmPassword && signupPassword !== signupConfirmPassword && (
                  <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-1 font-medium">
                    Passwords do not match
                  </p>
                )}
                {signupConfirmPassword && signupPassword === signupConfirmPassword && (
                  <p className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1 font-medium flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>Passwords match</span>
                  </p>
                )}
              </div>

              <div className="flex items-start gap-2 pt-1">
                <input
                  id="agree-terms-checkbox"
                  type="checkbox"
                  checked={agreeTerms}
                  onChange={(e) => setAgreeTerms(e.target.checked)}
                  className="mt-1 h-4 w-4 rounded border-slate-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-teal-600 focus:ring-teal-500"
                />
                <label htmlFor="agree-terms-checkbox" className="text-xs text-slate-600 dark:text-neutral-400">
                  I consent to the creation of a secure electronic patient profile per HIPAA & WeCare Hospital clinical protocols.
                </label>
              </div>

              <button
                id="btn-submit-signup"
                type="submit"
                disabled={loading}
                className="w-full mt-2 py-3 px-4 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-sm rounded-xl shadow-xs hover:shadow-teal-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {loading ? (
                  <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                ) : (
                  <>
                    <span>Create Patient Account</span>
                    <CheckCircle2 className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
