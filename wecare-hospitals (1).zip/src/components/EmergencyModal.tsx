import React, { useState } from 'react';
import { 
  X, 
  PhoneCall, 
  Ambulance, 
  MapPin, 
  Clock, 
  AlertOctagon, 
  CheckCircle2, 
  ShieldAlert,
  ArrowRight
} from 'lucide-react';

interface EmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EmergencyModal: React.FC<EmergencyModalProps> = ({ isOpen, onClose }) => {
  const [ambulanceRequested, setAmbulanceRequested] = useState(false);
  const [patientLocation, setPatientLocation] = useState('');
  const [contactNumber, setContactNumber] = useState('');

  if (!isOpen) return null;

  const handleRequestAmbulance = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactNumber || !patientLocation) return;
    setAmbulanceRequested(true);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 dark:bg-black/90 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="relative w-full max-w-lg bg-white dark:bg-black rounded-2xl shadow-2xl border border-rose-100 dark:border-rose-950/60 overflow-hidden text-slate-900 dark:text-white">
        {/* Header Ribbon */}
        <div className="bg-gradient-to-r from-rose-600 via-rose-700 to-red-800 px-6 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-white/20 flex items-center justify-center">
              <ShieldAlert className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-lg leading-tight">24/7 WeCare Emergency Response</h3>
              <p className="text-xs text-rose-100">Level-1 Trauma Center • Immediate Triage</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6 bg-white dark:bg-black">
          {/* Urgent Hotline Box */}
          <div className="bg-rose-50 dark:bg-rose-950/30 border-2 border-rose-200 dark:border-rose-900/60 rounded-xl p-4 text-center">
            <p className="text-xs font-semibold uppercase tracking-wider text-rose-700 dark:text-rose-400 mb-1">
              Direct Trauma & Emergency Helpline
            </p>
            <a
              href="tel:108"
              className="inline-flex items-center gap-2 text-3xl sm:text-4xl font-black text-rose-700 dark:text-rose-300 hover:text-rose-800 transition"
            >
              <PhoneCall className="w-8 h-8 text-rose-600 dark:text-rose-400 animate-bounce" />
              <span>108</span>
            </a>
            <p className="text-xs text-rose-600 dark:text-rose-400 mt-1 font-medium">
              National Emergency & Ambulance SOS • 24/7 Fast Response
            </p>
          </div>

          {/* Quick Ambulance Dispatch */}
          {!ambulanceRequested ? (
            <form onSubmit={handleRequestAmbulance} className="space-y-4 bg-slate-50 dark:bg-neutral-950 p-4 rounded-xl border border-slate-200 dark:border-neutral-800">
              <div className="flex items-center gap-2 text-slate-800 dark:text-white font-semibold text-sm">
                <Ambulance className="w-4 h-4 text-rose-600 dark:text-rose-400" />
                <span>Instant GPS Ambulance Dispatch (ICU on Wheels)</span>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-700 dark:text-neutral-300">Pickup Address / Landmark</label>
                <div className="relative">
                  <MapPin className="w-4 h-4 text-slate-400 dark:text-neutral-500 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    placeholder="Enter street address, building or landmark"
                    value={patientLocation}
                    onChange={(e) => setPatientLocation(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm bg-white dark:bg-black border border-slate-300 dark:border-neutral-700 text-slate-900 dark:text-white rounded-lg focus:ring-2 focus:ring-rose-500 focus:outline-hidden"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-700 dark:text-neutral-300">Caller Phone Number</label>
                <div className="relative">
                  <PhoneCall className="w-4 h-4 text-slate-400 dark:text-neutral-500 absolute left-3 top-3" />
                  <input
                    type="tel"
                    required
                    placeholder="e.g., +91 98220 12345"
                    value={contactNumber}
                    onChange={(e) => setContactNumber(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm bg-white dark:bg-black border border-slate-300 dark:border-neutral-700 text-slate-900 dark:text-white rounded-lg focus:ring-2 focus:ring-rose-500 focus:outline-hidden"
                  />
                </div>
              </div>
              <button
                type="submit"
                className="w-full py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold text-sm rounded-lg shadow-sm transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Dispatch Nearest Mobile ICU</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          ) : (
            <div className="bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 rounded-xl p-4 text-center space-y-2 animate-in fade-in">
              <CheckCircle2 className="w-10 h-10 text-emerald-600 dark:text-emerald-400 mx-auto" />
              <h4 className="font-bold text-slate-900 dark:text-white">Ambulance Dispatched!</h4>
              <p className="text-xs text-slate-600 dark:text-neutral-300">
                Advanced Life Support Ambulance #AMB-14 has been dispatched to <strong>{patientLocation}</strong>.
              </p>
              <div className="inline-block bg-white dark:bg-black px-3 py-1 rounded-full text-xs font-bold text-emerald-700 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-800">
                Estimated Arrival: 7 - 11 minutes
              </div>
              <p className="text-[11px] text-slate-500 dark:text-neutral-400">
                Our emergency paramedic team will contact {contactNumber} in under 60 seconds.
              </p>
            </div>
          )}

          {/* Quick Directives */}
          <div className="border-t border-slate-100 dark:border-neutral-800 pt-3 text-xs text-slate-500 dark:text-neutral-400 space-y-1">
            <p><strong>Hospital Entrance:</strong> Emergency Gate 1, North Ramp, Ground Floor.</p>
            <p><strong>Dedicated Facilities:</strong> 24/7 Blood Bank, Bedside CT, Cath Lab on active standby.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
