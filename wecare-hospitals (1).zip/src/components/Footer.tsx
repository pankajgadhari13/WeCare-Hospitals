import React from 'react';
import { 
  HeartPulse, 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  ExternalLink,
  Award,
  Ambulance,
  Calendar,
  ChevronRight,
  Download,
  Smartphone
} from 'lucide-react';
import { DEPARTMENTS } from '../data/hospitalData';

interface FooterProps {
  setActiveTab: (tab: string) => void;
  openEmergencyModal: () => void;
  openInstallModal?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ setActiveTab, openEmergencyModal, openInstallModal }) => {
  return (
    <footer className="bg-black text-slate-300 pt-16 pb-12 border-t border-neutral-900">
      <div className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16">
        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-slate-800">
          {/* Col 1: Brand & Emergency */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center">
                <HeartPulse className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-white tracking-tight">
                WeCare <span className="text-teal-400 font-light">Hospital</span>
              </span>
            </div>
            
            <p className="text-sm text-slate-400 leading-relaxed max-w-md">
              WeCare Hospital is a premier multi-specialty quaternary care medical institution dedicated to delivering international clinical excellence, compassionate patient care, and cutting-edge medical research.
            </p>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                  24/7 Critical Emergency Helpline
                </span>
                <span className="text-xs text-rose-400 font-bold bg-rose-950/60 px-2 py-0.5 rounded border border-rose-800/50">SOS 108</span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <a 
                  href="tel:108" 
                  className="text-2xl font-black text-white hover:text-teal-400 transition flex items-center gap-2"
                >
                  <span className="text-rose-500">📞</span> 108
                </a>
                <button
                  onClick={openEmergencyModal}
                  className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-lg transition"
                >
                  Ambulance
                </button>
              </div>
            </div>

            <div className="flex items-center gap-4 text-xs text-slate-400 pt-2">
              <div className="flex items-center gap-1">
                <Award className="w-4 h-4 text-teal-400" />
                <span>JCI Gold Seal</span>
              </div>
              <div className="flex items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-teal-400" />
                <span>NABH Certified</span>
              </div>
              <div className="flex items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-teal-400" />
                <span>ISO 9001:2015</span>
              </div>
            </div>

            {/* Mobile App Download Card */}
            {openInstallModal && (
              <div className="pt-2">
                <button
                  type="button"
                  onClick={openInstallModal}
                  className="w-full sm:w-auto px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-teal-300 hover:text-white border border-teal-500/40 rounded-xl text-xs font-bold transition flex items-center justify-between sm:justify-start gap-3 cursor-pointer shadow-md group"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg bg-teal-600/30 text-teal-400 flex items-center justify-center">
                      <Download className="w-3.5 h-3.5" />
                    </div>
                    <span>Download WeCare App (APK / WebAPK)</span>
                  </div>
                  <span className="px-1.5 py-0.5 rounded bg-teal-500/20 text-teal-300 text-[10px] font-bold group-hover:bg-teal-600 group-hover:text-white transition">
                    Android & iOS
                  </span>
                </button>
              </div>
            )}
          </div>

          {/* Col 2: Quick Links */}
          <div className="space-y-4">
            <h4 className="text-sm font-semibold uppercase tracking-wider text-white">
              Navigation
            </h4>
            <ul className="space-y-2.5 text-sm">
              {[
                { label: 'Home Page', tab: 'home' },
                { label: 'About WeCare', tab: 'about' },
                { label: 'Medical Departments', tab: 'departments' },
                { label: 'Find a Specialist', tab: 'doctors' },
                { label: 'Live Slot Availability', tab: 'availability' },
                { label: 'Book Appointment', tab: 'booking' },
                { label: 'Patient Portal & Reports', tab: 'dashboard' },
              ].map((link) => (
                <li key={link.tab}>
                  <button
                    onClick={() => {
                      setActiveTab(link.tab);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="hover:text-teal-400 transition flex items-center gap-1 text-slate-400 cursor-pointer"
                  >
                    <ChevronRight className="w-3 h-3 text-teal-500" />
                    <span>{link.label}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Key Departments */}
          <div className="space-y-4">
            <h4 className="text-sm font-semibold uppercase tracking-wider text-white">
              Centres of Excellence
            </h4>
            <ul className="space-y-2.5 text-sm text-slate-400">
              {DEPARTMENTS.slice(0, 6).map((dept) => (
                <li key={dept.id}>
                  <button
                    onClick={() => {
                      setActiveTab('departments');
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="hover:text-teal-400 transition text-left cursor-pointer flex items-center gap-1"
                  >
                    <ChevronRight className="w-3 h-3 text-slate-600" />
                    <span className="truncate">{dept.name}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 4: Contact & Visiting Hours */}
          <div className="space-y-4">
            <h4 className="text-sm font-semibold uppercase tracking-wider text-white">
              Hospital Campus
            </h4>
            <div className="space-y-3 text-xs text-slate-400">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
                <span>
                  Akhatwade near by nagardeola dist jalgaon 425001
                </span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-teal-400 shrink-0" />
                <span>Emergency: 108 • OPD Desk: +91 98220 12345</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-teal-400 shrink-0" />
                <span>care@wecarehospitals.org</span>
              </div>
              <div className="flex items-start gap-2.5 pt-1">
                <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <p className="text-slate-200 font-medium">Visiting Hours:</p>
                  <p>Morning: 10:00 AM – 12:00 PM</p>
                  <p>Evening: 05:00 PM – 07:30 PM</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom copyright & disclaimer */}
        <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <p>© {new Date().getFullYear()} WeCare Hospital Group. All rights reserved.</p>
          
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-900 border border-teal-500/40 text-slate-300 shadow-sm">
            <span>Website created by</span>
            <span className="text-teal-400 font-bold text-sm tracking-wide">Pankaj Gadhari</span>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-slate-500">
            <span className="hover:text-slate-400 transition cursor-pointer">Patient Rights & Privacy Policy</span>
            <span className="hover:text-slate-400 transition cursor-pointer">Biomedical Waste Compliance</span>
            <span className="hover:text-slate-400 transition cursor-pointer">Clinical Governance</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
