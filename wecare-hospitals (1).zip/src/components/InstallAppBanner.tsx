import React, { useState, useEffect } from 'react';
import { Download, Smartphone, X, CheckCircle2, ShieldCheck } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface InstallAppBannerProps {
  onOpenModal: () => void;
}

export const InstallAppBanner: React.FC<InstallAppBannerProps> = ({ onOpenModal }) => {
  const { isInstalled, triggerDownloadOrInstall } = usePWAInstall();
  const [showBanner, setShowBanner] = useState(false);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      const dismissed = sessionStorage.getItem('wecare_install_banner_dismissed');
      if (dismissed === 'true') return;

      const isMobile = window.innerWidth <= 768 || /iphone|ipad|ipod|android/i.test(navigator.userAgent);
      if (isMobile && !isInstalled) {
        // Show lightweight non-blocking banner after a slight delay
        const timer = setTimeout(() => {
          setShowBanner(true);
        }, 800);
        return () => clearTimeout(timer);
      }
    } catch {}
  }, [isInstalled]);

  const handleDismiss = () => {
    setShowBanner(false);
    try {
      sessionStorage.setItem('wecare_install_banner_dismissed', 'true');
    } catch {}
  };

  const handleDownload = async () => {
    setDownloading(true);
    try {
      await triggerDownloadOrInstall();
    } catch (err) {
      console.warn('Download error:', err);
    }
    setTimeout(() => {
      setDownloading(false);
      handleDismiss();
    }, 2000);
  };

  if (isInstalled || !showBanner) return null;

  return (
    <div 
      className="fixed bottom-16 sm:bottom-4 left-3 right-3 sm:left-auto sm:right-4 sm:max-w-md z-40 animate-in slide-in-from-bottom-4 duration-300 pointer-events-auto"
      role="region"
      aria-label="App download banner"
    >
      <div className="bg-slate-900/95 dark:bg-black/95 text-white p-3.5 sm:p-4 rounded-2xl shadow-2xl border border-teal-500/50 backdrop-blur-md flex items-center justify-between gap-3">
        {/* Logo & Info */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-teal-700 via-teal-600 to-teal-400 p-0.5 flex items-center justify-center shrink-0 shadow-sm">
            <img src="/pwa-192x192.png" alt="WeCare App" className="w-full h-full object-contain rounded-lg" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="text-xs sm:text-sm font-bold truncate text-white">WeCare App</span>
              <span className="px-1.5 py-0.2 rounded bg-teal-500/20 text-teal-300 text-[9px] font-bold uppercase tracking-wider">
                APK
              </span>
            </div>
            <p className="text-[11px] text-slate-300 truncate">
              Fast Doctor Booking & Offline Pass
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={handleDownload}
            disabled={downloading}
            className="px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs transition active:scale-95 cursor-pointer"
          >
            {downloading ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5 animate-bounce" />
                <span>Downloading...</span>
              </>
            ) : (
              <>
                <Download className="w-3.5 h-3.5" />
                <span>Download</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={handleDismiss}
            aria-label="Close download prompt"
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
