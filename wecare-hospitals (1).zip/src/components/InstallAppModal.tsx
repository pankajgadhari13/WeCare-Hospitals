import React, { useState } from 'react';
import { 
  Download, 
  Smartphone, 
  CheckCircle2, 
  Share2, 
  PlusSquare, 
  X, 
  ShieldCheck, 
  Zap, 
  WifiOff, 
  FileText, 
  PhoneCall, 
  ExternalLink,
  ChevronRight,
  Info
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface InstallAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallAppModal = ({ isOpen, onClose }: InstallAppModalProps) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, triggerDownloadOrInstall } = usePWAInstall();
  const [installStatus, setInstallStatus] = useState<'idle' | 'installing' | 'success' | 'dismissed'>('idle');
  const [activeTab, setActiveTab] = useState<'android' | 'ios' | 'desktop'>(
    isIOS ? 'ios' : isAndroid ? 'android' : 'android'
  );

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    setInstallStatus('installing');
    try {
      const res = await triggerDownloadOrInstall();
      if (res === 'installed') {
        setInstallStatus('success');
      } else {
        setInstallStatus('idle');
      }
    } catch {
      setInstallStatus('idle');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden text-slate-900 dark:text-white flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="relative p-5 sm:p-6 bg-gradient-to-r from-teal-900 via-slate-900 to-slate-950 text-white flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-teal-500/20 border border-teal-400/30 flex items-center justify-center p-1.5 shrink-0 shadow-inner">
              <img src="/pwa-192x192.png" alt="WeCare App Icon" className="w-full h-full object-contain rounded-xl" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black tracking-tight">WeCare Hospital App</h3>
                <span className="px-2 py-0.5 rounded-full bg-teal-400/20 text-teal-300 text-[10px] font-bold uppercase border border-teal-400/30">
                  Android & WebAPK
                </span>
              </div>
              <p className="text-xs text-teal-200/80 mt-0.5">
                Official Hospital Mobile Application
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-xl transition cursor-pointer"
            aria-label="Close installation modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 space-y-5 overflow-y-auto">
          {/* Success Banner if already installed */}
          {isInstalled || installStatus === 'success' ? (
            <div className="p-4 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 rounded-2xl flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500 text-white flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-emerald-900 dark:text-emerald-200">App Already Installed!</h4>
                <p className="text-xs text-emerald-700 dark:text-emerald-400 mt-0.5">
                  WeCare Hospital app is added to your phone's home screen with instant access.
                </p>
              </div>
            </div>
          ) : (
            <>
              {/* Direct Install CTA Box */}
              <div className="p-4 sm:p-5 bg-gradient-to-br from-teal-50 to-emerald-50/60 dark:from-teal-950/50 dark:to-slate-800/80 rounded-2xl border border-teal-200/80 dark:border-teal-900/60 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-[11px] font-bold text-teal-800 dark:text-teal-300 uppercase tracking-wider block">
                      Fast Direct Installation
                    </span>
                    <h4 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white mt-0.5">
                      Install Directly on Phone / Desktop
                    </h4>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300 text-[11px] font-bold flex items-center gap-1 shrink-0">
                    <Zap className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    &lt; 2 MB
                  </span>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  No Play Store required. Click below to install directly. Android creates an official certified <strong>WebAPK</strong> application on your device.
                </p>

                <div className="pt-1 flex flex-col gap-2">
                  <button
                    type="button"
                    onClick={handleInstallClick}
                    disabled={installStatus === 'installing'}
                    className="w-full py-3 px-5 bg-teal-600 hover:bg-teal-700 active:scale-98 text-white text-sm font-bold rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>{installStatus === 'installing' ? 'Starting Download...' : 'Download & Install WeCare App (APK)'}</span>
                  </button>
                </div>
              </div>

              {/* Platform Switcher Tabs */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
                  <span className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                    Installation Guides:
                  </span>
                  <div className="flex items-center gap-1.5 ml-auto">
                    <button
                      type="button"
                      onClick={() => setActiveTab('android')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                        activeTab === 'android'
                          ? 'bg-slate-900 dark:bg-teal-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      Android (Chrome)
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('ios')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                        activeTab === 'ios'
                          ? 'bg-slate-900 dark:bg-teal-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      iPhone (Safari)
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('desktop')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                        activeTab === 'desktop'
                          ? 'bg-slate-900 dark:bg-teal-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      PC / Laptop
                    </button>
                  </div>
                </div>

                {/* Android Steps */}
                {activeTab === 'android' && (
                  <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/80 space-y-2.5 text-xs text-slate-700 dark:text-slate-300">
                    <div className="flex items-center gap-2 text-teal-700 dark:text-teal-400 font-bold">
                      <Smartphone className="w-4 h-4" />
                      <span>Android WebAPK Installation Steps:</span>
                    </div>
                    <ol className="space-y-2 list-decimal list-inside pl-1 text-[12px] leading-relaxed">
                      <li>Open this website in <strong>Google Chrome</strong> on your phone.</li>
                      <li>
                        Click the <strong>"Install / Download App"</strong> button above, or tap the three dots (<strong>⋮</strong>) in Chrome top-right.
                      </li>
                      <li>
                        Select <strong>"Install app"</strong> or <strong>"Add to Home Screen"</strong>.
                      </li>
                      <li>
                        Android will automatically generate and install the verified <strong>WebAPK</strong> onto your home screen and app drawer!
                      </li>
                    </ol>
                  </div>
                )}

                {/* iOS Steps */}
                {activeTab === 'ios' && (
                  <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/80 space-y-2.5 text-xs text-slate-700 dark:text-slate-300">
                    <div className="flex items-center gap-2 text-teal-700 dark:text-teal-400 font-bold">
                      <Share2 className="w-4 h-4" />
                      <span>iPhone & iPad Installation Steps (Safari):</span>
                    </div>
                    <ol className="space-y-2 list-decimal list-inside pl-1 text-[12px] leading-relaxed">
                      <li>Open this website in <strong>Safari</strong> on your iPhone or iPad.</li>
                      <li>
                        Tap the <strong>Share</strong> button (box with an arrow pointing up <span className="inline-block px-1 bg-slate-200 dark:bg-slate-700 rounded font-mono">⎋</span>) at the bottom toolbar.
                      </li>
                      <li>Scroll down and tap <strong>"Add to Home Screen"</strong> (<PlusSquare className="w-3.5 h-3.5 inline mx-1 text-teal-600" />).</li>
                      <li>Tap <strong>"Add"</strong> in the top-right corner to place the app on your home screen.</li>
                    </ol>
                  </div>
                )}

                {/* Desktop Steps */}
                {activeTab === 'desktop' && (
                  <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/80 space-y-2.5 text-xs text-slate-700 dark:text-slate-300">
                    <div className="flex items-center gap-2 text-teal-700 dark:text-teal-400 font-bold">
                      <Zap className="w-4 h-4" />
                      <span>Windows & Mac Chrome / Edge Installation:</span>
                    </div>
                    <ol className="space-y-2 list-decimal list-inside pl-1 text-[12px] leading-relaxed">
                      <li>Look at the right side of your Chrome URL address bar.</li>
                      <li>Click the <strong>Install WeCare App</strong> icon (monitor with a down arrow).</li>
                      <li>Click <strong>"Install"</strong> to launch WeCare in a standalone window with taskbar pinning.</li>
                    </ol>
                  </div>
                )}
              </div>
            </>
          )}

          {/* App Key Highlights */}
          <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <h5 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
              App Features & Advantages:
            </h5>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800 flex items-center gap-2">
                <WifiOff className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0" />
                <span className="font-medium text-slate-700 dark:text-slate-300">Works Offline</span>
              </div>
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800 flex items-center gap-2">
                <FileText className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0" />
                <span className="font-medium text-slate-700 dark:text-slate-300">Digital OPD Pass</span>
              </div>
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800 flex items-center gap-2">
                <PhoneCall className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                <span className="font-medium text-slate-700 dark:text-slate-300">1-Tap 108 SOS</span>
              </div>
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800 flex items-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <span className="font-medium text-slate-700 dark:text-slate-300">Safe & Verified</span>
              </div>
            </div>
          </div>

          {/* Security & Verification Note */}
          <div className="p-3 bg-teal-50/60 dark:bg-teal-950/40 rounded-xl border border-teal-100 dark:border-teal-900/60 flex items-center gap-2.5 text-[11px] text-teal-900 dark:text-teal-300">
            <Info className="w-4 h-4 text-teal-600 dark:text-teal-400 shrink-0" />
            <p>
              Direct WebAPK installation is virus-free, signed by your phone's browser, and updates automatically whenever new features are added.
            </p>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <span className="text-[11px] text-slate-500 dark:text-slate-400">
            WeCare Hospital • Akhatwade, Nagardeola
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-800 dark:text-white rounded-xl text-xs font-bold transition cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
