import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  Clock, 
  UserCheck, 
  Calendar, 
  AlertCircle, 
  Filter, 
  Search, 
  RefreshCw, 
  Zap, 
  CheckCircle2, 
  Users,
  ChevronRight,
  TrendingUp,
  MapPin
} from 'lucide-react';
import { Doctor, Department } from '../types';

interface LiveAvailabilityTrackerProps {
  doctors: Doctor[];
  departments: Department[];
  onSelectDoctorForBooking: (doctor: Doctor) => void;
}

export const LiveAvailabilityTracker: React.FC<LiveAvailabilityTrackerProps> = ({
  doctors,
  departments,
  onSelectDoctorForBooking,
}) => {
  const [selectedDept, setSelectedDept] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [liveDoctors, setLiveDoctors] = useState<Doctor[]>(doctors);
  const [lastRefreshed, setLastRefreshed] = useState<string>('Just now');
  const [liveTickerMessage, setLiveTickerMessage] = useState<string>(
    '⚡ Real-time OPD sync active: 14 specialist clinics currently consulting patients'
  );
  const [isLiveSimulating, setIsLiveSimulating] = useState(true);

  // Sync state when doctors prop changes
  useEffect(() => {
    setLiveDoctors(doctors);
  }, [doctors]);

  // Periodic realistic live updates simulation to show true real-time availability tracking
  useEffect(() => {
    if (!isLiveSimulating) return;

    const interval = setInterval(() => {
      // Pick a random doctor and adjust their slot count slightly to demonstrate real-time availability
      setLiveDoctors((prevDocs) => {
        const randomIndex = Math.floor(Math.random() * prevDocs.length);
        const targetDoc = prevDocs[randomIndex];
        if (!targetDoc) return prevDocs;

        // Choose a random available slot
        const availableSlots = targetDoc.slots.filter((s) => s.isAvailable && s.bookedCount < s.totalCapacity);
        if (availableSlots.length === 0) return prevDocs;

        const targetSlot = availableSlots[Math.floor(Math.random() * availableSlots.length)];
        const updatedBookedCount = Math.min(targetSlot.totalCapacity, targetSlot.bookedCount + 1);

        const updatedSlots = targetDoc.slots.map((s) => 
          s.id === targetSlot.id 
            ? { ...s, bookedCount: updatedBookedCount, isAvailable: updatedBookedCount < s.totalCapacity } 
            : s
        );

        setLiveTickerMessage(
          `🔔 Live Update: 1 appointment just reserved for ${targetDoc.name} (${targetDoc.departmentName}) for ${targetSlot.time}`
        );
        setLastRefreshed(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));

        return prevDocs.map((doc, idx) => (idx === randomIndex ? { ...doc, slots: updatedSlots } : doc));
      });
    }, 12000); // Trigger every 12 seconds

    return () => clearInterval(interval);
  }, [isLiveSimulating]);

  const handleManualRefresh = () => {
    setLastRefreshed(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    setLiveTickerMessage('⚡ Real-time OPD board refreshed with latest queue telemetry.');
  };

  const filteredDoctors = liveDoctors.filter((doc) => {
    const matchesDept = selectedDept === 'all' || doc.departmentId === selectedDept;
    const matchesSearch = 
      doc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.departmentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.specializations.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesDept && matchesSearch;
  });

  // Calculate global availability statistics
  const totalDoctorsAvailableToday = liveDoctors.filter((d) => d.isAvailableToday).length;
  const totalOpenSlots = liveDoctors.reduce((acc, doc) => {
    return acc + doc.slots.reduce((sAcc, slot) => sAcc + (slot.isAvailable ? slot.totalCapacity - slot.bookedCount : 0), 0);
  }, 0);

  return (
    <div className="space-y-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-teal-900 via-slate-900 to-slate-950 rounded-2xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-10 -translate-y-10 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-teal-500/20 border border-teal-400/30 rounded-full text-xs font-semibold text-teal-300 mb-3">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              Live Telemetry & OPD Queue Monitoring
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">
              Real-Time Doctor Availability Tracker
            </h2>
            <p className="text-slate-300 text-sm mt-1 max-w-2xl">
              Track live OPD outpatient clinics, remaining consultation seats per specialist, current wait times, and book immediate slots without hospital queue delays.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleManualRefresh}
              className="flex items-center gap-2 px-3.5 py-2 bg-white/10 hover:bg-white/20 rounded-xl text-xs font-medium backdrop-blur-xs transition cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5 text-teal-300" />
              <span>Refreshed: {lastRefreshed}</span>
            </button>
            <button
              onClick={() => setIsLiveSimulating(!isLiveSimulating)}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold transition cursor-pointer ${
                isLiveSimulating
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30'
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
              }`}
            >
              <Zap className={`w-3.5 h-3.5 ${isLiveSimulating ? 'text-emerald-400' : 'text-slate-500'}`} />
              <span>{isLiveSimulating ? 'Live Stream Active' : 'Stream Paused'}</span>
            </button>
          </div>
        </div>

        {/* Live Metrics Ticker Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-800">
          <div className="bg-white/5 p-3 rounded-xl border border-white/5">
            <span className="text-xs text-slate-400 block">Available In-Clinic</span>
            <span className="text-xl font-black text-teal-300">{totalDoctorsAvailableToday} Specialists</span>
          </div>
          <div className="bg-white/5 p-3 rounded-xl border border-white/5">
            <span className="text-xs text-slate-400 block">Total Open Slots Today</span>
            <span className="text-xl font-black text-emerald-300">{totalOpenSlots} Slots</span>
          </div>
          <div className="bg-white/5 p-3 rounded-xl border border-white/5">
            <span className="text-xs text-slate-400 block">Average OPD Triage</span>
            <span className="text-xl font-black text-amber-300">~ 8 Mins</span>
          </div>
          <div className="bg-white/5 p-3 rounded-xl border border-white/5">
            <span className="text-xs text-slate-400 block">Trauma Bay Readiness</span>
            <span className="text-xl font-black text-white">100% Standby</span>
          </div>
        </div>

        {/* Live dynamic broadcast strip */}
        <div className="mt-4 bg-slate-900/90 border border-teal-500/30 rounded-xl px-4 py-2.5 flex items-center gap-3 text-xs text-teal-200">
          <Activity className="w-4 h-4 text-emerald-400 shrink-0 animate-pulse" />
          <span className="font-mono text-emerald-300 truncate">{liveTickerMessage}</span>
        </div>
      </div>

      {/* Filter and Search Toolbar */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search specialist or specialty..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:outline-hidden"
          />
        </div>

        {/* Department Filters */}
        <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 scrollbar-none">
          <button
            onClick={() => setSelectedDept('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
              selectedDept === 'all'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            All Departments ({doctors.length})
          </button>
          {departments.map((dept) => (
            <button
              key={dept.id}
              onClick={() => setSelectedDept(dept.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                selectedDept === dept.id
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {dept.name.split('&')[0]}
            </button>
          ))}
        </div>
      </div>

      {/* Live Doctor Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-4 gap-6">
        {filteredDoctors.map((doctor) => {
          const availableSlotsCount = doctor.slots.reduce(
            (acc, s) => acc + (s.isAvailable ? s.totalCapacity - s.bookedCount : 0),
            0
          );
          const isFillingFast = availableSlotsCount > 0 && availableSlotsCount <= 4;
          const isFull = availableSlotsCount === 0;

          return (
            <div
              key={doctor.id}
              className="bg-white rounded-2xl border border-slate-200 shadow-xs hover:shadow-md transition flex flex-col justify-between overflow-hidden"
            >
              {/* Doctor Head Info */}
              <div className="p-5 border-b border-slate-100">
                <div className="flex items-start gap-4">
                  <div className="relative">
                    <img
                      src={doctor.photoUrl}
                      alt={doctor.name}
                      className="w-16 h-16 rounded-xl object-cover border border-slate-200"
                    />
                    <span
                      className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${
                        doctor.isAvailableToday ? 'bg-emerald-500' : 'bg-slate-400'
                      }`}
                      title={doctor.isAvailableToday ? 'In Hospital Today' : 'Next Available Tomorrow'}
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-teal-700 bg-teal-50 px-2 py-0.5 rounded-md">
                        {doctor.departmentName.split('&')[0]}
                      </span>
                      <span className="text-xs text-amber-600 font-bold flex items-center gap-0.5">
                        ★ {doctor.rating}
                      </span>
                    </div>

                    <h3 className="font-bold text-slate-900 text-base mt-1 truncate">
                      {doctor.name}
                    </h3>
                    <p className="text-xs text-slate-500 truncate">{doctor.title}</p>
                    <p className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      {doctor.opdRoom}
                    </p>
                  </div>
                </div>

                {/* Real-time Status Strip */}
                <div className="mt-4 flex items-center justify-between bg-slate-50 p-2.5 rounded-xl text-xs">
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-slate-500" />
                    <span className="text-slate-600">Current Wait:</span>
                    <span className="font-bold text-slate-900">
                      {doctor.currentWaitTimeMin > 0 ? `${doctor.currentWaitTimeMin} mins` : 'Immediate'}
                    </span>
                  </div>

                  <div>
                    {isFull ? (
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-700">
                        Slots Full Today
                      </span>
                    ) : isFillingFast ? (
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 animate-pulse">
                        Filling Fast ({availableSlotsCount} left)
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        {availableSlotsCount} Slots Open
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Slot Availability Visualizer */}
              <div className="p-5 space-y-3 bg-white">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-700">Today’s Schedule:</span>
                  <span className="text-slate-500 text-[11px]">
                    Next: <strong className="text-teal-700">{doctor.nextAvailableSlot}</strong>
                  </span>
                </div>

                {/* Slot mini buttons */}
                <div className="grid grid-cols-3 gap-1.5 text-center text-xs">
                  {(doctor.slots || []).slice(0, 6).map((slot) => {
                    const remaining = slot.totalCapacity - slot.bookedCount;
                    return (
                      <div
                        key={slot.id}
                        className={`p-1.5 rounded-lg border text-[11px] flex flex-col justify-center items-center transition ${
                          !slot.isAvailable
                            ? 'bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed line-through'
                            : remaining === 1
                            ? 'bg-amber-50 border-amber-300 text-amber-900 font-semibold'
                            : 'bg-teal-50/70 border-teal-200 text-teal-800 font-medium'
                        }`}
                      >
                        <span>{slot.time}</span>
                        <span className="text-[9px] opacity-75">
                          {!slot.isAvailable ? 'Full' : `${remaining} left`}
                        </span>
                      </div>
                    );
                  })}
                </div>

                <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                  <span>Consultation Fee:</span>
                  <span className="font-bold text-slate-900 text-sm">₹{doctor.consultationFee}</span>
                </div>

                {/* Direct Action Button */}
                <button
                  onClick={() => onSelectDoctorForBooking(doctor)}
                  className="w-full mt-2 py-2.5 px-4 bg-teal-600 hover:bg-teal-700 active:scale-98 text-white text-xs font-semibold rounded-xl shadow-xs transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Book Appointment with {doctor.name.split(' ')[1]}</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
