import React, { useState, useRef, useEffect } from 'react';
import { 
  HeartPulse, 
  PhoneCall, 
  CalendarCheck, 
  UserCircle2, 
  Menu, 
  X, 
  Activity, 
  ShieldCheck, 
  LogIn, 
  LogOut, 
  ChevronDown, 
  UserCheck,
  Sun,
  Moon,
  Download,
  Smartphone
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  openEmergencyModal: () => void;
  openInstallModal?: () => void;
  appointmentsCount: number;
  onLogout?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  openEmergencyModal,
  openInstallModal,
  appointmentsCount,
  onLogout,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [downloadNotice, setDownloadNotice] = useState<string | null>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const { currentUser, userProfile, isAdmin, logout, openAuthModal } = useAuth();
  const { theme, isDark, toggleTheme } = useTheme();
  const { triggerDownloadOrInstall } = usePWAInstall();

  const handleDirectDownload = async () => {
    setDownloadNotice('Starting WeCare App download (APK)...');
    try {
      const outcome = await triggerDownloadOrInstall();
      if (outcome === 'installed') {
        setDownloadNotice('WeCare Hospital App installed successfully!');
      } else {
        setDownloadNotice('Download started! Check notifications or Downloads folder.');
      }
    } catch {
      setDownloadNotice('Download initiated (WeCare-Hospital.apk)');
    }
    setTimeout(() => {
      setDownloadNotice(null);
    }, 4500);
  };

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setUserDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'departments', label: 'Departments' },
    { id: 'doctors', label: 'Doctors' },
    { id: 'availability', label: 'Live Availability' },
    { id: 'dashboard', label: 'Patient Dashboard', badge: appointmentsCount > 0 ? appointmentsCount : null },
  ];

  const handleNavClick = (id: string) => {
    if (id === 'dashboard' && !currentUser) {
      setActiveTab('login');
      setMobileMenuOpen(false);
      setUserDropdownOpen(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    setActiveTab(id);
    setMobileMenuOpen(false);
    setUserDropdownOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSignOut = async () => {
    setUserDropdownOpen(false);
    setMobileMenuOpen(false);
    if (onLogout) {
      onLogout();
    } else {
      await logout();
      setActiveTab('login');
    }
  };

  const displayName = userProfile?.name || currentUser?.displayName || currentUser?.email?.split('@')[0] || 'Patient';
  const displayInitial = (displayName.charAt(0) || 'P').toUpperCase();

  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 dark:bg-black/95 shadow-xs border-b border-slate-100 dark:border-neutral-900 backdrop-blur-md transition-colors duration-200">
      {/* Main Navigation Bar */}
      <div className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div 
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-2.5 sm:gap-3 cursor-pointer group shrink-0"
          >
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-tr from-teal-700 to-teal-500 text-white flex items-center justify-center shadow-md shadow-teal-500/20 group-hover:scale-105 transition-transform shrink-0">
              <HeartPulse className="w-6 h-6 sm:w-7 sm:h-7 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1 sm:gap-1.5">
                <span className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 dark:text-white transition-colors">
                  WeCare
                </span>
                <span className="text-xl sm:text-2xl font-light tracking-tight text-teal-600 dark:text-teal-400">
                  Hospital
                </span>
              </div>
              <div className="hidden sm:flex items-center gap-1 text-[10px] text-slate-500 dark:text-slate-400 font-medium tracking-wide uppercase">
                <ShieldCheck className="w-3 h-3 text-teal-600 dark:text-teal-400" />
                NABH & JCI Accredited Healthcare
              </div>
            </div>
          </div>

          {/* Desktop Nav Items */}
          <nav className="hidden lg:flex items-center space-x-1 xl:space-x-2">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-link-${item.id}`}
                  onClick={() => handleNavClick(item.id)}
                  className={`relative px-3.5 py-2 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
                    isActive
                      ? 'text-teal-700 dark:text-teal-300 bg-teal-50/80 dark:bg-teal-950/60 font-bold'
                      : 'text-slate-600 dark:text-slate-300 hover:text-teal-600 dark:hover:text-teal-400 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                  }`}
                >
                  {item.label}
                  {item.badge && (
                    <span className="ml-1.5 inline-flex items-center justify-center px-1.5 py-0.5 text-xs font-bold leading-none text-white bg-teal-600 rounded-full">
                      {item.badge}
                    </span>
                  )}
                  {isActive && (
                    <span className="absolute bottom-0 left-3 right-3 h-0.5 bg-teal-600 dark:bg-teal-400 rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Desktop Actions */}
          <div className="hidden lg:flex items-center gap-3">
            {currentUser ? (
              <div className="relative" ref={dropdownRef}>
                <button
                  id="user-profile-menu-btn"
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-slate-200 dark:border-slate-700 hover:border-teal-300 dark:hover:border-teal-500 bg-slate-50/80 dark:bg-slate-800/80 hover:bg-teal-50/50 dark:hover:bg-slate-800 transition cursor-pointer"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-teal-600 to-teal-800 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                    {displayInitial}
                  </div>
                  <div className="text-left">
                    <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 leading-tight max-w-[110px] truncate">
                      {displayName}
                    </p>
                    <p className={`text-[10px] font-medium ${isAdmin ? 'text-amber-500 font-bold' : 'text-teal-600 dark:text-teal-400'}`}>
                      {isAdmin ? 'Administrator' : 'Patient'}
                    </p>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400 ml-0.5" />
                </button>

                {userDropdownOpen && (
                  <div 
                    id="user-profile-dropdown"
                    className="absolute right-0 mt-2 w-56 bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-100 dark:border-slate-800 py-2 z-50 text-slate-900 dark:text-slate-100 animate-in fade-in zoom-in-95 duration-150"
                  >
                    <div className="px-4 py-2 border-b border-slate-100 dark:border-slate-800">
                      <div className="flex items-center justify-between">
                        <p className="text-xs font-semibold text-slate-900 dark:text-white">{displayName}</p>
                        {isAdmin && (
                          <span className="px-1.5 py-0.2 bg-amber-100 text-amber-800 rounded text-[9px] font-bold uppercase">
                            Admin
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">{currentUser.email}</p>
                    </div>

                    {isAdmin && (
                      <button
                        onClick={() => handleNavClick('admin')}
                        className="w-full px-4 py-2 text-left text-xs font-semibold text-slate-900 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 cursor-pointer transition"
                      >
                        <ShieldCheck className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                        <span>Hospital Admin Portal</span>
                      </button>
                    )}

                    <button
                      onClick={() => handleNavClick('dashboard')}
                      className="w-full px-4 py-2 text-left text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-teal-50 dark:hover:bg-slate-800 hover:text-teal-700 dark:hover:text-teal-300 flex items-center gap-2 cursor-pointer transition"
                    >
                      <UserCircle2 className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                      <span>My Patient Dashboard</span>
                    </button>

                    <button
                      onClick={() => handleNavClick('booking')}
                      className="w-full px-4 py-2 text-left text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-teal-50 dark:hover:bg-slate-800 hover:text-teal-700 dark:hover:text-teal-300 flex items-center gap-2 cursor-pointer transition"
                    >
                      <CalendarCheck className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                      <span>Book Appointment</span>
                    </button>

                    <div className="border-t border-slate-100 dark:border-slate-800 my-1"></div>

                    <button
                      id="btn-logout"
                      onClick={handleSignOut}
                      className="w-full px-4 py-2 text-left text-xs font-medium text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 flex items-center gap-2 cursor-pointer transition"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  id="header-signin-btn"
                  onClick={() => handleNavClick('login')}
                  className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-semibold text-teal-700 dark:text-teal-300 hover:text-teal-800 dark:hover:text-teal-200 bg-teal-50 dark:bg-teal-950/60 hover:bg-teal-100/80 dark:hover:bg-teal-900/60 rounded-lg transition cursor-pointer border border-teal-200/60 dark:border-teal-800"
                >
                  <LogIn className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                  <span>Sign In</span>
                </button>
              </div>
            )}

            {/* Admin Portal Quick Pill if logged in as Admin */}
            {isAdmin && (
              <button
                onClick={() => handleNavClick('admin')}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold transition cursor-pointer shadow-xs ${
                  activeTab === 'admin'
                    ? 'bg-slate-900 text-teal-300 border border-teal-500/50'
                    : 'bg-slate-800 hover:bg-slate-900 text-white'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5 text-teal-400" />
                <span>Admin Portal</span>
              </button>
            )}

            {/* Global Dark Mode Desktop Toggle */}
            <button
              type="button"
              id="theme-toggle-desktop-btn"
              onClick={toggleTheme}
              aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
              title={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
              className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-amber-400 hover:text-slate-900 dark:hover:text-amber-300 hover:bg-slate-100 dark:hover:bg-slate-700/80 transition-all cursor-pointer shadow-2xs hover:scale-105 active:scale-95 flex items-center justify-center"
            >
              {isDark ? (
                <Sun className="w-4 h-4 transition-transform duration-300 hover:rotate-45" />
              ) : (
                <Moon className="w-4 h-4 transition-transform duration-300 hover:-rotate-12" />
              )}
            </button>

            {/* Small Download App Symbol Button */}
            <button
              type="button"
              id="navbar-download-app-btn"
              onClick={handleDirectDownload}
              title="Download WeCare Hospital App (APK)"
              aria-label="Download WeCare Hospital App APK"
              className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-teal-600 dark:text-teal-400 hover:text-teal-700 dark:hover:text-teal-300 hover:bg-teal-50/80 dark:hover:bg-slate-700/80 transition-all cursor-pointer shadow-2xs hover:scale-105 active:scale-95 flex items-center justify-center group"
            >
              <Download className="w-4 h-4 transition-transform duration-300 group-hover:translate-y-0.5" />
            </button>

            <button
              id="main-book-appointment-btn"
              onClick={() => handleNavClick('booking')}
              className="flex items-center gap-2 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-sm px-5 py-2.5 rounded-lg shadow-sm hover:shadow-teal-600/20 transition-all cursor-pointer active:scale-95"
            >
              <CalendarCheck className="w-4 h-4" />
              <span>Book Appointment</span>
            </button>
          </div>

          {/* Mobile Menu & Quick Actions Header */}
          <div className="flex lg:hidden items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Quick Book Pill on xs/sm devices */}
            <button
              id="mobile-quick-book-btn"
              onClick={() => handleNavClick('booking')}
              className="hidden xs:flex items-center gap-1 px-2.5 py-1.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-lg shadow-2xs transition active:scale-95 cursor-pointer shrink-0"
            >
              <CalendarCheck className="w-3.5 h-3.5" />
              <span>Book</span>
            </button>

            {/* Small Mobile Download App Symbol Button */}
            <button
              type="button"
              id="navbar-download-mobile-header"
              onClick={handleDirectDownload}
              aria-label="Download WeCare Hospital App (APK)"
              title="Download WeCare Hospital App (APK)"
              className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-teal-600 dark:text-teal-400 hover:bg-teal-50 dark:hover:bg-slate-700 transition cursor-pointer active:scale-95 shadow-2xs shrink-0"
            >
              <Download className="w-4 h-4" />
            </button>

            {/* Mobile Header Dark Mode Button */}
            <button
              type="button"
              id="theme-toggle-mobile-header"
              onClick={toggleTheme}
              aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
              title={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
              className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-amber-400 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer shadow-2xs shrink-0"
            >
              {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Prominent Three-Lines Hamburger Menu Button */}
            <button
              id="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl bg-teal-50 dark:bg-slate-800 text-teal-700 dark:text-teal-300 hover:bg-teal-100 dark:hover:bg-slate-700 border border-teal-200/90 dark:border-slate-700 shadow-2xs transition-all cursor-pointer flex items-center justify-center shrink-0 active:scale-95"
              aria-label="Toggle navigation menu"
              title="Open Navigation Menu"
            >
              {mobileMenuOpen ? (
                <X className="w-5 h-5 text-rose-600 dark:text-rose-400" />
              ) : (
                <Menu className="w-5 h-5 text-teal-700 dark:text-teal-300 stroke-[2.5]" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 px-4 pt-3 pb-6 space-y-3 shadow-xl animate-in slide-in-from-top-2 duration-200">
          {currentUser ? (
            <div className="p-3 bg-teal-50/70 dark:bg-teal-950/40 rounded-xl border border-teal-100 dark:border-teal-900/60 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-full bg-teal-600 text-white flex items-center justify-center font-bold text-sm">
                  {displayInitial}
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-900 dark:text-white">{displayName}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 truncate max-w-[180px]">{currentUser.email}</p>
                </div>
              </div>
              <button
                onClick={handleSignOut}
                className="p-2 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition cursor-pointer"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/60 dark:border-slate-700 flex items-center justify-between">
              <div>
                <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">WeCare Patient Account</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">Sign in to sync your bookings</p>
              </div>
              <button
                onClick={() => handleNavClick('login')}
                className="px-3 py-1.5 bg-teal-600 text-white rounded-lg text-xs font-semibold shadow-xs cursor-pointer"
              >
                Sign In
              </button>
            </div>
          )}

          {/* Color Mode Switcher Row */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/60 dark:border-slate-700/80 flex items-center justify-between">
            <div className="flex items-center gap-2 text-slate-800 dark:text-slate-200 text-xs font-semibold">
              {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600 dark:text-slate-400" />}
              <span>Theme Appearance</span>
            </div>
            <button
              type="button"
              onClick={toggleTheme}
              className="px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-100 cursor-pointer shadow-2xs"
            >
              <span>{isDark ? 'Light Mode' : 'Dark Mode'}</span>
            </button>
          </div>

          {/* Download App Row in Mobile Menu */}
          <div className="p-3 bg-teal-50/80 dark:bg-teal-950/40 rounded-xl border border-teal-200/70 dark:border-teal-900/60 flex items-center justify-between">
            <div className="flex items-center gap-2.5 text-xs">
              <div className="w-8 h-8 rounded-lg bg-teal-600 text-white flex items-center justify-center shrink-0">
                <Smartphone className="w-4 h-4" />
              </div>
              <div>
                <p className="font-bold text-slate-900 dark:text-white leading-tight">WeCare Mobile App</p>
                <p className="text-[11px] text-teal-700 dark:text-teal-300">Android APK & WebAPK</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                handleDirectDownload();
              }}
              className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-lg transition shadow-xs cursor-pointer flex items-center gap-1 active:scale-95"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download</span>
            </button>
          </div>

          <div className="grid grid-cols-1 gap-1">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-semibold transition cursor-pointer ${
                    isActive
                      ? 'bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className="px-2 py-0.5 text-xs font-bold rounded-full bg-teal-600 text-white">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}

            {/* Mobile Admin Portal Link (Admin Only) */}
            {isAdmin && (
              <button
                onClick={() => handleNavClick('admin')}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-semibold transition cursor-pointer ${
                  activeTab === 'admin'
                    ? 'bg-slate-900 text-teal-300 font-bold'
                    : 'text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                  <span>Admin Portal</span>
                </div>
                <span className="px-1.5 py-0.5 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 text-[10px] font-bold rounded">
                  Staff
                </span>
              </button>
            )}
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-col gap-2">
            <button
              onClick={() => handleNavClick('booking')}
              className="w-full flex items-center justify-center gap-2 bg-teal-600 hover:bg-teal-700 text-white font-semibold py-3 rounded-lg text-sm shadow-xs transition cursor-pointer"
            >
              <CalendarCheck className="w-4 h-4" />
              <span>Book Doctor Appointment</span>
            </button>
            <button
              onClick={openEmergencyModal}
              className="w-full flex items-center justify-center gap-2 bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-900/60 font-semibold py-2.5 rounded-lg text-sm transition cursor-pointer"
            >
              <PhoneCall className="w-4 h-4 text-rose-600" />
              <span>24/7 Emergency SOS Line</span>
            </button>
          </div>
        </div>
      )}

      {/* Instant Download Alert Toast */}
      {downloadNotice && (
        <div className="fixed top-22 right-4 sm:right-8 z-50 animate-in slide-in-from-top-3 fade-in duration-200">
          <div className="bg-slate-900/95 dark:bg-slate-800 text-white px-4 py-2.5 rounded-2xl shadow-2xl border border-teal-500/40 text-xs flex items-center gap-2.5 backdrop-blur-md">
            <span className="w-2 h-2 rounded-full bg-teal-400 animate-ping shrink-0" />
            <span className="font-semibold text-slate-100">{downloadNotice}</span>
            {openInstallModal && (
              <button 
                type="button" 
                onClick={openInstallModal}
                className="text-[11px] font-bold text-teal-300 hover:text-teal-200 underline ml-1 cursor-pointer"
              >
                Help
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
