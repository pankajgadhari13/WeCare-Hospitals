import React, { createContext, useContext, useState, useEffect, useRef, ReactNode } from 'react';
import { 
  auth, 
  googleProvider,
  signInWithPopup, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  updateProfile,
  onAuthStateChanged,
  FirebaseUser 
} from '../lib/firebase';
import { PatientProfile } from '../types';
import { getUserProfile, saveUserProfile, findUserByPhone } from '../services/userService';

export interface RegisterResult {
  success: boolean;
  message: string;
}

export const ADMIN_EMAILS = [
  'pankajgadhari123@gmail.com',
  'pankajgadhari154@gmail.com',
  'admin@wecarehospitals.org',
  'admin@wecare.hospital'
];
export const ADMIN_EMAIL = 'pankajgadhari123@gmail.com';
export const ADMIN_DEFAULT_PASSWORD = 'Pass@123';

interface AuthContextType {
  currentUser: FirebaseUser | null;
  userProfile: PatientProfile | null;
  isAdmin: boolean;
  loading: boolean;
  authModalOpen: boolean;
  authModalReason: string;
  openAuthModal: (reason?: string, onComplete?: () => void) => void;
  closeAuthModal: () => void;
  signInWithEmail: (email: string, pass: string) => Promise<void>;
  signInWithEmailOrPhone: (identifier: string, pass: string) => Promise<void>;
  signInWithDemoPatient: () => Promise<void>;
  signInWithAdmin: () => Promise<void>;
  signUpWithEmail: (
    email: string, 
    pass: string, 
    details: {
      name: string;
      phone: string;
      age?: number;
      gender?: string;
      bloodGroup?: string;
    }
  ) => Promise<RegisterResult>;
  signInWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  updateProfileData: (data: Partial<PatientProfile>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<PatientProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalReason, setAuthModalReason] = useState('Sign in to access your WeCare healthcare portal');
  const [onAuthSuccessCallback, setOnAuthSuccessCallback] = useState<(() => void) | null>(null);

  // Ref to suppress automatic login when registering a new patient
  const isRegisteringRef = useRef(false);

  const defaultProfile = (user: FirebaseUser): PatientProfile => ({
    id: user.uid,
    uid: user.uid,
    name: user.displayName || 'Patient',
    email: user.email || '',
    phone: user.phoneNumber || '+91 98220 12345',
    age: 32,
    gender: 'other',
    bloodGroup: 'O+',
    emergencyContact: {
      name: 'Emergency Contact',
      relation: 'Family',
      phone: '+91 98220 99999',
    },
    vitals: {
      bloodPressure: '120/80',
      heartRate: 72,
      oxygenSaturation: 98,
      bloodSugar: 95,
      weightKg: 68,
      lastUpdated: 'Just now',
    },
    allergies: ['None recorded'],
    chronicConditions: ['None'],
  });

  // Listen to Firebase Auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      // If currently executing registration, suppress auto-login
      if (isRegisteringRef.current) {
        setLoading(false);
        return;
      }

      setCurrentUser(user);
      if (user) {
        try {
          const isCurrentAdmin = ADMIN_EMAILS.some((e) => e.toLowerCase() === user.email?.toLowerCase());
          const profile = await getUserProfile(user.uid);
          if (profile) {
            if (isCurrentAdmin && profile.role !== 'admin') {
              profile.role = 'admin';
              await saveUserProfile(profile);
            }
            setUserProfile(profile);
          } else {
            const newProf = defaultProfile(user);
            if (isCurrentAdmin) {
              newProf.role = 'admin';
              newProf.name = 'Dr. Pankaj Gadhari (Admin)';
            }
            await saveUserProfile(newProf);
            setUserProfile(newProf);
          }
        } catch (err) {
          console.warn('Error loading patient profile:', err);
          const fallback = defaultProfile(user);
          if (ADMIN_EMAILS.some((e) => e.toLowerCase() === user.email?.toLowerCase())) {
            fallback.role = 'admin';
            fallback.name = 'Dr. Pankaj Gadhari (Admin)';
          }
          setUserProfile(fallback);
        }
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const openAuthModal = (reason?: string, onComplete?: () => void) => {
    if (reason) setAuthModalReason(reason);
    if (onComplete) setOnAuthSuccessCallback(() => onComplete);
    setAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setAuthModalOpen(false);
    setOnAuthSuccessCallback(null);
  };

  const executeSuccessCallback = () => {
    if (onAuthSuccessCallback) {
      const cb = onAuthSuccessCallback;
      setOnAuthSuccessCallback(null);
      cb();
    }
  };

  const signInWithEmail = async (email: string, pass: string) => {
    const trimmedEmail = email.trim();
    if (!trimmedEmail || !pass) {
      throw new Error('Invalid email/phone or password.');
    }

    try {
      await signInWithEmailAndPassword(auth, trimmedEmail, pass);
      closeAuthModal();
      executeSuccessCallback();
    } catch (err: any) {
      // If demo account credentials and user is not found or credential invalid in fresh Firebase, auto-provision
      const isDemo =
        trimmedEmail.toLowerCase() === 'patient@wecare.hospital' ||
        trimmedEmail.toLowerCase() === 'demo@wecare.hospital';

      if (
        isDemo &&
        (err?.code === 'auth/invalid-credential' ||
          err?.code === 'auth/user-not-found' ||
          err?.code === 'auth/wrong-password')
      ) {
        try {
          const cred = await createUserWithEmailAndPassword(auth, trimmedEmail, pass);
          if (cred.user) {
            await updateProfile(cred.user, { displayName: 'Rahul Deshmukh' });
            const demoProf: PatientProfile = {
              id: cred.user.uid,
              uid: cred.user.uid,
              name: 'Rahul Deshmukh',
              email: trimmedEmail,
              phone: '+91 98220 12345',
              age: 46,
              gender: 'male',
              bloodGroup: 'B+',
              emergencyContact: {
                name: 'Snehal Deshmukh',
                relation: 'Spouse',
                phone: '+91 98220 54321',
              },
              vitals: {
                bloodPressure: '118/76',
                heartRate: 72,
                oxygenSaturation: 99,
                bloodSugar: 94,
                weightKg: 74,
                lastUpdated: 'Just now',
              },
              allergies: ['Penicillin'],
              chronicConditions: ['Mild Hypertension'],
            };
            await saveUserProfile(demoProf);
            setUserProfile(demoProf);
          }
          closeAuthModal();
          executeSuccessCallback();
          return;
        } catch {
          // If creation fails, proceed to standard error
        }
      }

      // If admin credentials and user is not registered in Firebase Auth yet, auto-provision
      const isAdminAttempt =
        ADMIN_EMAILS.some((e) => e.toLowerCase() === trimmedEmail.toLowerCase()) &&
        pass === ADMIN_DEFAULT_PASSWORD;

      if (
        isAdminAttempt &&
        (err?.code === 'auth/invalid-credential' ||
          err?.code === 'auth/user-not-found' ||
          err?.code === 'auth/wrong-password')
      ) {
        try {
          const cred = await createUserWithEmailAndPassword(auth, trimmedEmail, pass);
          if (cred.user) {
            await updateProfile(cred.user, { displayName: 'Hospital Administrator' });
            const adminProf: PatientProfile = {
              id: cred.user.uid,
              uid: cred.user.uid,
              role: 'admin',
              name: 'Dr. Pankaj Gadhari (Admin)',
              email: trimmedEmail,
              phone: '+91 257 222 5500',
              age: 38,
              gender: 'male',
              bloodGroup: 'O+',
              emergencyContact: {
                name: 'Hospital Administration Directorate',
                relation: 'Staff',
                phone: '+91 257 222 5501',
              },
              vitals: {
                bloodPressure: '120/80',
                heartRate: 72,
                oxygenSaturation: 99,
                bloodSugar: 92,
                weightKg: 75,
                lastUpdated: 'Admin Online',
              },
              allergies: [],
              chronicConditions: [],
            };
            await saveUserProfile(adminProf);
            setUserProfile(adminProf);
          }
          closeAuthModal();
          executeSuccessCallback();
          return;
        } catch (adminErr) {
          console.warn('Admin user auto-creation error:', adminErr);
        }
      }

      // Exact user requirement: "If the user enters incorrect credentials, show: Invalid email/phone or password."
      throw new Error('Invalid email/phone or password.');
    }
  };

  const signInWithEmailOrPhone = async (identifier: string, pass: string) => {
    const trimmed = identifier.trim();
    if (!trimmed || !pass) {
      throw new Error('Invalid email/phone or password.');
    }

    if (trimmed.includes('@')) {
      return signInWithEmail(trimmed, pass);
    }

    // Phone number lookup
    const profile = await findUserByPhone(trimmed);
    if (!profile || !profile.email) {
      throw new Error('Invalid email/phone or password.');
    }

    return signInWithEmail(profile.email, pass);
  };

  const signInWithDemoPatient = async () => {
    const demoEmail = 'patient@wecare.hospital';
    const demoPass = 'wecare2026!';
    await signInWithEmail(demoEmail, demoPass);
  };

  const signInWithAdmin = async () => {
    await signInWithEmail(ADMIN_EMAIL, ADMIN_DEFAULT_PASSWORD);
  };

  /**
   * Registration requirement:
   * 1. Create account successfully
   * 2. Show: "Registration successful. Please login to continue."
   * 3. Redirect user to Login page
   * 4. Do NOT automatically log the newly registered user into the dashboard
   * 5. Do NOT create an authenticated session/token after registration
   * 6. The user must manually enter their registered email/phone and password on the Login page
   */
  const signUpWithEmail = async (
    email: string, 
    pass: string, 
    details: {
      name: string;
      phone: string;
      age?: number;
      gender?: string;
      bloodGroup?: string;
    }
  ): Promise<RegisterResult> => {
    const trimmedEmail = email.trim();
    isRegisteringRef.current = true;

    try {
      const cred = await createUserWithEmailAndPassword(auth, trimmedEmail, pass);
      if (cred.user) {
        await updateProfile(cred.user, { displayName: details.name.trim() });
        const newProf: PatientProfile = {
          id: cred.user.uid,
          uid: cred.user.uid,
          name: details.name.trim(),
          email: trimmedEmail,
          phone: details.phone.trim() || '+91 98220 12345',
          age: Number(details.age) || 30,
          gender: (details.gender as any) || 'other',
          bloodGroup: details.bloodGroup || 'O+',
          emergencyContact: {
            name: 'Emergency Contact',
            relation: 'Family',
            phone: details.phone.trim() || '+91 98220 99999',
          },
          vitals: {
            bloodPressure: '120/80',
            heartRate: 72,
            oxygenSaturation: 98,
            bloodSugar: 95,
            weightKg: 68,
            lastUpdated: 'Account created',
          },
          allergies: ['None recorded'],
          chronicConditions: ['None'],
        };
        await saveUserProfile(newProf);

        // Terminate authenticated session immediately - DO NOT auto log in
        await signOut(auth);
      }

      // Explicitly clear any session/local state
      setCurrentUser(null);
      setUserProfile(null);
      try {
        localStorage.removeItem('wecare_appointments');
        localStorage.removeItem('wecare_patient_profile');
        localStorage.removeItem('wecare_auth_token');
        sessionStorage.clear();
      } catch {}

      return {
        success: true,
        message: 'Registration successful. Please login to continue.',
      };
    } catch (err: any) {
      if (err?.code === 'auth/email-already-in-use') {
        throw new Error('An account with this email already exists. Please login instead.');
      }
      if (err?.code === 'auth/weak-password') {
        throw new Error('Password should be at least 6 characters.');
      }
      throw err;
    } finally {
      isRegisteringRef.current = false;
      setCurrentUser(null);
      setUserProfile(null);
    }
  };

  const signInWithGoogle = async () => {
    const result = await signInWithPopup(auth, googleProvider);
    if (result.user) {
      const existing = await getUserProfile(result.user.uid);
      if (!existing) {
        const newProf = defaultProfile(result.user);
        await saveUserProfile(newProf);
        setUserProfile(newProf);
      }
    }
    closeAuthModal();
    executeSuccessCallback();
  };

  /**
   * Logout requirement:
   * 1. Completely terminate the authenticated session
   * 2. Clear/remove the authentication token/session from local storage, session storage, cookies
   * 3. Clear cached logged-in patient information from frontend state
   * 4. Clear the previous user's dashboard data from application state
   * 5. Redirect immediately to the Login page
   * 6. Previous user's data must NOT remain pre-filled on login page
   * 7. Login fields must be completely reset after logout
   * 8. Browser back button must NOT allow access to dashboard
   */
  const logout = async () => {
    try {
      await signOut(auth);
    } catch (e) {
      console.warn('Firebase signOut error:', e);
    }

    setCurrentUser(null);
    setUserProfile(null);

    // Thorough storage cleanup
    try {
      const keys = [
        'wecare_appointments',
        'wecare_patient_profile',
        'wecare_medical_records',
        'wecare_prescriptions',
        'wecare_auth_token',
        'wecare_user_id',
        'wecare_last_user',
      ];
      keys.forEach((k) => localStorage.removeItem(k));
      Object.keys(localStorage).forEach((k) => {
        if (k.startsWith('wecare_')) {
          localStorage.removeItem(k);
        }
      });
      sessionStorage.clear();
    } catch (e) {
      console.warn('Storage cleanup error:', e);
    }
  };

  const updateProfileData = async (data: Partial<PatientProfile>) => {
    if (!userProfile || !currentUser) return;
    const updated: PatientProfile = {
      ...userProfile,
      ...data,
      uid: currentUser.uid,
      id: currentUser.uid,
    };
    setUserProfile(updated);
    await saveUserProfile(updated);
  };

  const isAdmin = Boolean(
    currentUser && (
      ADMIN_EMAILS.some((e) => e.toLowerCase() === currentUser.email?.toLowerCase()) ||
      userProfile?.role === 'admin'
    )
  );

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        isAdmin,
        loading,
        authModalOpen,
        authModalReason,
        openAuthModal,
        closeAuthModal,
        signInWithEmail,
        signInWithEmailOrPhone,
        signInWithDemoPatient,
        signInWithAdmin,
        signUpWithEmail,
        signInWithGoogle,
        logout,
        updateProfileData,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
