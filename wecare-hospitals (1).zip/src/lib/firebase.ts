import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  GoogleAuthProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  updateProfile,
  onAuthStateChanged,
  User as FirebaseUser
} from 'firebase/auth';
import { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy, 
  onSnapshot,
  addDoc,
  serverTimestamp,
  Timestamp
} from 'firebase/firestore';

// Web app's Firebase configuration provided by user
export const firebaseConfig = {
  apiKey: "AIzaSyB7YKpc6ZuXxUGTOB0glM8wPe5zfsGg1BU",
  authDomain: "wecare-hospitals-b72ec.firebaseapp.com",
  projectId: "wecare-hospitals-b72ec",
  storageBucket: "wecare-hospitals-b72ec.firebasestorage.app",
  messagingSenderId: "1087956838972",
  appId: "1:1087956838972:web:423336381a10ac38963139"
};

// Initialize Firebase singleton
export const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);
export const db = getFirestore(app);

export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

// Operation Types for error handling
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | null;
    email: string | null;
    isAuthenticated: boolean;
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null = null
): never {
  const err = error as { code?: string; message?: string };
  const authInfo = {
    userId: auth.currentUser ? auth.currentUser.uid : null,
    email: auth.currentUser ? auth.currentUser.email : null,
    isAuthenticated: !!auth.currentUser,
  };

  const errorInfo: FirestoreErrorInfo = {
    error: err?.message || String(error),
    operationType,
    path,
    authInfo,
  };

  console.error('[Firestore Error]', JSON.stringify(errorInfo, null, 2));
  throw new Error(JSON.stringify(errorInfo));
}

export {
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  updateProfile,
  onAuthStateChanged,
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  addDoc,
  serverTimestamp,
  Timestamp
};
export type { FirebaseUser };
