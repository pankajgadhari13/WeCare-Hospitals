import React from 'react';
import { 
  ShieldCheck, 
  Award, 
  HeartHandshake, 
  Microscope, 
  Activity, 
  Clock, 
  Users, 
  CheckCircle2, 
  Building, 
  CalendarCheck,
  ChevronRight
} from 'lucide-react';
import { HOSPITAL_STATS } from '../data/hospitalData';

interface AboutPageProps {
  setActiveTab: (tab: string) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ setActiveTab }) => {
  return (
    <div className="space-y-16 pb-16">
      {/* Hero Banner */}
      <section className="bg-gradient-to-r from-teal-900 via-slate-900 to-slate-950 text-white py-16 sm:py-20 relative overflow-hidden">
        <div className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16 relative z-10">
          <div className="max-w-3xl space-y-4">
            <span className="px-3 py-1 bg-teal-500/20 text-teal-300 border border-teal-400/30 rounded-full text-xs font-semibold uppercase tracking-wider inline-block">
              About WeCare Hospital
            </span>
            <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight">
              Two Decades of Clinical Innovation & Compassionate Healing
            </h1>
            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              Founded on the belief that world-class healthcare should be transparent, accessible, and grounded in human empathy, WeCare Hospital has grown into one of the nation’s most trusted quaternary care destinations.
            </p>
          </div>
        </div>
      </section>

      {/* Stats Ribbon */}
      <section className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16 -mt-8">
        <div className="bg-white rounded-2xl border border-slate-200 shadow-md p-6 sm:p-8 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 text-center">
          {HOSPITAL_STATS.map((stat, i) => (
            <div key={i} className="space-y-1">
              <span className="text-2xl sm:text-3xl font-black text-teal-700 block">
                {stat.value}
              </span>
              <span className="text-xs font-semibold text-slate-600">
                {stat.label}
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* Mission & Vision Section */}
      <section className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-xs space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center">
              <HeartHandshake className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900">Our Mission</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              To deliver uncompromising, evidence-based quaternary clinical care that combines medical ingenuity with gentle compassion, restoring health and hope to every patient who walks through our doors.
            </p>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-xs space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center">
              <Microscope className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900">Our Vision</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              To serve as the global benchmark for patient safety, robotic surgical precision, biomedical research, and digital healthcare access across the continent.
            </p>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-xs space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900">Core Values</h3>
            <ul className="text-sm text-slate-600 space-y-2">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-600" />
                <span><strong>Clinical Integrity:</strong> Purely evidence-driven treatments</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-600" />
                <span><strong>Patient Centricity:</strong> Dignity, comfort & transparency</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-600" />
                <span><strong>Continuous Learning:</strong> Academic research & robotics</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* Advanced Infrastructure */}
      <section className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16">
        <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 overflow-hidden relative">
          <div className="max-w-2xl space-y-4 relative z-10">
            <span className="text-xs font-bold uppercase tracking-wider text-teal-400">
              World-Class Facilities
            </span>
            <h2 className="text-2xl sm:text-4xl font-bold tracking-tight">
              Pioneering Medical Technology
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              WeCare Hospital invests continually in advanced diagnostic equipment, hybrid operation theatres, and ultra-sterile clinical environments to ensure optimal surgical outcomes.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8 relative z-10">
            <div className="bg-slate-800/80 p-5 rounded-2xl border border-slate-700">
              <h4 className="font-bold text-base text-white">Mako & DaVinci Robotics</h4>
              <p className="text-xs text-slate-400 mt-2">
                Sub-millimeter accuracy for joint replacements, complex urology, and oncologic tumor extractions.
              </p>
            </div>
            <div className="bg-slate-800/80 p-5 rounded-2xl border border-slate-700">
              <h4 className="font-bold text-base text-white">3-Tesla Digital MRI & CT</h4>
              <p className="text-xs text-slate-400 mt-2">
                Ultra-fast scan times with high spatial resolution for precise neurological and cardiac diagnoses.
              </p>
            </div>
            <div className="bg-slate-800/80 p-5 rounded-2xl border border-slate-700">
              <h4 className="font-bold text-base text-white">Level-III NICU & PICU</h4>
              <p className="text-xs text-slate-400 mt-2">
                Round-the-clock intensive care for micro-preemies and critically ill infants with nitric oxide therapy.
              </p>
            </div>
            <div className="bg-slate-800/80 p-5 rounded-2xl border border-slate-700">
              <h4 className="font-bold text-base text-white">HEPA Laminar Flow OTs</h4>
              <p className="text-xs text-slate-400 mt-2">
                Class-100 positive air pressure surgical suites minimizing post-operative surgical site infections to 0.12%.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Hospital Leadership & Governance */}
      <section className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-bold text-teal-700 uppercase tracking-wider">
            Hospital Leadership
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mt-1">
            Governed by Renowned Physicians
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            Our governing medical council consists of active clinicians and international healthcare executives.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 text-center shadow-xs">
            <img
              src="https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=400&q=80"
              alt="Dr. Rajesh Sharma"
              className="w-24 h-24 rounded-full object-cover mx-auto mb-4 border-2 border-teal-600"
            />
            <h4 className="font-bold text-base text-slate-900">Dr. Rajesh Sharma, MD, DM, FACC</h4>
            <p className="text-xs font-semibold text-teal-700">Chief Medical Officer</p>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Leading interventional cardiologist with 22+ years overseeing clinical governance, patient safety, and cardiac cath lab benchmarks.
            </p>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-6 text-center shadow-xs">
            <img
              src="/doctors/doc-soumya.jpg"
              alt="Dr. Sunita Kulkarni"
              className="w-24 h-24 rounded-full object-cover mx-auto mb-4 border-2 border-teal-600"
            />
            <h4 className="font-bold text-base text-slate-900">Dr. Sunita Kulkarni, MD, DM</h4>
            <p className="text-xs font-semibold text-teal-700">Director of Academic Medicine & Research</p>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Pioneering researcher in neuro-vascular stroke interventions, DNB residency training, and evidence-based protocols.
            </p>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-6 text-center shadow-xs">
            <img
              src="https://images.unsplash.com/photo-1622902046580-2b47f47f5471?auto=format&fit=crop&w=400&q=80"
              alt="Dr. Arvind Patil"
              className="w-24 h-24 rounded-full object-cover mx-auto mb-4 border-2 border-teal-600"
            />
            <h4 className="font-bold text-base text-slate-900">Dr. Arvind Patil, MS, DNB (Ortho)</h4>
            <p className="text-xs font-semibold text-teal-700">Chairman of Surgical Operations</p>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Veteran robotic joint replacement surgeon supervising OT sterility protocols, surgical NABH audits, and modern theater safety.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Box */}
      <section className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16">
        <div className="bg-gradient-to-r from-teal-700 to-emerald-700 text-white rounded-3xl p-8 sm:p-10 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl">
          <div>
            <h3 className="text-2xl font-bold">Experience Healthcare You Can Trust</h3>
            <p className="text-sm text-teal-100 mt-1">
              Schedule a consultation with our specialists or explore our comprehensive clinical departments.
            </p>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setActiveTab('departments')}
              className="px-5 py-3 bg-white text-teal-800 font-bold text-xs rounded-xl shadow-xs transition hover:bg-teal-50 cursor-pointer"
            >
              Explore Departments
            </button>
            <button
              onClick={() => setActiveTab('booking')}
              className="px-5 py-3 bg-teal-900 hover:bg-teal-950 text-white font-bold text-xs rounded-xl transition cursor-pointer"
            >
              Book Appointment
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
