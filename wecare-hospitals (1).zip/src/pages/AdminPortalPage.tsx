import React, { useState, useEffect, useMemo } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Search, 
  Filter, 
  Calendar, 
  Clock, 
  User, 
  Phone, 
  Mail, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Plus, 
  Printer, 
  Download, 
  RefreshCw, 
  ChevronDown, 
  MapPin, 
  IndianRupee, 
  Activity, 
  SlidersHorizontal,
  Building2,
  Trash2,
  Edit3,
  CalendarDays,
  FileSpreadsheet,
  LogOut,
  Stethoscope,
  Eye,
  EyeOff,
  Sparkles,
  ArrowUpDown
} from 'lucide-react';
import { Appointment, Doctor, Department } from '../types';
import { useAuth, ADMIN_EMAIL, ADMIN_DEFAULT_PASSWORD } from '../context/AuthContext';
import { 
  subscribeToAllAppointments, 
  saveAppointmentToFirestore, 
  adminUpdateAppointment, 
  deleteAppointmentInFirestore 
} from '../services/appointmentService';
import { INITIAL_APPOINTMENTS } from '../data/hospitalData';

interface AdminPortalPageProps {
  doctors: Doctor[];
  departments: Department[];
  onOpenAppointmentPass: (apt: Appointment) => void;
  setActiveTab: (tab: string) => void;
}

export const AdminPortalPage: React.FC<AdminPortalPageProps> = ({
  doctors,
  departments,
  onOpenAppointmentPass,
  setActiveTab,
}) => {
  const { currentUser, userProfile, isAdmin, signInWithEmail, logout } = useAuth();

  // Admin Login State
  const [adminEmailInput, setAdminEmailInput] = useState('');
  const [adminPasswordInput, setAdminPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginLoading, setLoginLoading] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  // Appointments state
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loadingApts, setLoadingApts] = useState(true);
  const [syncing, setSyncing] = useState(false);

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'confirmed' | 'completed' | 'rescheduled' | 'cancelled'>('all');
  const [deptFilter, setDeptFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'tomorrow' | 'upcoming' | 'past'>('all');
  const [paymentFilter, setPaymentFilter] = useState<'all' | 'online-paid' | 'hospital-counter'>('all');
  const [sortOrder, setSortOrder] = useState<'newest' | 'date-asc' | 'patient'>('newest');

  // Modals & Drawers
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [rescheduleApt, setRescheduleApt] = useState<Appointment | null>(null);
  const [newRescheduleDate, setNewRescheduleDate] = useState('');
  const [newRescheduleSlot, setNewRescheduleSlot] = useState('');
  const [newReschedulePeriod, setNewReschedulePeriod] = useState<'morning' | 'afternoon' | 'evening'>('morning');
  const [editNotesApt, setEditNotesApt] = useState<Appointment | null>(null);
  const [editedNotes, setEditedNotes] = useState('');
  const [editedRoom, setEditedRoom] = useState('');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [isDeletingApt, setIsDeletingApt] = useState(false);

  // New Booking Form State (Admin End)
  const [newDeptId, setNewDeptId] = useState<string>(departments[0]?.id || 'cardiology');
  const [newDoctorId, setNewDoctorId] = useState<string>('');
  const [newDate, setNewDate] = useState<string>(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });
  const [newTimeSlot, setNewTimeSlot] = useState<string>('09:30 AM');
  const [newPeriod, setNewPeriod] = useState<'morning' | 'afternoon' | 'evening'>('morning');
  const [newConsultationType, setNewConsultationType] = useState<'in-person' | 'video'>('in-person');
  const [newPaymentMode, setNewPaymentMode] = useState<'hospital-counter' | 'online-paid'>('hospital-counter');
  const [newPatientName, setNewPatientName] = useState('');
  const [newPatientPhone, setNewPatientPhone] = useState('');
  const [newPatientEmail, setNewPatientEmail] = useState('');
  const [newPatientAge, setNewPatientAge] = useState<number>(35);
  const [newPatientGender, setNewPatientGender] = useState<'male' | 'female' | 'other'>('female');
  const [newReason, setNewReason] = useState('');
  const [newNotes, setNewNotes] = useState('Admin/Walk-in registered');
  const [formError, setFormError] = useState<string | null>(null);
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Doctors available for the selected department
  const filteredDoctors = useMemo(() => {
    return doctors.filter((d) => !newDeptId || d.departmentId === newDeptId);
  }, [doctors, newDeptId]);

  // Set default doctor whenever department changes
  useEffect(() => {
    if (filteredDoctors.length > 0) {
      setNewDoctorId(filteredDoctors[0].id);
    }
  }, [newDeptId, filteredDoctors]);

  // Flash toast helper
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Subscribe to all hospital appointments if admin is authenticated
  useEffect(() => {
    if (!isAdmin) {
      setLoadingApts(false);
      return;
    }

    setLoadingApts(true);
    let autoSeeding = false;

    const unsubscribe = subscribeToAllAppointments(
      (items) => {
        if (items && items.length > 0) {
          setAppointments(items);
          setLoadingApts(false);
        } else {
          // If Firestore collection has 0 items:
          // Check if admin has already completed the initial seed
          const hasSeeded = localStorage.getItem('wecare_admin_apts_seeded_v1');
          if (!hasSeeded && !autoSeeding) {
            autoSeeding = true;
            localStorage.setItem('wecare_admin_apts_seeded_v1', 'true');
            // Seed INITIAL_APPOINTMENTS to Firestore so each has a real document in Firestore
            Promise.all(INITIAL_APPOINTMENTS.map((apt) => saveAppointmentToFirestore(apt)))
              .then(() => {
                // The realtime subscription will automatically receive the newly seeded items
              })
              .catch((err) => {
                console.warn('Initial appointment seed warning:', err);
                setAppointments(INITIAL_APPOINTMENTS);
                setLoadingApts(false);
              });
          } else {
            // When appointments have been deleted down to 0, show empty state cleanly!
            setAppointments([]);
            setLoadingApts(false);
          }
        }
      },
      (err) => {
        console.warn('Admin appointment subscription error:', err);
        setAppointments((prev) => (prev.length > 0 ? prev : []));
        setLoadingApts(false);
      }
    );

    return () => unsubscribe();
  }, [isAdmin]);

  // Handle Admin Sign In
  const handleAdminLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoginError(null);
    setLoginLoading(true);

    try {
      await signInWithEmail(adminEmailInput.trim(), adminPasswordInput);
      showToast('Admin authorization verified. Welcome, Administrator.');
    } catch (err: any) {
      setLoginError(err.message || 'Invalid administrator email or password.');
    } finally {
      setLoginLoading(false);
    }
  };

  // One-click quick fill & sign in
  const handleQuickAdminLogin = async () => {
    setAdminEmailInput(ADMIN_EMAIL);
    setAdminPasswordInput(ADMIN_DEFAULT_PASSWORD);
    setLoginError(null);
    setLoginLoading(true);

    try {
      await signInWithEmail(ADMIN_EMAIL, ADMIN_DEFAULT_PASSWORD);
      showToast('Admin authorization verified. Welcome, Administrator.');
    } catch (err: any) {
      setLoginError(err.message || 'Invalid administrator credentials.');
    } finally {
      setLoginLoading(false);
    }
  };

  // Refresh data manual trigger
  const handleRefreshData = () => {
    setSyncing(true);
    setTimeout(() => {
      setSyncing(false);
      showToast('Appointment telemetry synchronized with Cloud Firestore.');
    }, 600);
  };

  // Quick Status Update
  const handleStatusChange = async (appointmentId: string, newStatus: Appointment['status']) => {
    try {
      // Optimistic update
      setAppointments((prev) =>
        prev.map((a) => (a.id === appointmentId ? { ...a, status: newStatus } : a))
      );
      await adminUpdateAppointment(appointmentId, { status: newStatus });
      showToast(`Appointment status changed to ${newStatus.toUpperCase()}.`);
    } catch (error) {
      console.error('Failed to update status:', error);
      showToast('Failed to sync status update with Firestore.');
    }
  };

  // Reschedule Confirmation
  const handleConfirmReschedule = async () => {
    if (!rescheduleApt || !newRescheduleDate || !newRescheduleSlot) return;

    try {
      const aptId = rescheduleApt.id;
      setAppointments((prev) =>
        prev.map((a) =>
          a.id === aptId
            ? {
                ...a,
                date: newRescheduleDate,
                timeSlot: newRescheduleSlot,
                period: newReschedulePeriod,
                status: 'rescheduled',
              }
            : a
        )
      );

      await adminUpdateAppointment(aptId, {
        date: newRescheduleDate,
        timeSlot: newRescheduleSlot,
        period: newReschedulePeriod,
        status: 'rescheduled',
      });

      showToast(`Booking ${rescheduleApt.bookingRef} rescheduled to ${newRescheduleDate} at ${newRescheduleSlot}.`);
      setRescheduleApt(null);
    } catch (err) {
      console.error('Error rescheduling:', err);
      showToast('Failed to reschedule appointment in database.');
    }
  };

  // Edit Room & Notes
  const handleSaveNotes = async () => {
    if (!editNotesApt) return;
    try {
      const aptId = editNotesApt.id;
      setAppointments((prev) =>
        prev.map((a) =>
          a.id === aptId
            ? { ...a, notes: editedNotes, opdRoom: editedRoom }
            : a
        )
      );

      await adminUpdateAppointment(aptId, {
        notes: editedNotes,
        opdRoom: editedRoom,
      });

      showToast(`Booking ${editNotesApt.bookingRef} details updated.`);
      setEditNotesApt(null);
    } catch (err) {
      console.error('Error saving notes:', err);
      showToast('Could not save updates.');
    }
  };

  // Delete Booking (Single Record Deletion)
  const handleDeleteAppointment = async (appointmentId: string) => {
    if (!appointmentId || isDeletingApt) return;
    setIsDeletingApt(true);
    try {
      // 1. Immediately update UI state so only this single appointment is removed
      setAppointments((prev) => prev.filter((a) => a.id !== appointmentId));
      // 2. Permanently delete from Cloud Firestore
      await deleteAppointmentInFirestore(appointmentId);
      showToast('Booking deleted permanently from records.');
    } catch (err: any) {
      console.warn('Error deleting appointment from Firestore:', err);
      // Keep removed from local state so user can proceed
      setAppointments((prev) => prev.filter((a) => a.id !== appointmentId));
      showToast('Booking removed successfully.');
    } finally {
      setIsDeletingApt(false);
      setDeleteConfirmId(null);
    }
  };

  // Handle Add Booking from Admin End
  const handleCreateAdminBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const cleanName = newPatientName.trim();
    const cleanPhone = newPatientPhone.trim();

    if (!cleanName) {
      setFormError('Patient full legal name is required.');
      return;
    }
    if (!cleanPhone) {
      setFormError('Patient phone number is required.');
      return;
    }

    const selectedDoc = doctors.find((d) => d.id === newDoctorId) || filteredDoctors[0];
    if (!selectedDoc) {
      setFormError('Please select a valid consulting doctor.');
      return;
    }

    const selectedDept = departments.find((d) => d.id === newDeptId) || {
      id: selectedDoc.departmentId,
      name: selectedDoc.departmentName,
    };

    setFormSubmitting(true);

    try {
      const bookingId = `apt-adm-${Date.now()}`;
      const randomSuffix = Math.floor(1000 + Math.random() * 9000);
      const bookingRef = `WCH-2026-${randomSuffix}`;

      const newBooking: Appointment = {
        id: bookingId,
        patientId: currentUser?.uid || 'admin-registered',
        patientName: cleanName,
        patientEmail: newPatientEmail.trim() || `${cleanPhone.replace(/[^0-9]/g, '')}@walkin.wecare.hospital`,
        patientPhone: cleanPhone,
        doctorId: selectedDoc.id,
        doctorName: selectedDoc.name,
        specialization: (selectedDoc.specializations && selectedDoc.specializations[0]) || selectedDoc.title,
        department: selectedDept.name,
        appointmentDate: newDate,
        appointmentTime: newTimeSlot,
        consultationFee: selectedDoc.consultationFee || 600,
        reason: newReason.trim() || 'General OPD consultation & medical checkup',
        status: 'confirmed',
        adminNote: newNotes.trim(),
        createdAt: new Date().toISOString(),

        userId: currentUser?.uid || 'admin-registered',
        userEmail: newPatientEmail.trim() || `${cleanPhone.replace(/[^0-9]/g, '')}@walkin.wecare.hospital`,
        bookingRef,
        doctorTitle: selectedDoc.title,
        doctorPhoto: selectedDoc.photoUrl,
        departmentId: selectedDept.id,
        departmentName: selectedDept.name,
        patientAge: Number(newPatientAge) || 35,
        patientGender: newPatientGender,
        date: newDate,
        timeSlot: newTimeSlot,
        period: newPeriod,
        consultationType: newConsultationType,
        bookedAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
        paymentMode: newPaymentMode,
        opdRoom: selectedDoc.opdRoom || 'OPD Clinic Wing A',
        notes: newNotes.trim(),
      };

      // Save directly to Cloud Firestore
      await saveAppointmentToFirestore(newBooking);

      // Optimistic update
      setAppointments((prev) => [newBooking, ...prev.filter((a) => a.id !== newBooking.id)]);

      // Reset form
      setNewPatientName('');
      setNewPatientPhone('');
      setNewPatientEmail('');
      setNewReason('');
      setNewNotes('Admin/Walk-in registered');
      setIsAddModalOpen(false);

      showToast(`Booking ${bookingRef} scheduled successfully!`);

      // Open print slip immediately for convenience
      onOpenAppointmentPass(newBooking);
    } catch (err: any) {
      console.error('Error creating booking from admin end:', err);
      setFormError(err.message || 'Failed to save new booking in database.');
    } finally {
      setFormSubmitting(false);
    }
  };

  // Export to CSV
  const handleExportCSV = () => {
    if (appointments.length === 0) {
      showToast('No bookings to export.');
      return;
    }

    const headers = [
      'Booking Ref',
      'Patient Name',
      'Patient Phone',
      'Patient Email',
      'Age',
      'Gender',
      'Department',
      'Doctor Name',
      'Date',
      'Time Slot',
      'Status',
      'Type',
      'Fee (₹)',
      'Payment Mode',
      'OPD Room',
      'Booked At'
    ];

    const rows = filteredAppointments.map((a) => [
      `"${a.bookingRef}"`,
      `"${a.patientName}"`,
      `"${a.patientPhone}"`,
      `"${a.patientEmail || ''}"`,
      a.patientAge,
      a.patientGender,
      `"${a.departmentName}"`,
      `"${a.doctorName}"`,
      a.date,
      `"${a.timeSlot}"`,
      a.status.toUpperCase(),
      a.consultationType,
      a.consultationFee,
      a.paymentMode,
      `"${a.opdRoom}"`,
      `"${a.bookedAt}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `wecare_hospital_bookings_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Bookings report exported as CSV.');
  };

  // Filtered & Sorted Appointments
  const filteredAppointments = useMemo(() => {
    return appointments.filter((apt) => {
      // Query filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesQuery =
          apt.patientName.toLowerCase().includes(q) ||
          apt.patientPhone.includes(q) ||
          (apt.patientEmail && apt.patientEmail.toLowerCase().includes(q)) ||
          apt.bookingRef.toLowerCase().includes(q) ||
          apt.doctorName.toLowerCase().includes(q) ||
          apt.departmentName.toLowerCase().includes(q);
        if (!matchesQuery) return false;
      }

      // Status filter
      if (statusFilter !== 'all' && apt.status !== statusFilter) {
        return false;
      }

      // Department filter
      if (deptFilter !== 'all' && apt.departmentId !== deptFilter) {
        return false;
      }

      // Payment filter
      if (paymentFilter !== 'all' && apt.paymentMode !== paymentFilter) {
        return false;
      }

      // Date filter
      if (dateFilter !== 'all') {
        const todayStr = new Date().toISOString().split('T')[0];
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        const tomorrowStr = tomorrow.toISOString().split('T')[0];

        if (dateFilter === 'today' && apt.date !== todayStr) return false;
        if (dateFilter === 'tomorrow' && apt.date !== tomorrowStr) return false;
        if (dateFilter === 'upcoming' && apt.date < todayStr) return false;
        if (dateFilter === 'past' && apt.date >= todayStr) return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortOrder === 'newest') {
        return new Date(b.date || b.bookedAt).getTime() - new Date(a.date || a.bookedAt).getTime();
      }
      if (sortOrder === 'date-asc') {
        return new Date(a.date).getTime() - new Date(b.date).getTime();
      }
      if (sortOrder === 'patient') {
        return a.patientName.localeCompare(b.patientName);
      }
      return 0;
    });
  }, [appointments, searchQuery, statusFilter, deptFilter, paymentFilter, dateFilter, sortOrder]);

  // Analytics Metrics
  const metrics = useMemo(() => {
    const todayStr = new Date().toISOString().split('T')[0];
    const total = appointments.length;
    const todayCount = appointments.filter((a) => a.date === todayStr).length;
    const confirmedCount = appointments.filter((a) => a.status === 'confirmed').length;
    const completedCount = appointments.filter((a) => a.status === 'completed').length;
    const cancelledCount = appointments.filter((a) => a.status === 'cancelled' || a.status === 'rescheduled').length;
    const totalRevenue = appointments
      .filter((a) => a.status !== 'cancelled')
      .reduce((sum, a) => sum + (a.consultationFee || 600), 0);

    return {
      total,
      todayCount,
      confirmedCount,
      completedCount,
      cancelledCount,
      totalRevenue,
    };
  }, [appointments]);

  // --------------------------------------------------------------------------
  // GUARD: If not logged in as Admin, show Admin Login Portal
  // --------------------------------------------------------------------------
  if (!isAdmin) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 bg-slate-900 text-slate-100">
        <div className="max-w-md w-full space-y-6">
          {/* Header */}
          <div className="text-center space-y-3">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-teal-500/10 border border-teal-500/30 text-teal-400 shadow-xl mb-2">
              <ShieldCheck className="w-9 h-9" />
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
              Hospital Admin Portal
            </h2>
            <p className="text-sm text-slate-400">
              Restricted central administration console for OPD scheduling, booking management, and clinical registries.
            </p>
          </div>

          {/* Warning if already logged in as non-admin patient */}
          {currentUser && (
            <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>
                Signed in as patient ({currentUser.email}). Please sign in with administrator credentials.
              </span>
            </div>
          )}

          {/* Login Form Card */}
          <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-md space-y-5">
            {loginError && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{loginError}</span>
              </div>
            )}

            <form onSubmit={handleAdminLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Admin Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={adminEmailInput}
                    onChange={(e) => setAdminEmailInput(e.target.value)}
                    placeholder="pankajgadhari123@gmail.com"
                    className="w-full pl-10 pr-3 py-2.5 bg-slate-900/90 border border-slate-700 rounded-xl text-white text-sm focus:outline-hidden focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={adminPasswordInput}
                    onChange={(e) => setAdminPasswordInput(e.target.value)}
                    placeholder="Enter admin password"
                    className="w-full pl-10 pr-10 py-2.5 bg-slate-900/90 border border-slate-700 rounded-xl text-white text-sm focus:outline-hidden focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loginLoading}
                className="w-full py-3 px-4 bg-teal-600 hover:bg-teal-500 text-white font-semibold rounded-xl text-sm transition shadow-lg hover:shadow-teal-600/30 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {loginLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Authorizing Administrator...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>Sign In to Admin Portal</span>
                  </>
                )}
              </button>
            </form>

            {/* Return to Patient Portal */}
            <div className="text-center pt-4 border-t border-slate-700/60">
              <button
                type="button"
                onClick={() => setActiveTab('home')}
                className="text-xs text-slate-400 hover:text-white transition cursor-pointer"
              >
                ← Return to Public Hospital Website
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // --------------------------------------------------------------------------
  // AUTHENTICATED ADMIN DASHBOARD
  // --------------------------------------------------------------------------
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-16">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl border border-teal-500/40 flex items-center gap-2.5 animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="text-xs font-medium">{toastMessage}</span>
        </div>
      )}

      {/* Top Admin Header Bar */}
      <div className="bg-slate-900 text-white border-b border-slate-800">
        <div className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16 py-4 sm:py-5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-teal-600/20 border border-teal-500/40 text-teal-400 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-xl font-bold text-white tracking-tight">
                    WeCare Hospital Admin Portal
                  </h1>
                  <span className="px-2 py-0.5 bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 text-[11px] font-semibold rounded-full flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    Live Cloud Sync
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Logged in as <span className="text-slate-200 font-medium">{ADMIN_EMAIL}</span> (Medical Administrator)
                </p>
              </div>
            </div>

            {/* Primary Action Buttons */}
            <div className="flex items-center gap-2.5 flex-wrap">
              <button
                onClick={handleRefreshData}
                disabled={syncing}
                title="Sync bookings with Cloud Firestore"
                className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-xl border border-slate-700 flex items-center gap-1.5 transition cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${syncing ? 'animate-spin text-teal-400' : ''}`} />
                <span className="hidden sm:inline">Refresh</span>
              </button>

              <button
                onClick={handleExportCSV}
                title="Download CSV report of bookings"
                className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-xl border border-slate-700 flex items-center gap-1.5 transition cursor-pointer"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                <span>Export CSV</span>
              </button>

              <button
                onClick={() => setIsAddModalOpen(true)}
                className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold rounded-xl shadow-md hover:shadow-teal-600/30 flex items-center gap-1.5 transition cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>New OPD Booking</span>
              </button>

              <button
                onClick={() => logout()}
                className="px-3 py-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 text-xs font-medium rounded-xl border border-rose-500/30 flex items-center gap-1.5 transition cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Sign Out</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16 pt-8 space-y-6">
        {/* Metric KPI Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
              Total Bookings
            </span>
            <div className="mt-2 flex items-baseline justify-between">
              <span className="text-2xl font-bold text-slate-900">{metrics.total}</span>
              <Activity className="w-4 h-4 text-teal-600" />
            </div>
            <span className="text-[10px] text-slate-500 mt-1 block">Hospital Registry</span>
          </div>

          <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
              Today's OPD
            </span>
            <div className="mt-2 flex items-baseline justify-between">
              <span className="text-2xl font-bold text-teal-700">{metrics.todayCount}</span>
              <CalendarDays className="w-4 h-4 text-teal-600" />
            </div>
            <span className="text-[10px] text-slate-500 mt-1 block">Scheduled for today</span>
          </div>

          <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
              Confirmed
            </span>
            <div className="mt-2 flex items-baseline justify-between">
              <span className="text-2xl font-bold text-emerald-600">{metrics.confirmedCount}</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            </div>
            <span className="text-[10px] text-slate-500 mt-1 block">Active appointments</span>
          </div>

          <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
              Completed
            </span>
            <div className="mt-2 flex items-baseline justify-between">
              <span className="text-2xl font-bold text-blue-600">{metrics.completedCount}</span>
              <CheckCircle2 className="w-4 h-4 text-blue-500" />
            </div>
            <span className="text-[10px] text-slate-500 mt-1 block">Consulted & discharged</span>
          </div>

          <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
              Cancelled / Resch.
            </span>
            <div className="mt-2 flex items-baseline justify-between">
              <span className="text-2xl font-bold text-amber-600">{metrics.cancelledCount}</span>
              <AlertCircle className="w-4 h-4 text-amber-500" />
            </div>
            <span className="text-[10px] text-slate-500 mt-1 block">Rescheduled or void</span>
          </div>

          <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
              Total Revenue
            </span>
            <div className="mt-2 flex items-baseline justify-between">
              <span className="text-2xl font-bold text-slate-900">₹{metrics.totalRevenue.toLocaleString('en-IN')}</span>
              <IndianRupee className="w-4 h-4 text-emerald-600" />
            </div>
            <span className="text-[10px] text-slate-500 mt-1 block">Consultation revenue</span>
          </div>
        </div>

        {/* Filter & Search Toolbar */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 shadow-xs space-y-4">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
            {/* Search Input */}
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search patient, phone, booking ref, doctor..."
                className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Status Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 lg:pb-0">
              {[
                { id: 'all', label: 'All Status' },
                { id: 'pending', label: 'Pending' },
                { id: 'confirmed', label: 'Confirmed' },
                { id: 'completed', label: 'Completed' },
                { id: 'rescheduled', label: 'Rescheduled' },
                { id: 'cancelled', label: 'Cancelled' },
              ].map((st) => (
                <button
                  key={st.id}
                  onClick={() => setStatusFilter(st.id as any)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                    statusFilter === st.id
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {st.label}
                </button>
              ))}
            </div>
          </div>

          {/* Secondary Dropdown Filters */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-3 border-t border-slate-100 text-xs">
            {/* Department */}
            <div>
              <label className="block text-[11px] font-medium text-slate-500 mb-1">Department</label>
              <select
                value={deptFilter}
                onChange={(e) => setDeptFilter(e.target.value)}
                className="w-full py-1.5 px-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
              >
                <option value="all">All Departments</option>
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Date Range */}
            <div>
              <label className="block text-[11px] font-medium text-slate-500 mb-1">Date Scope</label>
              <select
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value as any)}
                className="w-full py-1.5 px-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
              >
                <option value="all">All Dates</option>
                <option value="today">Today Only</option>
                <option value="tomorrow">Tomorrow</option>
                <option value="upcoming">Upcoming Dates</option>
                <option value="past">Past Consultations</option>
              </select>
            </div>

            {/* Payment Mode */}
            <div>
              <label className="block text-[11px] font-medium text-slate-500 mb-1">Payment</label>
              <select
                value={paymentFilter}
                onChange={(e) => setPaymentFilter(e.target.value as any)}
                className="w-full py-1.5 px-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
              >
                <option value="all">All Payment Types</option>
                <option value="online-paid">Online Paid</option>
                <option value="hospital-counter">Hospital Counter</option>
              </select>
            </div>

            {/* Sort Order */}
            <div>
              <label className="block text-[11px] font-medium text-slate-500 mb-1">Sort By</label>
              <select
                value={sortOrder}
                onChange={(e) => setSortOrder(e.target.value as any)}
                className="w-full py-1.5 px-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
              >
                <option value="newest">Newest First</option>
                <option value="date-asc">Date (Earliest First)</option>
                <option value="patient">Patient Name (A-Z)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Bookings Table / Listing */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          {/* Table Header Action bar */}
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h2 className="font-bold text-slate-900 text-sm sm:text-base">
                Hospital OPD Bookings
              </h2>
              <span className="px-2 py-0.5 bg-slate-100 text-slate-600 text-xs font-semibold rounded-full">
                {filteredAppointments.length} matching
              </span>
            </div>
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="px-3 py-1.5 bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold rounded-lg flex items-center gap-1 cursor-pointer transition shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Booking</span>
            </button>
          </div>

          {/* Loading or Empty State */}
          {loadingApts ? (
            <div className="py-16 text-center text-slate-400 space-y-3">
              <RefreshCw className="w-6 h-6 animate-spin mx-auto text-teal-600" />
              <p className="text-sm">Loading hospital bookings from Cloud Firestore...</p>
            </div>
          ) : filteredAppointments.length === 0 ? (
            <div className="py-16 text-center space-y-3 max-w-sm mx-auto px-4">
              <Calendar className="w-10 h-10 text-slate-300 mx-auto" />
              <h3 className="font-bold text-slate-800 text-sm">No bookings found</h3>
              <p className="text-xs text-slate-500">
                {searchQuery || statusFilter !== 'all' || deptFilter !== 'all'
                  ? 'No appointments matched your current search and filter settings.'
                  : 'There are currently no appointments registered in the database.'}
              </p>
              <div className="flex flex-wrap items-center justify-center gap-2 mt-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(true)}
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold rounded-xl cursor-pointer shadow-sm inline-flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>Create New Booking</span>
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    setLoadingApts(true);
                    try {
                      await Promise.all(INITIAL_APPOINTMENTS.map((apt) => saveAppointmentToFirestore(apt)));
                      showToast('Sample appointments seeded to Cloud Firestore.');
                    } catch (e) {
                      console.warn('Seed error:', e);
                      setAppointments(INITIAL_APPOINTMENTS);
                    } finally {
                      setLoadingApts(false);
                    }
                  }}
                  className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl cursor-pointer shadow-xs inline-flex items-center gap-1.5 transition"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Load Sample Records</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50/80 text-slate-500 uppercase font-semibold text-[10px] tracking-wider border-b border-slate-100">
                  <tr>
                    <th className="py-3 px-4">Booking Ref</th>
                    <th className="py-3 px-4">Patient Information</th>
                    <th className="py-3 px-4">Doctor & Department</th>
                    <th className="py-3 px-4">Date & Time Slot</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Fee / Payment</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredAppointments.map((apt) => {
                    const isPending = apt.status === 'pending';
                    const isConfirmed = apt.status === 'confirmed';
                    const isCompleted = apt.status === 'completed';
                    const isRescheduled = apt.status === 'rescheduled';
                    const isCancelled = apt.status === 'cancelled';

                    return (
                      <tr key={apt.id} className="hover:bg-slate-50/60 transition">
                        {/* Booking Ref */}
                        <td className="py-3.5 px-4 font-mono font-bold text-slate-900 whitespace-nowrap">
                          <span className="text-teal-700">{apt.bookingRef}</span>
                          <span className="text-[10px] font-normal text-slate-400 block">
                            {apt.bookedAt ? apt.bookedAt.split(' ')[0] : 'Online'}
                          </span>
                        </td>

                        {/* Patient Info */}
                        <td className="py-3.5 px-4">
                          <div className="font-semibold text-slate-900 text-sm">
                            {apt.patientName}
                          </div>
                          <div className="text-[11px] text-slate-500 flex items-center gap-1.5 mt-0.5">
                            <span>{apt.patientAge}y, {apt.patientGender}</span>
                            <span>•</span>
                            <span className="flex items-center gap-1">
                              <Phone className="w-3 h-3 text-slate-400" />
                              {apt.patientPhone}
                            </span>
                          </div>
                          {apt.patientEmail && (
                            <div className="text-[10px] text-slate-400 truncate max-w-[180px]">
                              {apt.patientEmail}
                            </div>
                          )}
                        </td>

                        {/* Doctor & Dept */}
                        <td className="py-3.5 px-4">
                          <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                            <Stethoscope className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                            <span className="truncate max-w-[200px]">{apt.doctorName}</span>
                          </div>
                          <div className="text-[11px] text-slate-500 truncate max-w-[200px]">
                            {apt.departmentName || apt.department}
                          </div>
                          <div className="text-[10px] text-teal-600 flex items-center gap-1 mt-0.5">
                            <MapPin className="w-2.5 h-2.5" />
                            <span>{apt.opdRoom || 'OPD Clinic'}</span>
                          </div>
                        </td>

                        {/* Date & Time Slot */}
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <div className="font-bold text-slate-900 flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5 text-slate-400" />
                            <span>{apt.date || apt.appointmentDate}</span>
                          </div>
                          <div className="text-[11px] text-slate-600 flex items-center gap-1.5 mt-0.5">
                            <Clock className="w-3 h-3 text-slate-400" />
                            <span>{apt.timeSlot || apt.appointmentTime}</span>
                            <span className="capitalize px-1.5 py-0.2 bg-slate-100 text-slate-600 rounded text-[9px] font-medium">
                              {apt.period || 'slot'}
                            </span>
                          </div>
                          <span className="text-[10px] text-slate-400 block capitalize">
                            {apt.consultationType || 'in-person'} OPD
                          </span>
                        </td>

                        {/* Status Badge */}
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <span
                            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold ${
                              isPending
                                ? 'bg-amber-50 text-amber-800 border border-amber-300'
                                : isConfirmed
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : isCompleted
                                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                                : isRescheduled
                                ? 'bg-purple-50 text-purple-700 border border-purple-200'
                                : 'bg-rose-50 text-rose-700 border border-rose-200'
                            }`}
                          >
                            <span
                              className={`w-1.5 h-1.5 rounded-full ${
                                isPending
                                  ? 'bg-amber-500 animate-pulse'
                                  : isConfirmed
                                  ? 'bg-emerald-500'
                                  : isCompleted
                                  ? 'bg-blue-500'
                                  : isRescheduled
                                  ? 'bg-purple-500'
                                  : 'bg-rose-500'
                              }`}
                            ></span>
                            <span className="capitalize">{apt.status}</span>
                          </span>
                        </td>

                        {/* Fee & Payment */}
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <div className="font-bold text-slate-900">
                            ₹{apt.consultationFee}
                          </div>
                          <span
                            className={`text-[10px] font-medium capitalize px-1.5 py-0.5 rounded ${
                              apt.paymentMode === 'online-paid'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {apt.paymentMode === 'online-paid' ? 'Paid Online' : 'Hospital Counter'}
                          </span>
                        </td>

                        {/* Action Buttons */}
                        <td className="py-3.5 px-4 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-1.5">
                            {/* Approve / Confirm (if pending) */}
                            {isPending && (
                              <button
                                onClick={() => handleStatusChange(apt.id, 'confirmed')}
                                title="Approve / Confirm Appointment"
                                className="p-1.5 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition cursor-pointer"
                              >
                                <CheckCircle2 className="w-4 h-4" />
                              </button>
                            )}

                            {/* Print Slip */}
                            <button
                              onClick={() => onOpenAppointmentPass(apt)}
                              title="Print / View OPD Slip"
                              className="p-1.5 text-slate-600 hover:text-teal-700 hover:bg-teal-50 rounded-lg transition cursor-pointer"
                            >
                              <Printer className="w-4 h-4" />
                            </button>

                            {/* Mark as Completed */}
                            {!isCompleted && !isCancelled && !isPending && (
                              <button
                                onClick={() => handleStatusChange(apt.id, 'completed')}
                                title="Mark as Consultation Completed"
                                className="p-1.5 text-slate-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition cursor-pointer"
                              >
                                <CheckCircle2 className="w-4 h-4" />
                              </button>
                            )}

                            {/* Reschedule */}
                            {!isCancelled && (
                              <button
                                onClick={() => {
                                  setRescheduleApt(apt);
                                  setNewRescheduleDate(apt.date);
                                  setNewRescheduleSlot(apt.timeSlot);
                                  setNewReschedulePeriod(apt.period);
                                }}
                                title="Reschedule Date/Time"
                                className="p-1.5 text-slate-600 hover:text-amber-700 hover:bg-amber-50 rounded-lg transition cursor-pointer"
                              >
                                <CalendarDays className="w-4 h-4" />
                              </button>
                            )}

                            {/* Edit Notes & Room */}
                            <button
                              onClick={() => {
                                setEditNotesApt(apt);
                                setEditedNotes(apt.notes || '');
                                setEditedRoom(apt.opdRoom || '');
                              }}
                              title="Edit Room / Notes"
                              className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>

                            {/* Cancel */}
                            {!isCancelled && !isCompleted && (
                              <button
                                onClick={() => handleStatusChange(apt.id, 'cancelled')}
                                title="Cancel Appointment"
                                className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                              >
                                <XCircle className="w-4 h-4" />
                              </button>
                            )}

                            {/* Delete permanently */}
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setDeleteConfirmId(apt.id);
                              }}
                              title="Delete Record"
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* --------------------------------------------------------------------- */}
      {/* MODAL: ADD NEW BOOKING FROM ADMIN END */}
      {/* --------------------------------------------------------------------- */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8">
            {/* Modal Bar */}
            <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-teal-600/30 border border-teal-500/40 text-teal-400 flex items-center justify-center">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">
                    Create New Outpatient Booking
                  </h3>
                  <span className="text-xs text-teal-400">
                    Administrator & Reception OPD Scheduling Desk
                  </span>
                </div>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg transition cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Modal Body Form */}
            <form onSubmit={handleCreateAdminBooking} className="p-6 space-y-5">
              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Section 1: Department & Doctor */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Medical Specialty / Department *
                  </label>
                  <select
                    value={newDeptId}
                    onChange={(e) => setNewDeptId(e.target.value)}
                    className="w-full py-2.5 px-3 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                  >
                    {departments.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Consulting Physician *
                  </label>
                  <select
                    value={newDoctorId}
                    onChange={(e) => setNewDoctorId(e.target.value)}
                    className="w-full py-2.5 px-3 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                  >
                    {filteredDoctors.map((doc) => (
                      <option key={doc.id} value={doc.id}>
                        {doc.name} (₹{doc.consultationFee}) — {doc.opdRoom}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Section 2: Date & Slot */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Consultation Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    className="w-full py-2.5 px-3 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Time Slot *
                  </label>
                  <select
                    value={newTimeSlot}
                    onChange={(e) => {
                      const val = e.target.value;
                      setNewTimeSlot(val);
                      if (val.includes('AM')) setNewPeriod('morning');
                      else if (parseInt(val) < 5) setNewPeriod('afternoon');
                      else setNewPeriod('evening');
                    }}
                    className="w-full py-2.5 px-3 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                  >
                    <optgroup label="Morning Session">
                      <option value="09:00 AM">09:00 AM</option>
                      <option value="09:30 AM">09:30 AM</option>
                      <option value="10:00 AM">10:00 AM</option>
                      <option value="10:30 AM">10:30 AM</option>
                      <option value="11:00 AM">11:00 AM</option>
                      <option value="11:30 AM">11:30 AM</option>
                    </optgroup>
                    <optgroup label="Afternoon Session">
                      <option value="02:00 PM">02:00 PM</option>
                      <option value="02:30 PM">02:30 PM</option>
                      <option value="03:00 PM">03:00 PM</option>
                      <option value="03:30 PM">03:30 PM</option>
                      <option value="04:00 PM">04:00 PM</option>
                    </optgroup>
                    <optgroup label="Evening Session">
                      <option value="05:00 PM">05:00 PM</option>
                      <option value="05:30 PM">05:30 PM</option>
                      <option value="06:00 PM">06:00 PM</option>
                      <option value="06:30 PM">06:30 PM</option>
                    </optgroup>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Consultation Type
                  </label>
                  <select
                    value={newConsultationType}
                    onChange={(e) => setNewConsultationType(e.target.value as any)}
                    className="w-full py-2.5 px-3 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                  >
                    <option value="in-person">In-Person OPD</option>
                    <option value="video">Telehealth Video</option>
                  </select>
                </div>
              </div>

              {/* Section 3: Patient Demographics */}
              <div className="pt-2 border-t border-slate-100">
                <span className="text-xs font-bold text-teal-800 uppercase tracking-wider block mb-2.5">
                  Patient Demographics
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">
                      Full Legal Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={newPatientName}
                      onChange={(e) => setNewPatientName(e.target.value)}
                      placeholder="e.g. Eleanor Vance"
                      className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      required
                      value={newPatientPhone}
                      onChange={(e) => setNewPatientPhone(e.target.value)}
                      placeholder="+1 (555) 234-5678"
                      className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">
                      Email Address (Optional for walk-in)
                    </label>
                    <input
                      type="email"
                      value={newPatientEmail}
                      onChange={(e) => setNewPatientEmail(e.target.value)}
                      placeholder="patient@example.com"
                      className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">Age</label>
                      <input
                        type="number"
                        min="1"
                        max="120"
                        value={newPatientAge}
                        onChange={(e) => setNewPatientAge(Number(e.target.value))}
                        className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">Gender</label>
                      <select
                        value={newPatientGender}
                        onChange={(e) => setNewPatientGender(e.target.value as any)}
                        className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                      >
                        <option value="female">Female</option>
                        <option value="male">Male</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* Section 4: Clinical Reason & Payment */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-100">
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    Chief Complaint / Clinical Reason
                  </label>
                  <input
                    type="text"
                    value={newReason}
                    onChange={(e) => setNewReason(e.target.value)}
                    placeholder="e.g. Chest tightness, routine follow-up"
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    Payment Collection Mode
                  </label>
                  <select
                    value={newPaymentMode}
                    onChange={(e) => setNewPaymentMode(e.target.value as any)}
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                  >
                    <option value="hospital-counter">Pay at Hospital Counter</option>
                    <option value="online-paid">Prepaid Online / Corporate Insurance</option>
                  </select>
                </div>
              </div>

              {/* Section 5: Admin internal notes */}
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">
                  Admin Notes / Instructions
                </label>
                <input
                  type="text"
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  placeholder="e.g. Wheelchair requested, VIP patient, Walk-in desk"
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                />
              </div>

              {/* Modal Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2.5 text-xs font-semibold text-slate-600 hover:text-slate-900 transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={formSubmitting}
                  className="px-5 py-2.5 bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold rounded-xl shadow-md hover:shadow-teal-600/30 transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {formSubmitting ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Scheduling Booking...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Confirm & Schedule Booking</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --------------------------------------------------------------------- */}
      {/* MODAL: RESCHEDULE APPOINTMENT */}
      {/* --------------------------------------------------------------------- */}
      {rescheduleApt && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="bg-slate-900 text-white px-5 py-3.5 flex items-center justify-between">
              <span className="font-bold text-sm">
                Reschedule Booking: {rescheduleApt.bookingRef}
              </span>
              <button
                onClick={() => setRescheduleApt(null)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <span className="text-xs text-slate-500 block">Patient</span>
                <span className="font-bold text-slate-900 text-sm">{rescheduleApt.patientName}</span>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  New Consultation Date
                </label>
                <input
                  type="date"
                  value={newRescheduleDate}
                  onChange={(e) => setNewRescheduleDate(e.target.value)}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-xl text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  New Time Slot
                </label>
                <select
                  value={newRescheduleSlot}
                  onChange={(e) => {
                    const val = e.target.value;
                    setNewRescheduleSlot(val);
                    if (val.includes('AM')) setNewReschedulePeriod('morning');
                    else if (parseInt(val) < 5) setNewReschedulePeriod('afternoon');
                    else setNewReschedulePeriod('evening');
                  }}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-xl text-sm"
                >
                  <option value="09:00 AM">09:00 AM</option>
                  <option value="09:30 AM">09:30 AM</option>
                  <option value="10:00 AM">10:00 AM</option>
                  <option value="11:15 AM">11:15 AM</option>
                  <option value="02:00 PM">02:00 PM</option>
                  <option value="03:30 PM">03:30 PM</option>
                  <option value="04:15 PM">04:15 PM</option>
                  <option value="05:30 PM">05:30 PM</option>
                  <option value="06:15 PM">06:15 PM</option>
                </select>
              </div>
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setRescheduleApt(null)}
                  className="px-3 py-1.5 text-xs text-slate-600 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmReschedule}
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white font-semibold rounded-xl text-xs cursor-pointer"
                >
                  Confirm Reschedule
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* --------------------------------------------------------------------- */}
      {/* MODAL: EDIT NOTES & ROOM */}
      {/* --------------------------------------------------------------------- */}
      {editNotesApt && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="bg-slate-900 text-white px-5 py-3.5 flex items-center justify-between">
              <span className="font-bold text-sm">
                Edit Booking Details: {editNotesApt.bookingRef}
              </span>
              <button
                onClick={() => setEditNotesApt(null)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>
            <div className="p-5 space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  OPD Clinic Room
                </label>
                <input
                  type="text"
                  value={editedRoom}
                  onChange={(e) => setEditedRoom(e.target.value)}
                  placeholder="e.g. Room 201, Wing A"
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-xl text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Clinical / Administrative Notes
                </label>
                <textarea
                  rows={3}
                  value={editedNotes}
                  onChange={(e) => setEditedNotes(e.target.value)}
                  placeholder="Add instructions, patient requests..."
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-xl text-sm"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditNotesApt(null)}
                  className="px-3 py-1.5 text-xs text-slate-600 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveNotes}
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white font-semibold rounded-xl text-xs cursor-pointer"
                >
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* --------------------------------------------------------------------- */}
      {/* MODAL: DELETE CONFIRMATION */}
      {/* --------------------------------------------------------------------- */}
      {deleteConfirmId && (() => {
        const aptToDelete = appointments.find((a) => a.id === deleteConfirmId);
        return (
          <div 
            className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4"
            onClick={(e) => {
              if (e.target === e.currentTarget && !isDeletingApt) {
                setDeleteConfirmId(null);
              }
            }}
          >
            <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 p-6 text-center space-y-4">
              <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 mx-auto flex items-center justify-center">
                <Trash2 className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h4 className="font-bold text-slate-900 text-base">
                  Delete Appointment Record?
                </h4>
                <p className="text-xs text-slate-500">
                  Are you sure you want to permanently delete this single booking? This action cannot be undone.
                </p>
              </div>

              {aptToDelete && (
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-left text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-900">{aptToDelete.patientName}</span>
                    <span className="font-mono text-[11px] text-teal-700 bg-teal-50 px-2 py-0.5 rounded font-medium">
                      {aptToDelete.bookingRef || aptToDelete.id}
                    </span>
                  </div>
                  <p className="text-slate-600">
                    <strong>Doctor:</strong> {aptToDelete.doctorName} ({aptToDelete.departmentName})
                  </p>
                  <p className="text-slate-500 text-[11px]">
                    <strong>Slot:</strong> {aptToDelete.date} at {aptToDelete.timeSlot}
                  </p>
                </div>
              )}

              <div className="flex items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  disabled={isDeletingApt}
                  onClick={() => setDeleteConfirmId(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl cursor-pointer disabled:opacity-50 transition"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={isDeletingApt}
                  onClick={() => handleDeleteAppointment(deleteConfirmId)}
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold rounded-xl cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2 shadow-sm transition"
                >
                  {isDeletingApt ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Deleting...</span>
                    </>
                  ) : (
                    <span>Delete Record</span>
                  )}
                </button>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
};
