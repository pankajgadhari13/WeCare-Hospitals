import React, { useState, useEffect, useRef } from 'react';
import { 
  Calendar, 
  Clock, 
  User, 
  Phone, 
  Mail, 
  MapPin, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle, 
  ChevronRight, 
  ArrowLeft, 
  CreditCard, 
  FileText, 
  Video, 
  Building,
  Zap,
  Sparkles,
  Lock,
  LogIn,
  Database
} from 'lucide-react';
import { Department, Doctor, Appointment, DoctorSlot } from '../types';
import { useAuth } from '../context/AuthContext';
import { createAppointmentWithAddDoc, saveAppointmentToFirestore } from '../services/appointmentService';

interface BookingPageProps {
  departments: Department[];
  doctors: Doctor[];
  selectedDoctor: Doctor | null;
  onAppointmentBooked: (newApt: Appointment) => void;
  onOpenAppointmentPass: (apt: Appointment) => void;
  setActiveTab: (tab: string) => void;
}

export const BookingPage: React.FC<BookingPageProps> = ({
  departments,
  doctors,
  selectedDoctor,
  onAppointmentBooked,
  onOpenAppointmentPass,
  setActiveTab,
}) => {
  const { currentUser, userProfile, openAuthModal } = useAuth();

  // Wizard steps: 1: Specialty & Doctor, 2: Date & Slot, 3: Patient Info, 4: Review & Payment, 5: Confirmed
  const [currentStep, setCurrentStep] = useState<number>(selectedDoctor ? 2 : 1);

  // Form State
  const [chosenDepartmentId, setChosenDepartmentId] = useState<string>(
    selectedDoctor ? selectedDoctor.departmentId : departments[0]?.id || 'cardiology'
  );
  const [chosenDoctor, setChosenDoctor] = useState<Doctor | null>(
    selectedDoctor || doctors.find((d) => d.departmentId === (departments[0]?.id || 'cardiology')) || doctors[0]
  );

  // Generate next 5 business dates
  const generateDates = () => {
    const dates = [];
    const today = new Date();
    for (let i = 0; i < 5; i++) {
      const d = new Date();
      d.setDate(today.getDate() + i);
      const iso = d.toISOString().split('T')[0];
      const weekday = d.toLocaleDateString('en-US', { weekday: 'short' });
      const dayNum = d.toLocaleDateString('en-US', { day: 'numeric', month: 'short' });
      dates.push({
        iso,
        label: i === 0 ? 'Today' : i === 1 ? 'Tomorrow' : weekday,
        display: dayNum,
      });
    }
    return dates;
  };

  const availableDates = generateDates();
  const [selectedDate, setSelectedDate] = useState<string>(availableDates[0].iso);
  const [selectedSlot, setSelectedSlot] = useState<DoctorSlot | null>(null);
  const [consultationType, setConsultationType] = useState<'in-person' | 'video'>('in-person');

  // Patient Info - Auto-filled from Firebase User / Profile
  const [patientName, setPatientName] = useState(userProfile?.name || currentUser?.displayName || 'Alexander Hayes');
  const [patientPhone, setPatientPhone] = useState(userProfile?.phone || '+1 (555) 234-8901');
  const [patientEmail, setPatientEmail] = useState(userProfile?.email || currentUser?.email || 'alex.hayes@example.com');
  const [patientAge, setPatientAge] = useState<number>(userProfile?.age || 46);
  const [patientGender, setPatientGender] = useState<'male' | 'female' | 'other'>(
    (userProfile?.gender as any) || 'male'
  );
  const [reasonForVisit, setReasonForVisit] = useState('');
  const [paymentMode, setPaymentMode] = useState<'hospital-counter' | 'online-paid'>('hospital-counter');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Update form fields when user logs in or profile loads
  useEffect(() => {
    if (userProfile) {
      if (userProfile.name) setPatientName(userProfile.name);
      if (userProfile.email) setPatientEmail(userProfile.email);
      if (userProfile.phone) setPatientPhone(userProfile.phone);
      if (userProfile.age) setPatientAge(userProfile.age);
      if (userProfile.gender) setPatientGender(userProfile.gender as any);
    } else if (currentUser) {
      if (currentUser.displayName) setPatientName(currentUser.displayName);
      if (currentUser.email) setPatientEmail(currentUser.email);
    }
  }, [currentUser, userProfile]);

  // Confirmed appointment result
  const [confirmedAppointment, setConfirmedAppointment] = useState<Appointment | null>(null);

  // Top anchor ref to guarantee scrolling to page starting point
  const bookingTopRef = useRef<HTMLDivElement>(null);

  // Scroll viewport to the very top (starting of page)
  const scrollToTop = () => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    if (bookingTopRef.current) {
      bookingTopRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
    // Backup check after DOM render settles
    setTimeout(() => {
      window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    }, 40);
  };

  const goToStep = (stepNumber: number) => {
    setCurrentStep(stepNumber);
    scrollToTop();
  };

  // Scroll to top whenever step changes
  useEffect(() => {
    scrollToTop();
  }, [currentStep]);

  // When selectedDoctor prop changes
  useEffect(() => {
    if (selectedDoctor) {
      setChosenDoctor(selectedDoctor);
      setChosenDepartmentId(selectedDoctor.departmentId);
      goToStep(2);
    }
  }, [selectedDoctor]);

  // When department changes, set first doctor of that department
  const handleDeptChange = (deptId: string) => {
    setChosenDepartmentId(deptId);
    const availableDocs = doctors.filter((d) => d.departmentId === deptId);
    if (availableDocs.length > 0) {
      setChosenDoctor(availableDocs[0]);
    }
    setSelectedSlot(null);
  };

  // Immediate selection and transition to next step (Date & Slots)
  const handleSelectDoctorAndProceed = (doc: Doctor) => {
    setChosenDoctor(doc);
    setChosenDepartmentId(doc.departmentId);
    setSelectedSlot(null);
    goToStep(2);
  };

  const handleSlotSelect = (slot: DoctorSlot) => {
    if (!slot.isAvailable || slot.bookedCount >= slot.totalCapacity) return;
    setSelectedSlot(slot);
  };

  const handleSubmitBooking = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!chosenDoctor || !selectedSlot) return;

    setIsSubmitting(true);
    const bookingRef = `WCH-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const effectiveUid = currentUser?.uid || `patient_${patientPhone.replace(/\D/g, '') || Date.now()}`;
    const effectiveEmail = currentUser?.email || patientEmail.trim();

    try {
      // Use exact addDoc to appointments collection as requested by user
      const { appointment } = await createAppointmentWithAddDoc({
        user: {
          uid: effectiveUid,
          email: effectiveEmail,
        },
        patientName: patientName.trim(),
        patientPhone: patientPhone.trim(),
        doctor: {
          id: chosenDoctor.id,
          name: chosenDoctor.name,
          specialization: (chosenDoctor.specializations && chosenDoctor.specializations[0]) || chosenDoctor.title,
          specializations: chosenDoctor.specializations,
          department: chosenDoctor.departmentName,
          departmentName: chosenDoctor.departmentName,
          consultationFee: chosenDoctor.consultationFee,
          title: chosenDoctor.title,
          photoUrl: chosenDoctor.photoUrl,
          opdRoom: chosenDoctor.opdRoom,
        },
        selectedDate,
        selectedTime: selectedSlot.time,
        reason: reasonForVisit.trim() || 'General OPD Specialist Consultation',
        status: 'pending',
        adminNote: '',
        bookingRef,
        period: selectedSlot.period,
        consultationType,
        paymentMode,
      });

      onAppointmentBooked(appointment);
      setConfirmedAppointment(appointment);
    } catch (err) {
      console.error('Could not save to Firestore directly, fallback to local state:', err);

      const fallbackAppointment: Appointment = {
        id: `apt-${Date.now()}`,
        patientId: effectiveUid,
        patientName: patientName.trim(),
        patientEmail: effectiveEmail,
        patientPhone: patientPhone.trim(),
        doctorId: chosenDoctor.id,
        doctorName: chosenDoctor.name,
        specialization: (chosenDoctor.specializations && chosenDoctor.specializations[0]) || chosenDoctor.title,
        department: chosenDoctor.departmentName,
        appointmentDate: selectedDate,
        appointmentTime: selectedSlot.time,
        consultationFee: chosenDoctor.consultationFee,
        reason: reasonForVisit.trim() || 'General OPD Specialist Consultation',
        status: 'pending',
        adminNote: '',
        createdAt: new Date().toISOString(),

        userId: effectiveUid,
        userEmail: effectiveEmail,
        bookingRef,
        doctorTitle: chosenDoctor.title,
        doctorPhoto: chosenDoctor.photoUrl,
        departmentId: chosenDoctor.departmentId,
        departmentName: chosenDoctor.departmentName,
        patientAge: Number(patientAge),
        patientGender,
        date: selectedDate,
        timeSlot: selectedSlot.time,
        period: selectedSlot.period,
        consultationType,
        bookedAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
        paymentMode,
        opdRoom: chosenDoctor.opdRoom,
      };

      onAppointmentBooked(fallbackAppointment);
      setConfirmedAppointment(fallbackAppointment);
    } finally {
      setIsSubmitting(false);
      goToStep(5); // Confirmed screen
    }
  };

  const currentDept = departments.find((d) => d.id === chosenDepartmentId);
  const departmentDoctors = doctors.filter((d) => d.departmentId === chosenDepartmentId);

  return (
    <div ref={bookingTopRef} className="w-full max-w-6xl xl:max-w-7xl 2xl:max-w-[1500px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 py-8 space-y-8">
      {/* Title & Progress Bar */}
      <div className="text-center space-y-2">
        <span className="px-3 py-1 bg-teal-100/80 text-teal-800 rounded-full text-xs font-bold uppercase tracking-wider inline-block">
          WeCare Online OPD Desk
        </span>
        <h1 className="text-2xl sm:text-4xl font-black text-slate-900 tracking-tight">
          Book Doctor Appointment
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 max-w-xl mx-auto">
          Select department, choose a specialized physician, check real-time available slots, and obtain immediate digital OPD clearance.
        </p>
      </div>

      {/* Stepper indicator */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
        <div className="grid grid-cols-4 gap-2 text-center text-xs font-semibold">
          {[
            { step: 1, label: '1. Specialist' },
            { step: 2, label: '2. Date & Slot' },
            { step: 3, label: '3. Patient Info' },
            { step: 4, label: '4. Summary' },
          ].map((s) => (
            <button
              key={s.step}
              type="button"
              onClick={() => {
                if (s.step < currentStep) {
                  goToStep(s.step);
                }
              }}
              disabled={s.step > currentStep}
              className={`py-2 px-1 rounded-xl transition ${
                currentStep === s.step
                  ? 'bg-teal-600 text-white font-bold shadow-xs'
                  : currentStep > s.step
                  ? 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 cursor-pointer font-medium'
                  : 'bg-slate-50 text-slate-400 cursor-not-allowed'
              }`}
            >
              <span className="truncate block">{s.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* STEP 1: Select Department & Multiple Doctors */}
      {currentStep === 1 && (
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-6 animate-in fade-in">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Step 1: Choose Medical Department</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Select the relevant specialty. Each department has multiple verified consultants.
            </p>
          </div>

          {/* Department Horizontal Selector */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {departments.map((dept) => (
              <button
                key={dept.id}
                type="button"
                onClick={() => handleDeptChange(dept.id)}
                className={`p-3.5 rounded-2xl border text-left transition cursor-pointer flex flex-col justify-between ${
                  chosenDepartmentId === dept.id
                    ? 'border-teal-600 bg-teal-50/60 ring-2 ring-teal-500/20 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div>
                  <span className="text-[10px] font-bold text-teal-700 uppercase tracking-wider block">
                    {dept.floor}
                  </span>
                  <h4 className="text-xs sm:text-sm font-bold text-slate-900 mt-1 leading-tight">
                    {dept.name}
                  </h4>
                </div>
                <span className="text-[11px] text-slate-400 mt-3 block">
                  {doctors.filter((d) => d.departmentId === dept.id).length} Doctors
                </span>
              </button>
            ))}
          </div>

          {/* Doctors available in chosen Department */}
          <div className="space-y-3 pt-4 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">
                Select Specialist in {currentDept?.name} ({departmentDoctors.length} available)
              </h3>
              <span className="text-xs text-teal-700 font-semibold">Multiple consultants on duty</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {departmentDoctors.map((doc) => {
                const isSelected = chosenDoctor?.id === doc.id;
                return (
                  <div
                    key={doc.id}
                    onClick={() => handleSelectDoctorAndProceed(doc)}
                    className={`p-4 rounded-2xl border transition cursor-pointer flex flex-col justify-between group hover:shadow-md hover:border-teal-400 ${
                      isSelected
                        ? 'border-teal-600 bg-teal-50/50 ring-2 ring-teal-500/20 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <img
                        src={doc.photoUrl}
                        alt={doc.name}
                        className="w-14 h-14 rounded-xl object-cover border border-slate-200 shrink-0 group-hover:scale-105 transition-transform"
                      />
                      <div className="min-w-0 flex-1">
                        <h4 className="text-sm font-bold text-slate-900 truncate group-hover:text-teal-700 transition-colors">
                          {doc.name}
                        </h4>
                        <p className="text-xs text-slate-500 truncate">{doc.title}</p>
                        <p className="text-[11px] text-teal-700 font-medium mt-0.5">
                          {doc.qualifications}
                        </p>
                      </div>
                    </div>

                    <div className="mt-4 pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                      <span className="text-slate-500">Fee: <strong>₹{doc.consultationFee}</strong></span>
                      <span className="text-emerald-700 font-bold">{doc.nextAvailableSlot}</span>
                    </div>

                    <div className="mt-3">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSelectDoctorAndProceed(doc);
                        }}
                        className={`w-full py-2 px-3 rounded-xl text-xs font-bold text-center flex items-center justify-center gap-1.5 transition cursor-pointer ${
                          isSelected
                            ? 'bg-teal-600 text-white shadow-xs'
                            : 'bg-teal-50 group-hover:bg-teal-600 text-teal-700 group-hover:text-white border border-teal-200 group-hover:border-teal-600'
                        }`}
                      >
                        <span>{isSelected ? 'Selected • Proceed' : 'Select Doctor & Continue'}</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="flex justify-end pt-4">
            <button
              type="button"
              onClick={() => {
                if (chosenDoctor) {
                  goToStep(2);
                }
              }}
              disabled={!chosenDoctor}
              className="px-6 py-3 bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition flex items-center gap-2 cursor-pointer shadow-sm"
            >
              <span>Continue to Date & Slots</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: Select Date & Time Slot with Real-Time Availability Tracking */}
      {currentStep === 2 && chosenDoctor && (
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-6 animate-in fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div className="flex items-center gap-4">
              <img
                src={chosenDoctor.photoUrl}
                alt={chosenDoctor.name}
                className="w-16 h-16 rounded-2xl object-cover border border-slate-200"
              />
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-teal-700 bg-teal-50 px-2 py-0.5 rounded-md">
                  {chosenDoctor.departmentName}
                </span>
                <h3 className="text-base font-bold text-slate-900 mt-1">{chosenDoctor.name}</h3>
                <p className="text-xs text-slate-500">
                  {chosenDoctor.opdRoom} • Consultation Fee: ₹{chosenDoctor.consultationFee}
                </p>
              </div>
            </div>

            <button
              onClick={() => goToStep(1)}
              className="text-xs text-teal-700 hover:underline font-semibold flex items-center gap-1 cursor-pointer self-start sm:self-center"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Change Specialist</span>
            </button>
          </div>

          {/* Consultation Type Selector */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
              Consultation Mode
            </label>
            <div className="grid grid-cols-2 gap-3 max-w-md">
              <button
                type="button"
                onClick={() => setConsultationType('in-person')}
                className={`p-3 rounded-2xl border text-xs font-bold transition flex items-center gap-2.5 cursor-pointer ${
                  consultationType === 'in-person'
                    ? 'border-teal-600 bg-teal-50 text-teal-900 shadow-xs'
                    : 'border-slate-200 bg-white text-slate-600'
                }`}
              >
                <Building className="w-4 h-4 text-teal-600" />
                <span>In-Hospital OPD Visit</span>
              </button>
              <button
                type="button"
                onClick={() => setConsultationType('video')}
                className={`p-3 rounded-2xl border text-xs font-bold transition flex items-center gap-2.5 cursor-pointer ${
                  consultationType === 'video'
                    ? 'border-teal-600 bg-teal-50 text-teal-900 shadow-xs'
                    : 'border-slate-200 bg-white text-slate-600'
                }`}
              >
                <Video className="w-4 h-4 text-teal-600" />
                <span>Telehealth Video Call</span>
              </button>
            </div>
          </div>

          {/* Choose Date */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Select Appointment Date
              </label>
              <span className="text-xs text-slate-400 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                Showing Next 5 Days
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
              {availableDates.map((dateObj) => (
                <button
                  key={dateObj.iso}
                  type="button"
                  onClick={() => {
                    setSelectedDate(dateObj.iso);
                    setSelectedSlot(null);
                  }}
                  className={`p-3 rounded-2xl border text-center transition cursor-pointer ${
                    selectedDate === dateObj.iso
                      ? 'border-teal-600 bg-teal-600 text-white shadow-md'
                      : 'border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700'
                  }`}
                >
                  <span className="text-xs block font-bold">{dateObj.label}</span>
                  <span className={`text-xs block mt-0.5 ${selectedDate === dateObj.iso ? 'text-teal-100' : 'text-slate-400'}`}>
                    {dateObj.display}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Real-time Available Slots Grid */}
          <div className="space-y-4 pt-2">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-500" />
                  <span>Real-Time Appointment Slot Availability</span>
                </h4>
                <p className="text-xs text-slate-500">
                  Slots update dynamically with clinic queue telemetry
                </p>
              </div>

              {/* Slot Legend */}
              <div className="hidden sm:flex items-center gap-3 text-[11px] text-slate-500">
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-teal-500" /> Available
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> Filling Fast
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-300" /> Booked
                </span>
              </div>
            </div>

            {/* Morning Slots */}
            <div className="space-y-2">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                Morning Sessions (09:00 AM – 12:00 PM)
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {chosenDoctor.slots
                  .filter((s) => s.period === 'morning')
                  .map((slot) => {
                    const remaining = slot.totalCapacity - slot.bookedCount;
                    const isSelected = selectedSlot?.id === slot.id;
                    const isFull = !slot.isAvailable || remaining <= 0;

                    return (
                      <button
                        key={slot.id}
                        type="button"
                        disabled={isFull}
                        onClick={() => handleSlotSelect(slot)}
                        className={`p-3 rounded-2xl border text-center transition cursor-pointer relative ${
                          isFull
                            ? 'bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed line-through'
                            : isSelected
                            ? 'border-teal-600 bg-teal-600 text-white shadow-md'
                            : remaining === 1
                            ? 'border-amber-300 bg-amber-50/70 hover:bg-amber-100 text-amber-900'
                            : 'border-slate-200 bg-white hover:border-teal-400 text-slate-800'
                        }`}
                      >
                        <span className="text-xs font-bold block">{slot.time}</span>
                        <span
                          className={`text-[10px] block mt-0.5 ${
                            isSelected
                              ? 'text-teal-100'
                              : isFull
                              ? 'text-slate-400'
                              : remaining === 1
                              ? 'text-amber-700 font-bold'
                              : 'text-emerald-600'
                          }`}
                        >
                          {isFull ? 'Full' : `${remaining} seat${remaining > 1 ? 's' : ''} left`}
                        </span>
                      </button>
                    );
                  })}
              </div>
            </div>

            {/* Afternoon Slots */}
            <div className="space-y-2 pt-2">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                Afternoon Sessions (02:00 PM – 05:00 PM)
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {chosenDoctor.slots
                  .filter((s) => s.period === 'afternoon')
                  .map((slot) => {
                    const remaining = slot.totalCapacity - slot.bookedCount;
                    const isSelected = selectedSlot?.id === slot.id;
                    const isFull = !slot.isAvailable || remaining <= 0;

                    return (
                      <button
                        key={slot.id}
                        type="button"
                        disabled={isFull}
                        onClick={() => handleSlotSelect(slot)}
                        className={`p-3 rounded-2xl border text-center transition cursor-pointer relative ${
                          isFull
                            ? 'bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed line-through'
                            : isSelected
                            ? 'border-teal-600 bg-teal-600 text-white shadow-md'
                            : remaining === 1
                            ? 'border-amber-300 bg-amber-50/70 hover:bg-amber-100 text-amber-900'
                            : 'border-slate-200 bg-white hover:border-teal-400 text-slate-800'
                        }`}
                      >
                        <span className="text-xs font-bold block">{slot.time}</span>
                        <span
                          className={`text-[10px] block mt-0.5 ${
                            isSelected
                              ? 'text-teal-100'
                              : isFull
                              ? 'text-slate-400'
                              : remaining === 1
                              ? 'text-amber-700 font-bold'
                              : 'text-emerald-600'
                          }`}
                        >
                          {isFull ? 'Full' : `${remaining} seat${remaining > 1 ? 's' : ''} left`}
                        </span>
                      </button>
                    );
                  })}
              </div>
            </div>

            {/* Evening Slots */}
            <div className="space-y-2 pt-2">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                Evening Sessions (05:30 PM – 07:30 PM)
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {chosenDoctor.slots
                  .filter((s) => s.period === 'evening')
                  .map((slot) => {
                    const remaining = slot.totalCapacity - slot.bookedCount;
                    const isSelected = selectedSlot?.id === slot.id;
                    const isFull = !slot.isAvailable || remaining <= 0;

                    return (
                      <button
                        key={slot.id}
                        type="button"
                        disabled={isFull}
                        onClick={() => handleSlotSelect(slot)}
                        className={`p-3 rounded-2xl border text-center transition cursor-pointer relative ${
                          isFull
                            ? 'bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed line-through'
                            : isSelected
                            ? 'border-teal-600 bg-teal-600 text-white shadow-md'
                            : remaining === 1
                            ? 'border-amber-300 bg-amber-50/70 hover:bg-amber-100 text-amber-900'
                            : 'border-slate-200 bg-white hover:border-teal-400 text-slate-800'
                        }`}
                      >
                        <span className="text-xs font-bold block">{slot.time}</span>
                        <span
                          className={`text-[10px] block mt-0.5 ${
                            isSelected
                              ? 'text-teal-100'
                              : isFull
                              ? 'text-slate-400'
                              : remaining === 1
                              ? 'text-amber-700 font-bold'
                              : 'text-emerald-600'
                          }`}
                        >
                          {isFull ? 'Full' : `${remaining} seat${remaining > 1 ? 's' : ''} left`}
                        </span>
                      </button>
                    );
                  })}
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => goToStep(1)}
              className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 cursor-pointer"
            >
              Back
            </button>
            <button
              type="button"
              onClick={() => {
                if (selectedSlot) goToStep(3);
              }}
              disabled={!selectedSlot}
              className="px-6 py-3 bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition flex items-center gap-2 cursor-pointer"
            >
              <span>Next: Patient Information</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 3: Patient Information Form */}
      {currentStep === 3 && (
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-6 animate-in fade-in">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Step 3: Patient Information & Authentication</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Confirm your patient account and clinical contact details for the consultation.
            </p>
          </div>

          {/* Authentication Status Banner */}
          {!currentUser ? (
            <div className="p-4 rounded-2xl bg-amber-50/90 border border-amber-200 text-amber-900 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="p-2.5 bg-amber-100 rounded-xl text-amber-800 shrink-0">
                  <Lock className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-900">
                    Patient Sign In / Sign Up Required
                  </h4>
                  <p className="text-xs text-amber-700 mt-0.5">
                    WeCare Hospital requires an account to reserve doctor slots and securely store your electronic health record.
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
                <button
                  type="button"
                  onClick={() => openAuthModal('Sign in to continue your appointment booking')}
                  className="flex-1 sm:flex-initial px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Sign In</span>
                </button>
                <button
                  type="button"
                  onClick={() => openAuthModal('Create a patient account to reserve your slot')}
                  className="flex-1 sm:flex-initial px-4 py-2 bg-white hover:bg-amber-50 border border-amber-300 text-amber-900 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  Create Account
                </button>
              </div>
            </div>
          ) : (
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-sm shrink-0">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900">
                      Logged in as {currentUser.displayName || patientName}
                    </span>
                    <span className="px-2 py-0.5 bg-emerald-200 text-emerald-900 text-[10px] font-bold rounded-full">
                      OPD Verified
                    </span>
                  </div>
                  <span className="text-xs text-slate-500 block">
                    {currentUser.email} • Your booking will be saved to your Firestore patient records
                  </span>
                </div>
              </div>
              <span className="inline-flex items-center gap-1 px-3 py-1 bg-white border border-emerald-200 text-emerald-800 text-[11px] font-semibold rounded-lg shadow-2xs">
                <Database className="w-3 h-3 text-emerald-600" />
                Firebase Connected
              </span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">Full Name *</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  required
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  placeholder="e.g. Alexander Hayes"
                  className="w-full pl-9 pr-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">Phone Number *</label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="tel"
                  required
                  value={patientPhone}
                  onChange={(e) => setPatientPhone(e.target.value)}
                  placeholder="e.g. +1 (555) 234-8901"
                  className="w-full pl-9 pr-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">Email Address (For Confirmation Pass) *</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="email"
                  required
                  value={patientEmail}
                  onChange={(e) => setPatientEmail(e.target.value)}
                  placeholder="alex.hayes@example.com"
                  className="w-full pl-9 pr-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">Age *</label>
                <input
                  type="number"
                  min="1"
                  max="120"
                  required
                  value={patientAge}
                  onChange={(e) => setPatientAge(Number(e.target.value))}
                  className="w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:outline-hidden"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">Gender *</label>
                <select
                  value={patientGender}
                  onChange={(e) => setPatientGender(e.target.value as any)}
                  aria-label="Patient Gender"
                  className="w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:outline-hidden text-slate-700"
                >
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>

            <div className="sm:col-span-2 space-y-1.5">
              <label className="text-xs font-bold text-slate-700">
                Reason for Visit / Primary Symptoms (Optional)
              </label>
              <textarea
                rows={3}
                value={reasonForVisit}
                onChange={(e) => setReasonForVisit(e.target.value)}
                placeholder="Briefly describe your symptoms (e.g., chest tightness, knee pain, routine checkup, second opinion)..."
                className="w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:outline-hidden"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => goToStep(2)}
              className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 cursor-pointer"
            >
              Back
            </button>
            <button
              type="button"
              onClick={() => {
                if (patientName && patientPhone && patientEmail) goToStep(4);
              }}
              disabled={!patientName || !patientPhone || !patientEmail}
              className="px-6 py-3 bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition flex items-center gap-2 cursor-pointer"
            >
              <span>Review & Payment Selection</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 4: Summary & Payment Choice */}
      {currentStep === 4 && chosenDoctor && selectedSlot && (
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-6 animate-in fade-in">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Step 4: Review & Payment Option</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Verify your booking details before generating the digital outpatient consultation pass.
            </p>
          </div>

          {/* Booking Summary Box */}
          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <span className="text-slate-400 block uppercase font-bold text-[10px]">Consulting Doctor</span>
                <span className="font-bold text-slate-900 text-sm">{chosenDoctor.name}</span>
                <span className="text-slate-600 block">{chosenDoctor.title}</span>
                <span className="text-teal-700 font-medium block">{chosenDoctor.departmentName}</span>
              </div>
              <div>
                <span className="text-slate-400 block uppercase font-bold text-[10px]">Date & Time</span>
                <span className="font-bold text-slate-900 text-sm flex items-center gap-1 mt-0.5">
                  <Calendar className="w-3.5 h-3.5 text-teal-600" />
                  {selectedDate} at {selectedSlot.time}
                </span>
                <span className="text-slate-600 block mt-0.5">Room: {chosenDoctor.opdRoom}</span>
                <span className="text-slate-600 block capitalize">Mode: {consultationType} visit</span>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <span className="text-slate-400 block uppercase font-bold text-[10px]">Patient Name</span>
                <span className="font-bold text-slate-800">{patientName}</span>
                <span className="text-slate-500 block">{patientAge} yrs • {patientGender.toUpperCase()}</span>
              </div>
              <div>
                <span className="text-slate-400 block uppercase font-bold text-[10px]">Contact</span>
                <span className="font-bold text-slate-800">{patientPhone}</span>
                <span className="text-slate-500 block">{patientEmail}</span>
              </div>
            </div>
          </div>

          {/* Payment Selection */}
          <div className="space-y-3">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
              Payment Method
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div
                onClick={() => setPaymentMode('hospital-counter')}
                className={`p-4 rounded-2xl border transition cursor-pointer flex items-center justify-between ${
                  paymentMode === 'hospital-counter'
                    ? 'border-teal-600 bg-teal-50/60 ring-2 ring-teal-500/20'
                    : 'border-slate-200 bg-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Building className="w-5 h-5 text-teal-700" />
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Pay at Hospital Counter</h4>
                    <p className="text-[11px] text-slate-500">Pay at OPD billing desk upon arrival</p>
                  </div>
                </div>
                <span className="font-bold text-sm text-slate-900">₹{chosenDoctor.consultationFee}</span>
              </div>

              <div
                onClick={() => setPaymentMode('online-paid')}
                className={`p-4 rounded-2xl border transition cursor-pointer flex items-center justify-between ${
                  paymentMode === 'online-paid'
                    ? 'border-teal-600 bg-teal-50/60 ring-2 ring-teal-500/20'
                    : 'border-slate-200 bg-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <CreditCard className="w-5 h-5 text-teal-700" />
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Prepay Online (Fast-Track)</h4>
                    <p className="text-[11px] text-slate-500">Skip reception queue on visit day</p>
                  </div>
                </div>
                <span className="font-bold text-sm text-teal-700">₹{chosenDoctor.consultationFee}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => goToStep(3)}
              className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 cursor-pointer"
            >
              Back
            </button>
            {!currentUser ? (
              <button
                type="button"
                onClick={() => openAuthModal('Please sign in or register to confirm your appointment')}
                className="px-8 py-3.5 bg-teal-600 hover:bg-teal-700 active:scale-95 text-white text-xs font-bold rounded-xl transition shadow-md shadow-teal-600/20 flex items-center gap-2 cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                <span>Sign In to Confirm Booking</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleSubmitBooking}
                disabled={isSubmitting}
                className="px-8 py-3.5 bg-teal-600 hover:bg-teal-700 active:scale-95 text-white text-xs font-bold rounded-xl transition shadow-md shadow-teal-600/20 flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                ) : (
                  <CheckCircle2 className="w-4 h-4" />
                )}
                <span>Confirm & Issue Booking Pass</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* STEP 5: Booking Confirmed Screen */}
      {currentStep === 5 && confirmedAppointment && (
        <div className="bg-white p-8 rounded-3xl border border-emerald-200 shadow-xl text-center space-y-6 animate-in zoom-in-95 duration-300">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-sm">
            <CheckCircle2 className="w-9 h-9" />
          </div>

          <div className="space-y-1">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
              Outpatient Booking Confirmed
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mt-2">
              Appointment Successfully Reserved!
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto">
              Your consultation slot has been synchronized with the clinic's real-time queue at WeCare Hospital.
            </p>
          </div>

          {/* Firestore Synchronized Pill */}
          <div className="inline-flex items-center gap-2 bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-1.5 rounded-full text-xs font-semibold">
            <Database className="w-3.5 h-3.5 text-teal-600" />
            <span>Saved to Firestore Database under your Patient Account</span>
          </div>

          {/* Reference Badge */}
          <div>
            <div className="inline-block bg-slate-900 text-white px-5 py-2.5 rounded-2xl text-sm font-mono tracking-wider shadow-xs">
              Booking Ref: <strong className="text-teal-400">{confirmedAppointment.bookingRef}</strong>
            </div>
          </div>

          {/* Key Recap */}
          <div className="max-w-md mx-auto bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs space-y-2 text-left">
            <div className="flex justify-between">
              <span className="text-slate-500">Doctor:</span>
              <span className="font-bold text-slate-900">{confirmedAppointment.doctorName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Date & Slot:</span>
              <span className="font-bold text-slate-900">{confirmedAppointment.date} at {confirmedAppointment.timeSlot}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Location:</span>
              <span className="font-bold text-slate-900">{confirmedAppointment.opdRoom}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Patient:</span>
              <span className="font-bold text-slate-900">{confirmedAppointment.patientName}</span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={() => onOpenAppointmentPass(confirmedAppointment)}
              className="px-6 py-3 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl shadow-xs transition flex items-center gap-2 cursor-pointer"
            >
              <FileText className="w-4 h-4" />
              <span>View / Print Digital Pass</span>
            </button>
            <button
              onClick={() => setActiveTab('dashboard')}
              className="px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition cursor-pointer"
            >
              Go to Patient Dashboard
            </button>
            <button
              onClick={() => {
                goToStep(1);
                setSelectedSlot(null);
                setConfirmedAppointment(null);
              }}
              className="px-4 py-3 text-slate-500 hover:text-slate-800 text-xs font-semibold cursor-pointer"
            >
              Book Another
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
