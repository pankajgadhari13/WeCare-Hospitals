import React, { useState, useEffect } from 'react';
import { 
  User, 
  Calendar, 
  Clock, 
  MapPin, 
  FileText, 
  Pill, 
  Activity, 
  AlertCircle, 
  CheckCircle2, 
  XCircle, 
  Download, 
  Printer, 
  Phone, 
  Heart, 
  ShieldCheck, 
  Edit3, 
  Plus, 
  CalendarCheck,
  ChevronRight,
  ExternalLink,
  Trash2,
  RefreshCw,
  Database,
  LogIn,
  LogOut,
  Lock
} from 'lucide-react';
import { Appointment, MedicalRecord, Prescription, PatientProfile } from '../types';
import { useAuth } from '../context/AuthContext';
import { DEFAULT_PATIENT_PROFILE } from '../data/hospitalData';
import { AppointmentStatsSummary } from '../components/AppointmentStatsSummary';

interface DashboardPageProps {
  appointments: Appointment[];
  medicalRecords: MedicalRecord[];
  prescriptions: Prescription[];
  patientProfile?: PatientProfile | null;
  onCancelAppointment: (id: string) => void;
  onOpenAppointmentPass: (apt: Appointment) => void;
  onUpdateVitals: (vitals: PatientProfile['vitals']) => void;
  setActiveTab: (tab: string) => void;
  onLogout?: () => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  appointments,
  medicalRecords,
  prescriptions,
  patientProfile: fallbackProfile,
  onCancelAppointment,
  onOpenAppointmentPass,
  onUpdateVitals,
  setActiveTab,
  onLogout,
}) => {
  const { currentUser, userProfile, logout, updateProfileData } = useAuth();
  const currentProfile = userProfile || fallbackProfile || DEFAULT_PATIENT_PROFILE;

  const [activeSubTab, setActiveSubTab] = useState<'appointments' | 'records' | 'prescriptions' | 'profile'>('appointments');
  const [appointmentFilter, setAppointmentFilter] = useState<'all' | 'upcoming' | 'completed' | 'cancelled'>('upcoming');

  // Vitals editing state
  const [isEditingVitals, setIsEditingVitals] = useState(false);
  const [vitalsForm, setVitalsForm] = useState(currentProfile?.vitals || DEFAULT_PATIENT_PROFILE.vitals);

  // Requirement: Protected pages must verify authentication before rendering
  // If unauthenticated, redirect to login page immediately
  useEffect(() => {
    if (!currentUser) {
      setActiveTab('login');
    }
  }, [currentUser, setActiveTab]);

  const handleSignOut = async () => {
    if (onLogout) {
      onLogout();
    } else {
      await logout();
      setActiveTab('login');
    }
  };

  if (!currentUser) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center px-4 py-16 bg-slate-50 dark:bg-slate-950">
        <div className="max-w-md w-full text-center space-y-4 bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="w-12 h-12 rounded-full bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 flex items-center justify-center mx-auto">
            <Lock className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">Protected Patient Area</h3>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Please log in with your registered credentials to access your appointments and health records.
          </p>
          <button
            onClick={() => setActiveTab('login')}
            className="w-full py-2.5 px-4 bg-teal-600 text-white font-semibold text-sm rounded-xl hover:bg-teal-700 transition cursor-pointer"
          >
            Go to Login
          </button>
        </div>
      </div>
    );
  }

  const handleSaveVitals = async (e: React.FormEvent) => {
    e.preventDefault();
    const newVitals = {
      ...vitalsForm,
      lastUpdated: 'Just now (Updated)',
    };
    onUpdateVitals(newVitals);
    if (currentUser) {
      try {
        await updateProfileData({ vitals: newVitals });
      } catch (err) {
        console.warn('Could not sync vitals to Firestore:', err);
      }
    }
    setIsEditingVitals(false);
  };

  const filteredAppointments = appointments.filter((apt) => {
    if (appointmentFilter === 'all') return true;
    if (appointmentFilter === 'upcoming') return apt.status === 'confirmed' || apt.status === 'rescheduled' || apt.status === 'pending';
    if (appointmentFilter === 'completed') return apt.status === 'completed';
    if (appointmentFilter === 'cancelled') return apt.status === 'cancelled';
    return true;
  });

  const initials = currentProfile?.name
    ? currentProfile.name.split(' ').map((n) => n[0]).join('').slice(0, 2)
    : 'PT';

  return (
    <div className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16 py-8 space-y-8 pb-16">
      {/* Cloud Sync Status Ribbon for Guests */}
      {!currentUser && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-amber-900 animate-in fade-in">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-100 rounded-xl text-amber-800">
              <LogIn className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-amber-900">
                Sign In to Synchronize Your Bookings
              </h4>
              <p className="text-xs text-amber-700">
                Connect your account to access real-time Firebase Firestore synchronization across all your devices.
              </p>
            </div>
          </div>
          <button
            onClick={() => setActiveTab('login')}
            className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl transition shadow-xs cursor-pointer shrink-0"
          >
            Sign In / Register
          </button>
        </div>
      )}

      {/* Patient Header Banner */}
      <div className="bg-gradient-to-r from-teal-900 via-slate-900 to-slate-950 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-18 h-18 rounded-2xl bg-teal-500 text-white flex items-center justify-center font-black text-2xl shadow-lg border-2 border-white/20">
            {initials}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black">{currentProfile.name}</h1>
              <span className="px-2 py-0.5 rounded-full bg-teal-500/30 text-teal-300 text-[10px] font-bold uppercase tracking-wider border border-teal-400/30">
                {currentUser ? 'Firebase Account' : 'Guest Preview'}
              </span>
              {currentUser && (
                <span className="hidden sm:inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-500/30">
                  <Database className="w-3 h-3 text-emerald-400" />
                  Firestore Live
                </span>
              )}
            </div>
            <p className="text-xs text-slate-300 mt-1">
              Patient ID: <strong>{currentProfile.uid || currentProfile.id}</strong> • Age: {currentProfile.age} • Blood Group: <strong className="text-rose-400">{currentProfile.bloodGroup}</strong>
            </p>
            <p className="text-xs text-slate-400 mt-0.5">
              Contact: {currentProfile.phone} • {currentUser?.email || currentProfile.email}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setActiveTab('booking')}
            className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl shadow-xs transition flex items-center gap-2 cursor-pointer"
          >
            <CalendarCheck className="w-4 h-4" />
            <span>Book New Appointment</span>
          </button>
          <button
            onClick={() => {
              setVitalsForm(currentProfile.vitals);
              setIsEditingVitals(true);
            }}
            className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white text-xs font-medium rounded-xl transition flex items-center gap-1.5 cursor-pointer backdrop-blur-xs"
          >
            <Edit3 className="w-3.5 h-3.5 text-teal-300" />
            <span>Update Vitals</span>
          </button>
          <button
            id="dashboard-logout-btn"
            onClick={handleSignOut}
            className="px-4 py-2.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 hover:text-white border border-rose-400/30 text-xs font-semibold rounded-xl transition flex items-center gap-1.5 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* Appointment Summary Stats & Recharts Distribution */}
      <AppointmentStatsSummary 
        appointments={appointments}
        onBookNew={() => setActiveTab('booking')}
      />

      {/* Vitals Telemetry Ribbon */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">Blood Pressure</span>
          <span className="text-lg font-black text-slate-900 dark:text-white block mt-1">{currentProfile.vitals.bloodPressure}</span>
          <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">Optimal Range</span>
        </div>
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">Heart Rate</span>
          <span className="text-lg font-black text-slate-900 dark:text-white block mt-1">{currentProfile.vitals.heartRate} bpm</span>
          <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">Resting Normal</span>
        </div>
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">SpO2 (Oxygen)</span>
          <span className="text-lg font-black text-slate-900 dark:text-white block mt-1">{currentProfile.vitals.oxygenSaturation}%</span>
          <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">Adequate</span>
        </div>
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">Blood Sugar</span>
          <span className="text-lg font-black text-slate-900 dark:text-white block mt-1">{currentProfile.vitals.bloodSugar} mg/dL</span>
          <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">Fasting Normal</span>
        </div>
        <div className="col-span-2 sm:col-span-1 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">Weight</span>
          <span className="text-lg font-black text-slate-900 dark:text-white block mt-1">{currentProfile.vitals.weightKg} kg</span>
          <span className="text-[10px] text-slate-400 dark:text-slate-500">{currentProfile.vitals.lastUpdated}</span>
        </div>
      </div>

      {/* Vitals Edit Modal */}
      {isEditingVitals && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 text-slate-900 dark:text-white">
            <h3 className="font-bold text-slate-900 dark:text-white text-base">Update Patient Vitals</h3>
            <form onSubmit={handleSaveVitals} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">Blood Pressure (mmHg)</label>
                <input
                  type="text"
                  value={vitalsForm.bloodPressure}
                  onChange={(e) => setVitalsForm({ ...vitalsForm, bloodPressure: e.target.value })}
                  placeholder="e.g. 120/80 mmHg"
                  className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 dark:bg-slate-800 dark:text-white rounded-xl focus:outline-teal-500"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">Heart Rate (bpm)</label>
                  <input
                    type="number"
                    value={vitalsForm.heartRate}
                    onChange={(e) => setVitalsForm({ ...vitalsForm, heartRate: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 dark:bg-slate-800 dark:text-white rounded-xl focus:outline-teal-500"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">SpO2 (%)</label>
                  <input
                    type="number"
                    value={vitalsForm.oxygenSaturation}
                    onChange={(e) => setVitalsForm({ ...vitalsForm, oxygenSaturation: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 dark:bg-slate-800 dark:text-white rounded-xl focus:outline-teal-500"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">Blood Sugar (mg/dL)</label>
                  <input
                    type="number"
                    value={vitalsForm.bloodSugar}
                    onChange={(e) => setVitalsForm({ ...vitalsForm, bloodSugar: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 dark:bg-slate-800 dark:text-white rounded-xl focus:outline-teal-500"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">Weight (kg)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={vitalsForm.weightKg}
                    onChange={(e) => setVitalsForm({ ...vitalsForm, weightKg: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 dark:bg-slate-800 dark:text-white rounded-xl focus:outline-teal-500"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsEditingVitals(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-bold cursor-pointer"
                >
                  Save Vitals
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Sub Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 overflow-x-auto pb-1 scrollbar-none text-xs font-bold">
        {[
          { id: 'appointments', label: `My Appointments (${appointments.length})` },
          { id: 'records', label: `Diagnostic Records (${medicalRecords.length})` },
          { id: 'prescriptions', label: `Prescriptions (${prescriptions.length})` },
          { id: 'profile', label: 'Health Profile & Contacts' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id as any)}
            className={`px-4 py-2.5 rounded-xl transition cursor-pointer whitespace-nowrap ${
              activeSubTab === tab.id
                ? 'bg-teal-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* TAB 1: Appointments List */}
      {activeSubTab === 'appointments' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              {(['all', 'upcoming', 'completed', 'cancelled'] as const).map((filter) => (
                <button
                  key={filter}
                  onClick={() => setAppointmentFilter(filter)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition cursor-pointer ${
                    appointmentFilter === filter
                      ? 'bg-slate-900 dark:bg-teal-600 text-white shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>

            <button
              onClick={() => setActiveTab('booking')}
              className="text-xs font-bold text-teal-700 dark:text-teal-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Book Another Consultation</span>
            </button>
          </div>

          {filteredAppointments.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-10 text-center border border-slate-200 dark:border-slate-800 space-y-3">
              <Calendar className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto" />
              <h4 className="font-bold text-slate-900 dark:text-white text-sm">No {appointmentFilter} appointments found</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                You do not have any appointments in this status category.
              </p>
              <button
                onClick={() => setActiveTab('booking')}
                className="mt-2 px-4 py-2 bg-teal-600 text-white text-xs font-semibold rounded-xl cursor-pointer"
              >
                Book Appointment
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {filteredAppointments.map((apt) => (
                <div
                  key={apt.id}
                  className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs hover:shadow-md transition flex flex-col justify-between space-y-4"
                >
                  <div>
                    {/* Top Row */}
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono font-bold text-slate-400 dark:text-slate-500">
                        Ref: {apt.bookingRef}
                      </span>
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          apt.status === 'pending'
                            ? 'bg-amber-100 text-amber-900 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-300 dark:border-amber-800'
                            : apt.status === 'confirmed'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-300/40 dark:border-emerald-800'
                            : apt.status === 'completed'
                            ? 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                            : apt.status === 'rescheduled'
                            ? 'bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300'
                            : 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300'
                        }`}
                      >
                        {apt.status === 'pending' ? 'Pending Approval' : apt.status}
                      </span>
                    </div>

                    {/* Doctor Info */}
                    <div className="flex items-start gap-3 mt-3">
                      <img
                        src={apt.doctorPhoto}
                        alt={apt.doctorName}
                        className="w-14 h-14 rounded-2xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                      />
                      <div className="min-w-0 flex-1">
                        <span className="text-[10px] font-bold text-teal-700 dark:text-teal-400 uppercase">
                          {apt.departmentName}
                        </span>
                        <h4 className="font-bold text-slate-900 dark:text-white text-sm truncate">{apt.doctorName}</h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{apt.doctorTitle}</p>
                      </div>
                    </div>

                    {/* Appointment details box */}
                    <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-2xl border border-slate-100 dark:border-slate-800 mt-4 text-xs space-y-1.5 text-slate-700 dark:text-slate-300">
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-1.5 text-slate-900 dark:text-white font-semibold">
                          <Calendar className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                          {apt.date}
                        </span>
                        <span className="flex items-center gap-1.5 text-slate-900 dark:text-white font-semibold">
                          <Clock className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                          {apt.timeSlot}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-[11px] pt-1">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-slate-400" />
                          {apt.opdRoom}
                        </span>
                        <span className="capitalize">{apt.consultationType} visit</span>
                      </div>
                      {apt.reason && (
                        <p className="text-[11px] text-slate-600 dark:text-slate-300 italic pt-1 border-t border-slate-200 dark:border-slate-700">
                          "{apt.reason}"
                        </p>
                      )}
                      {apt.adminNote && (
                        <div className="text-[11px] text-teal-800 dark:text-teal-200 bg-teal-50/80 dark:bg-teal-950/60 p-2 rounded-xl border border-teal-100 dark:border-teal-800 mt-1.5">
                          <span className="font-bold">Hospital Remarks:</span> {apt.adminNote}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                    <button
                      onClick={() => onOpenAppointmentPass(apt)}
                      className="px-3.5 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5"
                    >
                      <FileText className="w-3.5 h-3.5 text-teal-700 dark:text-teal-400" />
                      <span>Digital Pass</span>
                    </button>

                    {apt.status === 'confirmed' && (
                      <button
                        onClick={() => onCancelAppointment(apt.id)}
                        className="px-3 py-2 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-semibold rounded-xl transition cursor-pointer flex items-center gap-1"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Cancel Booking</span>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: Diagnostic Records */}
      {activeSubTab === 'records' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">Diagnostic Reports & Imaging Tests</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Official laboratory and radiology reports uploaded by WeCare Diagnostic Services.
              </p>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {medicalRecords.map((record) => (
                <div key={record.id} className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded-md">
                        {record.category}
                      </span>
                      <span className="text-xs text-slate-400 dark:text-slate-500">{record.date}</span>
                    </div>
                    <h4 className="font-bold text-slate-900 dark:text-white text-sm">{record.testName}</h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Supervised by {record.doctorName}</p>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 max-w-xl bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl border border-slate-100 dark:border-slate-750">
                      <strong>Summary:</strong> {record.summary}
                    </p>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <span
                      className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                        record.status === 'Normal'
                          ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                          : 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800'
                      }`}
                    >
                      {record.status}
                    </span>
                    <button
                      onClick={() => alert(`Downloading verified PDF report: ${record.testName}`)}
                      className="p-2 text-teal-700 dark:text-teal-400 hover:bg-teal-50 dark:hover:bg-slate-800 rounded-xl transition cursor-pointer"
                      title="Download PDF"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: Active Prescriptions */}
      {activeSubTab === 'prescriptions' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">Active Prescriptions & Medications</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Digital prescriptions approved by WeCare Hospital physicians with dosage instructions.
              </p>
            </div>

            <div className="space-y-6">
              {prescriptions.map((rx) => (
                <div key={rx.id} className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 dark:border-slate-700/80 pb-3">
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">Issued by {rx.doctorName}</h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400">{rx.departmentName} • Date: {rx.date}</p>
                    </div>
                    {rx.refillAvailable && (
                      <span className="self-start sm:self-center px-2.5 py-1 bg-teal-100 dark:bg-teal-950/70 text-teal-800 dark:text-teal-300 text-[10px] font-bold rounded-full border border-teal-200/50 dark:border-teal-800">
                        Refill Eligible at Hospital Pharmacy
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {rx.medications.map((med, i) => (
                      <div key={i} className="bg-white dark:bg-slate-800 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 space-y-1 text-xs">
                        <div className="flex items-center justify-between font-bold text-slate-900 dark:text-white">
                          <span className="flex items-center gap-1.5">
                            <Pill className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                            {med.name}
                          </span>
                          <span className="text-teal-700 dark:text-teal-300">{med.dosage}</span>
                        </div>
                        <p className="text-slate-600 dark:text-slate-300"><strong>Schedule:</strong> {med.frequency} ({med.duration})</p>
                        <p className="text-slate-500 dark:text-slate-400 text-[11px]"><em>{med.instructions}</em></p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: Health Profile & Emergency Contacts */}
      {activeSubTab === 'profile' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <h3 className="font-bold text-slate-900 dark:text-white text-base">Allergies & Medical History</h3>
            
            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-rose-700 dark:text-rose-400 block">
                Known Drug / Environmental Allergies
              </span>
              <div className="flex flex-wrap gap-2">
                {currentProfile.allergies.map((allergy, i) => (
                  <span key={i} className="px-3 py-1 bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-900/60 rounded-lg text-xs font-semibold">
                    {allergy}
                  </span>
                ))}
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block">
                Chronic Health Conditions
              </span>
              <ul className="text-xs text-slate-700 dark:text-slate-300 space-y-1">
                {currentProfile.chronicConditions.map((cond, i) => (
                  <li key={i} className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                    <span>{cond}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <h3 className="font-bold text-slate-900 dark:text-white text-base">Emergency Contact</h3>
            <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2 text-xs">
              <p className="font-bold text-slate-900 dark:text-white text-sm">{currentProfile.emergencyContact.name}</p>
              <p className="text-slate-500 dark:text-slate-400">Relationship: {currentProfile.emergencyContact.relation}</p>
              <p className="text-teal-700 dark:text-teal-400 font-bold flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5" />
                {currentProfile.emergencyContact.phone}
              </p>
            </div>

            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400 space-y-1">
              <p><strong>Primary Hospital:</strong> WeCare Hospital, Akhatwade, Nagardeola (Dist Jalgaon 425001)</p>
              <p><strong>Primary Physician:</strong> Dr. Rajesh Sharma, MD</p>
              <p><strong>Blood Transfusion Consent:</strong> On File (Active)</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
