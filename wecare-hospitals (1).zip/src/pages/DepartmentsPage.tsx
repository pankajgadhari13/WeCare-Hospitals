import React, { useState } from 'react';
import { 
  HeartPulse, 
  Brain, 
  Activity, 
  Baby, 
  ShieldPlus, 
  Ambulance, 
  Sparkles, 
  Cross,
  Clock, 
  MapPin, 
  Users, 
  CheckCircle2, 
  ArrowRight, 
  CalendarCheck,
  Stethoscope,
  ChevronRight,
  ShieldCheck,
  X
} from 'lucide-react';
import { Department, Doctor } from '../types';

interface DepartmentsPageProps {
  departments: Department[];
  doctors: Doctor[];
  onSelectDepartmentForBooking: (deptId: string) => void;
  onSelectDoctorForBooking: (doctor: Doctor) => void;
}

export const DepartmentsPage: React.FC<DepartmentsPageProps> = ({
  departments,
  doctors,
  onSelectDepartmentForBooking,
  onSelectDoctorForBooking,
}) => {
  const [selectedDeptDetail, setSelectedDeptDetail] = useState<Department | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const getDeptIcon = (iconName: string) => {
    switch (iconName) {
      case 'HeartPulse': return <HeartPulse className="w-6 h-6 text-rose-600" />;
      case 'Brain': return <Brain className="w-6 h-6 text-indigo-600" />;
      case 'Activity': return <Activity className="w-6 h-6 text-amber-600" />;
      case 'Baby': return <Baby className="w-6 h-6 text-teal-600" />;
      case 'ShieldPlus': return <ShieldPlus className="w-6 h-6 text-blue-600" />;
      case 'Ambulance': return <Ambulance className="w-6 h-6 text-red-600" />;
      case 'Sparkles': return <Sparkles className="w-6 h-6 text-pink-600" />;
      case 'Cross': return <Cross className="w-6 h-6 text-emerald-600" />;
      default: return <Stethoscope className="w-6 h-6 text-teal-600" />;
    }
  };

  const filteredDepts = departments.filter((dept) => {
    if (activeCategory === 'all') return true;
    if (activeCategory === 'critical') return dept.emergencyAvailable || dept.id === 'emergency' || dept.id === 'cardiology';
    if (activeCategory === 'surgical') return dept.id === 'orthopedics' || dept.id === 'neurology' || dept.id === 'oncology';
    if (activeCategory === 'maternal') return dept.id === 'gynecology' || dept.id === 'pediatrics';
    return true;
  });

  return (
    <div className="space-y-12 pb-16">
      {/* Header Banner */}
      <section className="bg-gradient-to-r from-teal-900 via-slate-900 to-slate-950 text-white py-14 sm:py-16">
        <div className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16">
          <div className="max-w-3xl space-y-3">
            <span className="px-3 py-1 bg-teal-500/20 text-teal-300 border border-teal-400/30 rounded-full text-xs font-semibold uppercase tracking-wider inline-block">
              Clinical Specializations
            </span>
            <h1 className="text-3xl sm:text-5xl font-black tracking-tight">
              Medical Departments & Centres of Excellence
            </h1>
            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              WeCare Hospital features 8 specialized institutes with dedicated wards, intensive care suites, and internationally trained clinical teams. Every department houses multiple senior consultant doctors.
            </p>
          </div>
        </div>
      </section>

      {/* Category Tabs */}
      <section className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16">
        <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-200 scrollbar-none">
          {[
            { id: 'all', label: 'All Departments' },
            { id: 'critical', label: 'Critical & Emergency Care' },
            { id: 'surgical', label: 'Robotic & Surgical Wings' },
            { id: 'maternal', label: 'Women & Child Health' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                activeCategory === cat.id
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </section>

      {/* Departments Grid */}
      <section className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 xl:gap-8">
          {filteredDepts.map((dept) => {
            const deptDoctors = doctors.filter((d) => d.departmentId === dept.id);

            return (
              <div
                key={dept.id}
                className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-lg transition flex flex-col justify-between group"
              >
                {/* Banner Image */}
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={dept.bannerImage}
                    alt={dept.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/30 to-transparent" />
                  
                  <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-xs p-2 rounded-2xl shadow-md">
                    {getDeptIcon(dept.iconName)}
                  </div>

                  {dept.emergencyAvailable && (
                    <div className="absolute top-4 right-4 bg-rose-600 text-white text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider flex items-center gap-1 shadow-xs">
                      <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                      24/7 Service
                    </div>
                  )}

                  <div className="absolute bottom-4 left-4 right-4 text-white">
                    <span className="text-[11px] font-bold text-teal-300 uppercase tracking-wider block">
                      {dept.floor}
                    </span>
                    <h3 className="text-xl font-bold text-white mt-0.5 leading-snug">
                      {dept.name}
                    </h3>
                  </div>
                </div>

                {/* Body Content */}
                <div className="p-6 space-y-4 flex-1 flex flex-col justify-between">
                  <div>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      {dept.shortDescription}
                    </p>

                    {/* Department Head */}
                    <div className="mt-4 bg-slate-50 p-3 rounded-xl border border-slate-100 flex items-center justify-between text-xs">
                      <div>
                        <span className="text-slate-400 block text-[10px] uppercase font-bold">
                          Head of Department
                        </span>
                        <span className="font-bold text-slate-800">{dept.headOfDepartment}</span>
                      </div>
                      <span className="bg-teal-50 text-teal-700 font-bold px-2 py-1 rounded-lg text-xs">
                        {deptDoctors.length} Doctors
                      </span>
                    </div>

                    {/* Key Procedures / Treatments Pills */}
                    <div className="mt-4 space-y-1.5">
                      <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                        Core Treatments:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {(dept.treatments || []).slice(0, 3).map((treatment, idx) => (
                          <span
                            key={idx}
                            className="inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-medium bg-slate-100 text-slate-700"
                          >
                            {treatment}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="pt-4 border-t border-slate-100 flex items-center gap-2">
                    <button
                      onClick={() => setSelectedDeptDetail(dept)}
                      className="flex-1 py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-1"
                    >
                      <span>View Team & Details</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onSelectDepartmentForBooking(dept.id)}
                      className="py-2.5 px-4 bg-teal-600 hover:bg-teal-700 active:scale-95 text-white text-xs font-bold rounded-xl transition shadow-xs cursor-pointer flex items-center gap-1.5"
                    >
                      <CalendarCheck className="w-3.5 h-3.5" />
                      <span>Book Slot</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Department Detail Modal (Showing Multiple Doctors in that department) */}
      {selectedDeptDetail && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="relative h-48 sm:h-60 overflow-hidden">
              <img
                src={selectedDeptDetail.bannerImage}
                alt={selectedDeptDetail.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/40 to-transparent" />
              
              <button
                onClick={() => setSelectedDeptDetail(null)}
                className="absolute top-4 right-4 p-2 rounded-full bg-black/40 hover:bg-black/60 text-white transition cursor-pointer"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="absolute bottom-4 left-6 right-6 text-white">
                <span className="text-xs font-bold uppercase tracking-wider text-teal-300">
                  {selectedDeptDetail.floor} • OPD: {selectedDeptDetail.opdHours}
                </span>
                <h2 className="text-2xl sm:text-3xl font-black mt-1">
                  {selectedDeptDetail.name}
                </h2>
              </div>
            </div>

            <div className="p-6 sm:p-8 space-y-6 max-h-[70vh] overflow-y-auto">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Clinical Overview
                </h4>
                <p className="text-sm text-slate-700 mt-1 leading-relaxed">
                  {selectedDeptDetail.fullDescription}
                </p>
              </div>

              {/* Technology & Diagnostics */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
                  <h5 className="text-xs font-bold uppercase tracking-wider text-teal-800 mb-2">
                    Advanced Diagnostics & Technology
                  </h5>
                  <ul className="text-xs text-slate-600 space-y-1.5">
                    {selectedDeptDetail.equipment.map((eq, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                        <span>{eq}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
                  <h5 className="text-xs font-bold uppercase tracking-wider text-teal-800 mb-2">
                    Key Procedures & Treatments
                  </h5>
                  <ul className="text-xs text-slate-600 space-y-1.5">
                    {selectedDeptDetail.treatments.map((tr, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                        <span>{tr}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Multiple Doctors Section for this Department */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Users className="w-4 h-4 text-teal-600" />
                    <span>Specialist Doctors in this Department ({doctors.filter(d => d.departmentId === selectedDeptDetail.id).length})</span>
                  </h4>
                  <span className="text-xs text-slate-400">Multiple Consultants on OPD Duty</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {doctors
                    .filter((d) => d.departmentId === selectedDeptDetail.id)
                    .map((doctor) => (
                      <div
                        key={doctor.id}
                        className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-3"
                      >
                        <div className="flex items-start gap-3">
                          <img
                            src={doctor.photoUrl}
                            alt={doctor.name}
                            className="w-14 h-14 rounded-xl object-cover border border-slate-100 shrink-0"
                          />
                          <div className="min-w-0">
                            <h5 className="font-bold text-slate-900 text-sm truncate">
                              {doctor.name}
                            </h5>
                            <p className="text-xs text-slate-500 truncate">{doctor.title}</p>
                            <p className="text-[11px] text-teal-700 font-medium mt-0.5">
                              {doctor.qualifications}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-xs bg-slate-50 p-2 rounded-lg">
                          <span className="text-slate-500">OPD Room: <strong>{doctor.opdRoom}</strong></span>
                          <span className="font-bold text-emerald-700">Next: {doctor.nextAvailableSlot}</span>
                        </div>

                        <button
                          onClick={() => {
                            setSelectedDeptDetail(null);
                            onSelectDoctorForBooking(doctor);
                          }}
                          className="w-full py-2 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5"
                        >
                          <CalendarCheck className="w-3.5 h-3.5" />
                          <span>Book with {doctor.name.split(' ')[1]}</span>
                        </button>
                      </div>
                    ))}
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="bg-slate-50 p-4 border-t border-slate-200 flex justify-between items-center">
              <span className="text-xs text-slate-500">
                Emergency: 108 • Campus: Akhatwade near by nagardeola dist jalgaon 425001
              </span>
              <button
                onClick={() => setSelectedDeptDetail(null)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded-xl transition cursor-pointer"
              >
                Close Window
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
