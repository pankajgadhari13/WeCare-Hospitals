import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  Star, 
  MapPin, 
  Clock, 
  Globe, 
  CalendarCheck, 
  GraduationCap, 
  CheckCircle2, 
  X, 
  ChevronRight,
  UserCheck,
  ShieldCheck,
  Sparkles
} from 'lucide-react';
import { Doctor, Department } from '../types';

interface DoctorsPageProps {
  doctors: Doctor[];
  departments: Department[];
  selectedDepartmentId: string;
  onSelectDepartmentFilter: (deptId: string) => void;
  onSelectDoctorForBooking: (doctor: Doctor) => void;
}

export const DoctorsPage: React.FC<DoctorsPageProps> = ({
  doctors,
  departments,
  selectedDepartmentId,
  onSelectDepartmentFilter,
  onSelectDoctorForBooking,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [onlyAvailableToday, setOnlyAvailableToday] = useState(false);
  const [viewingDoctorProfile, setViewingDoctorProfile] = useState<Doctor | null>(null);

  const filteredDoctors = doctors.filter((doc) => {
    const matchesDept = 
      !selectedDepartmentId || 
      selectedDepartmentId === 'all' || 
      doc.departmentId === selectedDepartmentId;

    const matchesSearch = 
      doc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.departmentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.specializations.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase())) ||
      doc.qualifications.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesAvailability = !onlyAvailableToday || doc.isAvailableToday;

    return matchesDept && matchesSearch && matchesAvailability;
  });

  return (
    <div className="space-y-10 pb-16">
      {/* Header Banner */}
      <section className="bg-gradient-to-r from-teal-900 via-slate-900 to-slate-950 text-white py-14 sm:py-16">
        <div className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16">
          <div className="max-w-3xl space-y-3">
            <span className="px-3 py-1 bg-teal-500/20 text-teal-300 border border-teal-400/30 rounded-full text-xs font-semibold uppercase tracking-wider inline-block">
              WeCare Medical Faculty
            </span>
            <h1 className="text-3xl sm:text-5xl font-black tracking-tight">
              Our Expert Doctors & Consultants
            </h1>
            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              Every department at WeCare Hospital is staffed by multiple board-certified specialists, researchers, and surgeons dedicated to precise diagnosis and compassionate therapy.
            </p>
          </div>
        </div>
      </section>

      {/* Filter and Search Bar */}
      <section className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16">
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            {/* Search Input */}
            <div className="md:col-span-6 relative">
              <Search className="w-5 h-5 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="text"
                placeholder="Search by doctor name, specialty (e.g. TAVI, robotic), or condition..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-11 pr-4 py-3 text-sm bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-teal-500 focus:outline-hidden"
              />
            </div>

            {/* Department Dropdown */}
            <div className="md:col-span-4">
              <select
                value={selectedDepartmentId}
                onChange={(e) => onSelectDepartmentFilter(e.target.value)}
                aria-label="Filter by department"
                className="w-full py-3 px-4 text-sm bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-teal-500 focus:outline-hidden text-slate-700"
              >
                <option value="all">All Departments ({doctors.length} Doctors)</option>
                {departments.map((dept) => (
                  <option key={dept.id} value={dept.id}>
                    {dept.name} ({doctors.filter(d => d.departmentId === dept.id).length} Doctors)
                  </option>
                ))}
              </select>
            </div>

            {/* Toggle Available Today */}
            <div className="md:col-span-2 flex items-center">
              <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer select-none bg-slate-50 hover:bg-slate-100 p-3 rounded-2xl border border-slate-200 w-full justify-center">
                <input
                  type="checkbox"
                  checked={onlyAvailableToday}
                  onChange={(e) => setOnlyAvailableToday(e.target.checked)}
                  className="rounded text-teal-600 focus:ring-teal-500 w-4 h-4"
                />
                <span>Available Today</span>
              </label>
            </div>
          </div>

          {/* Quick Department Filter Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none text-xs">
            <span className="text-slate-400 font-medium shrink-0">Quick Filter:</span>
            <button
              onClick={() => onSelectDepartmentFilter('all')}
              className={`px-3 py-1.5 rounded-lg font-medium transition whitespace-nowrap cursor-pointer ${
                !selectedDepartmentId || selectedDepartmentId === 'all'
                  ? 'bg-teal-700 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              All
            </button>
            {departments.map((dept) => (
              <button
                key={dept.id}
                onClick={() => onSelectDepartmentFilter(dept.id)}
                className={`px-3 py-1.5 rounded-lg font-medium transition whitespace-nowrap cursor-pointer ${
                  selectedDepartmentId === dept.id
                    ? 'bg-teal-700 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {dept.name.split('&')[0]}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Doctors Grid */}
      <section className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16">
        <div className="flex items-center justify-between mb-6">
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            Showing <strong className="text-slate-900">{filteredDoctors.length}</strong> specialized physicians
          </p>
          <span className="text-xs text-teal-700 font-semibold bg-teal-50 px-3 py-1 rounded-full border border-teal-200/60">
            Multiple Consultants Per Department
          </span>
        </div>

        {filteredDoctors.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-3">
            <UserCheck className="w-12 h-12 text-slate-300 mx-auto" />
            <h3 className="font-bold text-slate-900 text-lg">No specialists match your search criteria</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Try adjusting your specialty filter or clearing keywords to see our full medical team.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                onSelectDepartmentFilter('all');
                setOnlyAvailableToday(false);
              }}
              className="mt-2 px-4 py-2 bg-teal-600 text-white text-xs font-semibold rounded-xl cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-4 gap-6">
            {filteredDoctors.map((doctor) => {
              const availableSlotsCount = doctor.slots.reduce(
                (acc, s) => acc + (s.isAvailable ? s.totalCapacity - s.bookedCount : 0),
                0
              );

              return (
                <div
                  key={doctor.id}
                  onClick={() => onSelectDoctorForBooking(doctor)}
                  className="bg-white rounded-3xl border border-slate-200 shadow-xs hover:shadow-lg hover:border-teal-500 transition-all flex flex-col justify-between overflow-hidden cursor-pointer group"
                >
                  <div className="p-6 space-y-4">
                    {/* Doctor Top Avatar & Status */}
                    <div className="flex items-start gap-4">
                      <div className="relative shrink-0">
                        <img
                          src={doctor.photoUrl}
                          alt={doctor.name}
                          className="w-20 h-20 rounded-2xl object-cover border-2 border-slate-100 shadow-xs group-hover:scale-105 transition-transform"
                        />
                        <span
                          className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${
                            doctor.isAvailableToday ? 'bg-emerald-500' : 'bg-slate-400'
                          }`}
                          title={doctor.isAvailableToday ? 'On OPD Duty Today' : 'Available Tomorrow'}
                        />
                      </div>

                      <div className="min-w-0 flex-1">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-teal-700 bg-teal-50 px-2 py-0.5 rounded-md inline-block">
                          {doctor.departmentName}
                        </span>
                        <h3 className="font-bold text-slate-900 group-hover:text-teal-700 transition-colors text-base mt-1 truncate">
                          {doctor.name}
                        </h3>
                        <p className="text-xs text-slate-500 truncate">{doctor.title}</p>
                        <p className="text-[11px] text-slate-400 truncate mt-0.5">
                          {doctor.qualifications}
                        </p>
                      </div>
                    </div>

                    {/* Ratings & Experience Row */}
                    <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-100">
                      <div className="flex items-center gap-1.5">
                        <Star className="w-4 h-4 text-amber-500 fill-amber-400" />
                        <span className="font-bold text-slate-800">{doctor.rating}</span>
                        <span className="text-slate-400">({doctor.reviewCount})</span>
                      </div>
                      <span className="text-slate-600 font-medium">
                        {doctor.experienceYears} Years Exp.
                      </span>
                    </div>

                    {/* Specializations */}
                    <div className="space-y-1">
                      <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                        Clinical Focus:
                      </span>
                      <div className="flex flex-wrap gap-1">
                        {(doctor.specializations || []).slice(0, 3).map((spec, i) => (
                          <span
                            key={i}
                            className="text-[11px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md font-medium"
                          >
                            {spec}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Location & Languages */}
                    <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100 text-xs space-y-1.5 text-slate-600">
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-slate-400" />
                          {doctor.opdRoom}
                        </span>
                        <span className="font-bold text-slate-900">₹{doctor.consultationFee}</span>
                      </div>
                      <div className="flex items-center gap-1 text-[11px] text-slate-500">
                        <Globe className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">Languages: {doctor.languages.join(', ')}</span>
                      </div>
                    </div>

                    {/* Live Slot Status Pill */}
                    <div className="flex items-center justify-between text-xs bg-teal-50/60 group-hover:bg-teal-100/80 transition-colors p-2.5 rounded-xl border border-teal-100">
                      <span className="text-teal-900 font-medium">Next Available:</span>
                      <span className="font-bold text-teal-700">{doctor.nextAvailableSlot}</span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="p-6 pt-0 flex items-center gap-2">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setViewingDoctorProfile(doctor);
                      }}
                      className="flex-1 py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition cursor-pointer"
                    >
                      Profile & Bio
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectDoctorForBooking(doctor);
                      }}
                      className="flex-1 py-2.5 px-3 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl transition shadow-xs cursor-pointer flex items-center justify-center gap-1.5 active:scale-95"
                    >
                      <CalendarCheck className="w-3.5 h-3.5" />
                      <span>Select & Book</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Doctor Profile Modal */}
      {viewingDoctorProfile && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-teal-800 to-slate-900 p-6 sm:p-8 text-white flex items-start justify-between">
              <div className="flex items-center gap-4">
                <img
                  src={viewingDoctorProfile.photoUrl}
                  alt={viewingDoctorProfile.name}
                  className="w-20 h-20 rounded-2xl object-cover border-2 border-white/40 shadow-lg"
                />
                <div>
                  <span className="text-xs uppercase font-bold tracking-wider text-teal-300">
                    {viewingDoctorProfile.departmentName}
                  </span>
                  <h3 className="text-xl sm:text-2xl font-black mt-0.5">
                    {viewingDoctorProfile.name}
                  </h3>
                  <p className="text-xs text-slate-300">{viewingDoctorProfile.title}</p>
                  <p className="text-[11px] text-teal-200 mt-1">{viewingDoctorProfile.qualifications}</p>
                </div>
              </div>
              <button
                onClick={() => setViewingDoctorProfile(null)}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition cursor-pointer"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 sm:p-8 space-y-6 max-h-[65vh] overflow-y-auto">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Biography & Clinical Experience
                </h4>
                <p className="text-xs sm:text-sm text-slate-700 mt-2 leading-relaxed">
                  {viewingDoctorProfile.bio}
                </p>
              </div>

              {/* Specializations & Languages */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
                  <h5 className="text-xs font-bold uppercase tracking-wider text-teal-800">
                    Specialized Procedures
                  </h5>
                  <ul className="text-xs text-slate-600 space-y-1">
                    {viewingDoctorProfile.specializations.map((spec, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                        <span>{spec}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                  <div>
                    <h5 className="text-xs font-bold uppercase tracking-wider text-teal-800">
                      OPD Consulting Schedule
                    </h5>
                    <p className="text-xs text-slate-600 mt-1">
                      Days: {viewingDoctorProfile.availableDays.join(', ')}
                    </p>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Clinic: {viewingDoctorProfile.opdRoom}
                    </p>
                  </div>
                  <div>
                    <h5 className="text-xs font-bold uppercase tracking-wider text-teal-800">
                      Spoken Languages
                    </h5>
                    <p className="text-xs text-slate-600 mt-0.5">
                      {viewingDoctorProfile.languages.join(', ')}
                    </p>
                  </div>
                </div>
              </div>

              {/* Real-time slot summary */}
              <div className="bg-teal-50 p-4 rounded-2xl border border-teal-200 flex items-center justify-between">
                <div>
                  <span className="text-xs text-teal-800 font-bold block">Consultation Fee</span>
                  <span className="text-lg font-black text-teal-950">₹{viewingDoctorProfile.consultationFee}</span>
                </div>
                <div className="text-right">
                  <span className="text-xs text-teal-800 block">Next Opening</span>
                  <span className="text-sm font-bold text-emerald-800">{viewingDoctorProfile.nextAvailableSlot}</span>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="bg-slate-50 p-6 border-t border-slate-200 flex items-center justify-between">
              <button
                onClick={() => setViewingDoctorProfile(null)}
                className="px-4 py-2.5 text-slate-600 hover:text-slate-900 text-xs font-bold rounded-xl transition cursor-pointer"
              >
                Back to Doctors List
              </button>
              <button
                onClick={() => {
                  const doc = viewingDoctorProfile;
                  setViewingDoctorProfile(null);
                  onSelectDoctorForBooking(doc);
                }}
                className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl transition shadow-md cursor-pointer flex items-center gap-2"
              >
                <CalendarCheck className="w-4 h-4" />
                <span>Book Appointment Now</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
