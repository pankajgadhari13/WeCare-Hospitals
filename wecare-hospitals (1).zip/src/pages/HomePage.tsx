import React, { useState } from 'react';
import { 
  HeartPulse, 
  CalendarCheck, 
  Search, 
  ArrowRight, 
  ShieldCheck, 
  Clock, 
  PhoneCall, 
  Award, 
  Users, 
  Building2, 
  Stethoscope, 
  Bed, 
  Activity, 
  CheckCircle2, 
  Star,
  ChevronRight,
  Zap,
  MapPin,
  Sparkles,
  ArrowUpRight,
  Shield,
  ThumbsUp,
  Quote,
  Ambulance,
  BadgeCheck
} from 'lucide-react';
import { Department, Doctor } from '../types';
import { HOSPITAL_STATS, DEPARTMENTS, DOCTORS } from '../data/hospitalData';

interface HomePageProps {
  departments?: Department[];
  doctors?: Doctor[];
  setActiveTab: (tab: string) => void;
  onSelectDepartment?: (deptId: string) => void;
  onSelectDoctorForBooking?: (doctor: Doctor) => void;
  onBookDoctor?: (doctor: Doctor) => void;
  openEmergencyModal?: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  departments = DEPARTMENTS,
  doctors = DOCTORS,
  setActiveTab,
  onSelectDepartment,
  onSelectDoctorForBooking,
  onBookDoctor,
  openEmergencyModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDeptFilter, setSelectedDeptFilter] = useState('all');
  const [doctorFilter, setDoctorFilter] = useState<'all' | 'today' | 'top'>('all');
  const [activeStoryIdx, setActiveStoryIdx] = useState(0);

  const handleBookingClick = (doctor: Doctor) => {
    if (onSelectDoctorForBooking) {
      onSelectDoctorForBooking(doctor);
    } else if (onBookDoctor) {
      onBookDoctor(doctor);
    } else {
      setActiveTab('booking');
    }
  };

  const safeDepartments = departments && departments.length > 0 ? departments : DEPARTMENTS;
  const safeDoctors = doctors && doctors.length > 0 ? doctors : DOCTORS;

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setActiveTab('doctors');
  };

  // Filtered departments based on selected tab
  const filteredDepartments = selectedDeptFilter === 'all' 
    ? safeDepartments.slice(0, 4)
    : safeDepartments.filter((d) => d.id === selectedDeptFilter);

  // Filtered doctors
  const filteredDoctors = safeDoctors.filter((doc) => {
    if (doctorFilter === 'today') return doc.availableDays.includes('Today') || doc.nextAvailableSlot.includes('Today');
    if (doctorFilter === 'top') return doc.rating >= 4.8;
    return true;
  }).slice(0, 3);

  // Stats icon mapper
  const getStatIcon = (iconName?: string) => {
    switch (iconName) {
      case 'Bed': return <Bed className="w-5 h-5 text-teal-600" />;
      case 'Stethoscope': return <Stethoscope className="w-5 h-5 text-teal-600" />;
      case 'Building2': return <Building2 className="w-5 h-5 text-teal-600" />;
      case 'Users': return <Users className="w-5 h-5 text-teal-600" />;
      case 'Clock': return <Clock className="w-5 h-5 text-teal-600" />;
      case 'Award': return <Award className="w-5 h-5 text-teal-600" />;
      default: return <Activity className="w-5 h-5 text-teal-600" />;
    }
  };

  const patientStories = [
    {
      id: 1,
      quote: "Dr. Rajesh Sharma and the cardiology cath lab team handled my father's emergency angioplasty with breathtaking speed and care. The digital booking and patient dashboard kept us informed every hour.",
      name: "Ramesh Deshmukh",
      info: "Cardiology Patient Family",
      location: "Jalgaon, MH",
      rating: 5,
      tag: "Emergency Angioplasty"
    },
    {
      id: 2,
      quote: "My robotic knee replacement with Dr. Arvind Patil gave me my life back. I walked without crutches within 3 weeks. The physical rehabilitation wing at WeCare is unmatched.",
      name: "Meena Patil",
      info: "Joint Replacement Patient",
      location: "Bhusawal, MH",
      rating: 5,
      tag: "Robotic Knee Surgery"
    },
    {
      id: 3,
      quote: "The Level-III NICU doctors and nurses took such loving care of our premature daughter. Today she is healthy, laughing, and thriving. We are forever grateful to WeCare Hospital.",
      name: "Farah & Amir Khan",
      info: "Pediatric Parents",
      location: "Dhule, MH",
      rating: 5,
      tag: "Level-III Neonatal Care"
    }
  ];

  return (
    <div className="space-y-16 pb-16 overflow-hidden">
      {/* Hero Section with Ambient Glow & Floating Cards */}
      <section className="relative overflow-hidden bg-gradient-to-b from-teal-50/80 via-white to-slate-50 dark:from-black dark:via-black dark:to-neutral-950 pt-8 sm:pt-14 pb-16 border-b border-slate-200 dark:border-neutral-900 transition-colors duration-200">
        {/* Animated Ambient Glow Spheres */}
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-teal-400/15 dark:bg-teal-500/10 rounded-full blur-3xl pointer-events-none animate-pulse" />
        <div className="absolute top-1/2 -right-24 w-96 h-96 bg-emerald-400/10 dark:bg-emerald-500/5 rounded-full blur-3xl pointer-events-none animate-pulse" />

        <div className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16 relative">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-6">
              {/* Trust Badge with Animated Heartbeat */}
              <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-teal-100/80 dark:bg-teal-950/70 border border-teal-200/90 dark:border-teal-800 text-teal-900 dark:text-teal-300 text-xs font-semibold backdrop-blur-xs shadow-xs transition hover:bg-teal-100 dark:hover:bg-teal-900/80">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-teal-600 dark:bg-teal-400"></span>
                </span>
                <span>Premier Quaternary Care • JCI & NABH Certified</span>
                <svg className="w-10 h-3 text-teal-600 dark:text-teal-400 ml-1 inline-block animate-pulse" viewBox="0 0 100 24" fill="none">
                  <path d="M0 12h20l5-9 7 18 6-13 4 7 5-3h53" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>

              {/* Main Headline */}
              <h1 className="text-3xl sm:text-5xl lg:text-6xl xl:text-7xl font-black text-slate-950 dark:text-white tracking-tight leading-tight">
                Advanced Medicine, <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-600 via-teal-700 to-emerald-600 dark:from-teal-300 dark:via-teal-400 dark:to-emerald-400">
                  Compassionate Care
                </span>
              </h1>

              <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl xl:max-w-3xl">
                Welcome to <strong>WeCare Hospital</strong>. Combining internationally trained specialists, next-generation robotic surgery, 24/7 Level-1 trauma response, and seamless digital outpatient bookings for you and your family.
              </p>

              {/* Quick Search Bar with Interactive Focus */}
              <form 
                onSubmit={handleHeroSearch} 
                className="bg-white dark:bg-neutral-950 p-2.5 rounded-2xl shadow-lg shadow-teal-900/5 dark:shadow-none border border-slate-200 dark:border-neutral-800 flex flex-col sm:flex-row items-center gap-2 max-w-2xl xl:max-w-3xl transition-all duration-300 focus-within:border-teal-500 focus-within:ring-3 focus-within:ring-teal-500/20"
              >
                <div className="relative flex-1 w-full">
                  <Search className="w-5 h-5 text-teal-600 dark:text-teal-400 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    placeholder="Search doctor, medical condition, or clinical specialty..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-11 pr-4 py-3 text-sm text-slate-800 dark:text-white placeholder-slate-400 dark:placeholder-neutral-500 bg-transparent focus:outline-hidden"
                  />
                </div>
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={() => setActiveTab('doctors')}
                    className="w-full sm:w-auto px-6 py-3 bg-teal-600 hover:bg-teal-700 active:scale-95 text-white text-sm font-semibold rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer group"
                  >
                    <span>Find Doctor</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </form>

              {/* Action Buttons & Fast Links */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  onClick={() => setActiveTab('booking')}
                  className="px-6 py-3.5 bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm rounded-xl shadow-md shadow-teal-600/20 transition-all flex items-center gap-2 cursor-pointer active:scale-95 hover:shadow-lg hover:shadow-teal-600/30 hover:-translate-y-0.5"
                >
                  <CalendarCheck className="w-4 h-4" />
                  <span>Book In-Clinic Appointment</span>
                </button>
                <button
                  onClick={() => setActiveTab('availability')}
                  className="px-5 py-3.5 bg-white dark:bg-neutral-900 hover:bg-slate-50 dark:hover:bg-neutral-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-neutral-700 font-semibold text-sm rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer hover:border-teal-300 dark:hover:border-teal-500 hover:-translate-y-0.5"
                >
                  <Activity className="w-4 h-4 text-emerald-600 dark:text-emerald-400 animate-pulse" />
                  <span>Live Slot Availability</span>
                </button>
                <button
                  onClick={openEmergencyModal}
                  className="px-4 py-3.5 bg-white dark:bg-neutral-950 text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 font-semibold text-sm rounded-xl transition-all flex items-center gap-2 cursor-pointer border border-rose-200 dark:border-rose-900/60 hover:border-rose-300 dark:hover:border-rose-700 active:scale-95"
                >
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-600"></span>
                  </span>
                  <PhoneCall className="w-4 h-4 text-rose-600 dark:text-rose-400" />
                  <span>Emergency 24x7</span>
                </button>
              </div>

              {/* Trust Indicators */}
              <div className="grid grid-cols-3 gap-4 pt-4 border-t border-slate-200/80 dark:border-neutral-800 max-w-xl">
                <div className="space-y-0.5">
                  <span className="text-xl sm:text-2xl font-black text-slate-950 dark:text-teal-400 tracking-tight">480+</span>
                  <p className="text-xs text-slate-500 dark:text-neutral-400 font-medium">Critical Beds</p>
                </div>
                <div className="space-y-0.5">
                  <span className="text-xl sm:text-2xl font-black text-slate-950 dark:text-emerald-400 tracking-tight">98.6%</span>
                  <p className="text-xs text-slate-500 dark:text-neutral-400 font-medium">Patient Recovery Rate</p>
                </div>
                <div className="space-y-0.5">
                  <span className="text-xl sm:text-2xl font-black text-slate-950 dark:text-cyan-400 tracking-tight">&lt;6 mins</span>
                  <p className="text-xs text-slate-500 dark:text-neutral-400 font-medium">Trauma Door-to-Doctor</p>
                </div>
              </div>
            </div>

            {/* Right Graphic Banner with Floating Animated Badges */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md lg:max-w-none">
                {/* Main Card with subtle elevation */}
                <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-slate-100 dark:border-neutral-800 bg-white dark:bg-black transition-all duration-300 hover:shadow-teal-900/10">
                  <div className="relative h-80 overflow-hidden group">
                    <img
                      src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&w=900&q=80"
                      alt="WeCare Hospital Facility"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent" />
                    <div className="absolute bottom-4 left-4 right-4 text-white">
                      <span className="text-[11px] font-bold uppercase tracking-wider bg-teal-600/90 backdrop-blur-xs px-2.5 py-1 rounded-md">
                        Main Wing & Multi-Specialty Tower
                      </span>
                    </div>
                  </div>

                  <div className="p-6 space-y-4 bg-white dark:bg-black">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-xs font-bold text-teal-700 dark:text-teal-400 uppercase tracking-wider">
                          Central OPD Clinics
                        </span>
                        <h3 className="text-lg font-bold text-slate-900 dark:text-white">WeCare Medical Tower</h3>
                      </div>
                      <span className="px-2.5 py-1 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 text-xs font-bold rounded-full flex items-center gap-1.5 shadow-2xs border border-transparent dark:border-emerald-800/60">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                        Open Today
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-neutral-300 leading-relaxed">
                      Spanning 600,000 sq.ft of medical excellence, featuring 18 advanced laminar flow operating theatres, dual 3-Tesla MRIs, and hybrid catheterization suites.
                    </p>

                    <div className="bg-slate-50 dark:bg-neutral-950 p-3.5 rounded-xl border border-slate-200 dark:border-neutral-800 flex items-center justify-between text-xs">
                      <div>
                        <span className="text-slate-400 dark:text-neutral-500 block text-[11px]">Today’s Duty Incharge</span>
                        <span className="font-bold text-slate-800 dark:text-white">Dr. Rajesh Sharma, MD</span>
                      </div>
                      <button
                        onClick={() => setActiveTab('doctors')}
                        className="text-teal-700 dark:text-teal-400 font-bold hover:underline flex items-center gap-0.5 cursor-pointer group"
                      >
                        <span>View Staff</span>
                        <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Floating Real-time Slot Badge with Gentle Float Animation */}
                <div className="hidden sm:flex absolute -bottom-6 sm:-left-4 md:-left-6 bg-white dark:bg-neutral-900 rounded-2xl p-4 shadow-xl border border-slate-100 dark:border-neutral-700 items-center gap-3 animate-float transition hover:shadow-2xl">
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-teal-600 to-teal-500 text-white flex items-center justify-center shadow-md shadow-teal-500/20">
                    <Zap className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 dark:text-neutral-400 uppercase font-bold tracking-wider">
                      Real-Time Availability
                    </span>
                    <p className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                      32 Slots Open for Today
                    </p>
                  </div>
                </div>

                {/* Floating Rating Badge with Slow Float Animation */}
                <div className="hidden sm:flex absolute -top-5 sm:-right-4 bg-slate-950 text-white rounded-2xl p-3.5 shadow-xl items-center gap-2.5 animate-float-slow border border-slate-800">
                  <Star className="w-5 h-5 text-amber-400 fill-amber-400 animate-pulse" />
                  <div>
                    <span className="text-xs font-bold block leading-none">4.9 / 5.0</span>
                    <span className="text-[10px] text-slate-400">12,400+ Verified Patient Reviews</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Hospital Stats Ribbon with Micro-Interactions */}
      <section className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16">
        <div className="bg-white dark:bg-black rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-xs p-6 sm:p-8 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 text-center">
          {HOSPITAL_STATS.map((stat, i) => (
            <div 
              key={i} 
              className="p-3 rounded-2xl transition-all duration-300 hover:bg-teal-50/60 dark:hover:bg-neutral-900/60 hover:-translate-y-1 hover:shadow-xs group cursor-default"
            >
              <div className="w-10 h-10 rounded-xl bg-teal-50 dark:bg-neutral-900 text-teal-700 dark:text-teal-400 flex items-center justify-center mx-auto mb-2.5 group-hover:scale-110 group-hover:bg-teal-600 group-hover:text-white transition-all duration-300">
                {getStatIcon(stat.icon)}
              </div>
              <span className="text-2xl sm:text-3xl font-black text-slate-950 dark:text-white block tracking-tight group-hover:text-teal-700 dark:group-hover:text-teal-400 transition-colors">
                {stat.value}
              </span>
              <span className="text-xs font-medium text-slate-500 dark:text-neutral-400 mt-0.5 block">
                {stat.label}
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* 4 Core Pillars Cards with Elevated Hover States */}
      <section className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs hover:border-teal-400 hover:shadow-xl hover:shadow-teal-500/10 hover:-translate-y-2 transition-all duration-300 group flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mb-4 group-hover:bg-rose-600 group-hover:text-white group-hover:rotate-3 transition-all duration-300 shadow-xs">
                <PhoneCall className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-slate-900 text-base mb-1 group-hover:text-rose-600 transition-colors">
                24/7 Emergency Care
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Immediate resuscitation, Level-1 trauma surgical bays, and dedicated pediatric triage teams.
              </p>
            </div>
            <button
              onClick={openEmergencyModal}
              className="mt-5 text-xs font-bold text-rose-600 hover:text-rose-700 flex items-center gap-1.5 cursor-pointer self-start group/btn"
            >
              <span>Emergency Services</span>
              <ChevronRight className="w-3.5 h-3.5 group-hover/btn:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs hover:border-teal-400 hover:shadow-xl hover:shadow-teal-500/10 hover:-translate-y-2 transition-all duration-300 group flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center mb-4 group-hover:bg-teal-600 group-hover:text-white group-hover:rotate-3 transition-all duration-300 shadow-xs">
                <Stethoscope className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-slate-900 text-base mb-1 group-hover:text-teal-700 transition-colors">
                Expert Specialists
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Over 140 internationally trained consultants across cardiology, neurology, oncology, and robotics.
              </p>
            </div>
            <button
              onClick={() => setActiveTab('doctors')}
              className="mt-5 text-xs font-bold text-teal-700 hover:text-teal-800 flex items-center gap-1.5 cursor-pointer self-start group/btn"
            >
              <span>Explore Doctors</span>
              <ChevronRight className="w-3.5 h-3.5 group-hover/btn:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs hover:border-teal-400 hover:shadow-xl hover:shadow-teal-500/10 hover:-translate-y-2 transition-all duration-300 group flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center mb-4 group-hover:bg-teal-600 group-hover:text-white group-hover:rotate-3 transition-all duration-300 shadow-xs">
                <CalendarCheck className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-slate-900 text-base mb-1 group-hover:text-teal-700 transition-colors">
                Instant Online Booking
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Real-time slot tracking with digital confirmation passes and automatic reminder notifications.
              </p>
            </div>
            <button
              onClick={() => setActiveTab('booking')}
              className="mt-5 text-xs font-bold text-teal-700 hover:text-teal-800 flex items-center gap-1.5 cursor-pointer self-start group/btn"
            >
              <span>Book Consultation</span>
              <ChevronRight className="w-3.5 h-3.5 group-hover/btn:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs hover:border-teal-400 hover:shadow-xl hover:shadow-teal-500/10 hover:-translate-y-2 transition-all duration-300 group flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center mb-4 group-hover:bg-teal-600 group-hover:text-white group-hover:rotate-3 transition-all duration-300 shadow-xs">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-slate-900 text-base mb-1 group-hover:text-teal-700 transition-colors">
                Patient Health Portal
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Access your diagnostic lab tests, electronic prescriptions, vitals charts, and appointment history.
              </p>
            </div>
            <button
              onClick={() => setActiveTab('dashboard')}
              className="mt-5 text-xs font-bold text-teal-700 hover:text-teal-800 flex items-center gap-1.5 cursor-pointer self-start group/btn"
            >
              <span>View Records</span>
              <ChevronRight className="w-3.5 h-3.5 group-hover/btn:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      {/* Featured Clinical Departments with Live Filter Tabs */}
      <section className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6">
          <div>
            <span className="text-xs font-bold text-teal-700 uppercase tracking-wider">
              Centers of Excellence
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mt-1">
              Specialized Medical Departments
            </h2>
            <p className="text-sm text-slate-500 mt-1 max-w-2xl">
              Each department features multi-disciplinary teams of veteran doctors, specialized ICUs, and customized diagnostic technologies.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('departments')}
              className="text-sm font-bold text-teal-700 hover:text-teal-800 flex items-center gap-1 shrink-0 cursor-pointer group"
            >
              <span>View All 8 Departments</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>

        {/* Interactive Department Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 mb-6 p-1.5 bg-slate-100/80 rounded-2xl max-w-fit">
          <button
            onClick={() => setSelectedDeptFilter('all')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              selectedDeptFilter === 'all'
                ? 'bg-white text-teal-800 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Departments
          </button>
          {safeDepartments.slice(0, 5).map((d) => (
            <button
              key={d.id}
              onClick={() => setSelectedDeptFilter(d.id)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                selectedDeptFilter === d.id
                  ? 'bg-white text-teal-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {d.name.split('&')[0].trim()}
            </button>
          ))}
        </div>

        {/* Departments Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredDepartments.map((dept) => (
            <div
              key={dept.id}
              className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-xl hover:border-teal-400 hover:-translate-y-2 transition-all duration-300 flex flex-col justify-between group"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={dept.bannerImage}
                  alt={dept.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/30 to-transparent" />
                <div className="absolute bottom-3 left-3 right-3 text-white">
                  <span className="text-[10px] font-bold uppercase tracking-wider bg-teal-600/90 backdrop-blur-xs px-2.5 py-0.5 rounded-md inline-block">
                    {dept.floor}
                  </span>
                  <h3 className="font-bold text-base mt-1 text-white leading-tight">
                    {dept.name}
                  </h3>
                </div>
              </div>

              <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
                <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                  {dept.shortDescription}
                </p>

                <div className="space-y-2 pt-2 border-t border-slate-100 text-xs">
                  <div className="flex justify-between text-slate-500">
                    <span>Doctors in Dept:</span>
                    <span className="font-bold text-slate-800">{dept.totalDoctors} Specialists</span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>OPD Hours:</span>
                    <span className="font-medium text-slate-700">{dept.opdHours}</span>
                  </div>
                </div>

                <div className="pt-2 flex gap-2">
                  <button
                    onClick={() => onSelectDepartment ? onSelectDepartment(dept.id) : setActiveTab('doctors')}
                    className="flex-1 py-2.5 px-3 bg-teal-50 hover:bg-teal-100 text-teal-800 text-xs font-semibold rounded-xl transition cursor-pointer active:scale-95"
                  >
                    View Doctors
                  </button>
                  <button
                    onClick={() => {
                      if (onSelectDepartment) onSelectDepartment(dept.id);
                      setActiveTab('booking');
                    }}
                    className="py-2.5 px-3.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-xl transition cursor-pointer active:scale-95"
                  >
                    Book Slot
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Real-time Availability Teaser Banner with Glowing Pulse */}
      <section className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16">
        <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-slate-800 bg-radial from-slate-900 to-slate-950 p-8 sm:p-12 text-white flex flex-col lg:flex-row items-center justify-between gap-8">
          {/* Ambient Glowing Emerald Ring */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none animate-pulse" />

          <div className="space-y-4 max-w-2xl relative z-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-semibold">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <Activity className="w-3.5 h-3.5" />
              <span>Live Queue & Slot Telemetry</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-black tracking-tight leading-tight">
              Check Real-Time Doctor Availability Before You Arrive
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              WeCare Hospital features live OPD occupancy tracking. See real-time remaining consultation slots, current waiting room times, and reserve confirmed slots in under 60 seconds.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0 relative z-10 w-full sm:w-auto">
            <button
              onClick={() => setActiveTab('availability')}
              className="w-full sm:w-auto px-6 py-3.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-sm rounded-xl transition-all shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 cursor-pointer active:scale-95 hover:-translate-y-0.5"
            >
              <Activity className="w-4 h-4" />
              <span>Launch Live OPD Tracker</span>
            </button>
            <button
              onClick={() => setActiveTab('booking')}
              className="w-full sm:w-auto px-6 py-3.5 bg-white/10 hover:bg-white/20 text-white font-semibold text-sm rounded-xl backdrop-blur-xs transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95 border border-white/10"
            >
              <CalendarCheck className="w-4 h-4" />
              <span>Instant Appointment</span>
            </button>
          </div>
        </div>
      </section>

      {/* Top Doctors Showcase with Interactive Tabs */}
      <section className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6">
          <div>
            <span className="text-xs font-bold text-teal-700 uppercase tracking-wider">
              Clinical Leadership
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mt-1">
              Consult With Senior Medical Specialists
            </h2>
            <p className="text-sm text-slate-500 mt-1 max-w-2xl">
              Board-certified practitioners with decades of clinical acumen, patient-first ethics, and academic research.
            </p>
          </div>

          {/* Doctor Filter Controls */}
          <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setDoctorFilter('all')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                doctorFilter === 'all'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Specialists
            </button>
            <button
              onClick={() => setDoctorFilter('today')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                doctorFilter === 'today'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Available Today
            </button>
            <button
              onClick={() => setDoctorFilter('top')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                doctorFilter === 'top'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Top Rated (★ 4.8+)
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDoctors.map((doctor) => (
            <div
              key={doctor.id}
              onClick={() => handleBookingClick(doctor)}
              className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:shadow-xl hover:border-teal-400 hover:-translate-y-2 transition-all duration-300 flex flex-col justify-between cursor-pointer group"
            >
              <div>
                <div className="flex items-start gap-4">
                  <div className="relative shrink-0">
                    <img
                      src={doctor.photoUrl}
                      alt={doctor.name}
                      className="w-20 h-20 rounded-2xl object-cover border-2 border-slate-100 shadow-xs group-hover:scale-105 group-hover:rotate-1 transition-transform duration-300"
                    />
                    <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-white" title="Active On Duty" />
                  </div>

                  <div className="min-w-0 flex-1">
                    <span className="text-[10px] font-bold text-teal-800 uppercase bg-teal-50 px-2 py-0.5 rounded-md inline-block">
                      {doctor.departmentName.split('&')[0]}
                    </span>
                    <h3 className="font-bold text-slate-900 group-hover:text-teal-700 transition-colors text-base mt-1 truncate">
                      {doctor.name}
                    </h3>
                    <p className="text-xs text-slate-500 truncate">{doctor.qualifications}</p>
                    <div className="flex items-center gap-2 mt-1.5">
                      <span className="text-xs font-bold text-amber-600 flex items-center gap-0.5">
                        <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                        {doctor.rating}
                      </span>
                      <span className="text-xs text-slate-400">({doctor.reviewCount})</span>
                      <span className="text-xs text-slate-300">•</span>
                      <span className="text-xs font-medium text-slate-600">{doctor.experienceYears}y exp</span>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-slate-600 mt-4 line-clamp-2 leading-relaxed">
                  {doctor.bio}
                </p>

                {/* Status indicator with live pulsing dot */}
                <div className="mt-4 bg-slate-50 p-3 rounded-2xl border border-slate-100 flex items-center justify-between text-xs group-hover:bg-teal-50/70 transition-colors">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                    Next Available:
                  </span>
                  <span className="font-bold text-teal-800">{doctor.nextAvailableSlot}</span>
                </div>
              </div>

              <div className="mt-5 pt-3.5 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-slate-400 block">Consultation Fee</span>
                  <span className="text-base font-bold text-slate-900">₹{doctor.consultationFee}</span>
                </div>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleBookingClick(doctor);
                  }}
                  className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 active:scale-95 text-white text-xs font-bold rounded-xl transition-all shadow-xs cursor-pointer flex items-center gap-1.5 group-hover:shadow-md group-hover:shadow-teal-600/20"
                >
                  <CalendarCheck className="w-3.5 h-3.5" />
                  <span>Select & Book</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Patient Testimonials & Trust Stories */}
      <section className="bg-slate-100/60 py-14 border-y border-slate-200 relative overflow-hidden">
        <div className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16 relative">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-bold text-teal-700 uppercase tracking-wider">
              Patient Voices
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mt-1">
              Healing Stories From Our Community
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Over 75,000 inpatients and outpatients cared for across our multi-specialty wings annually.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {patientStories.map((story, idx) => (
              <div 
                key={story.id}
                onClick={() => setActiveStoryIdx(idx)}
                className={`bg-white p-6 rounded-3xl border transition-all duration-300 cursor-pointer flex flex-col justify-between ${
                  activeStoryIdx === idx 
                    ? 'border-teal-500 shadow-xl shadow-teal-500/10 ring-2 ring-teal-500/20 -translate-y-1.5' 
                    : 'border-slate-200 shadow-xs hover:border-slate-300 hover:-translate-y-1'
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex text-amber-400 gap-1 text-sm">
                      {Array.from({ length: story.rating }).map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                      ))}
                    </div>
                    <span className="text-[11px] font-bold text-teal-800 bg-teal-50 px-2 py-0.5 rounded-md">
                      {story.tag}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed italic">
                    "{story.quote}"
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-100 flex items-center gap-3 mt-4">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-teal-700 to-teal-500 text-white font-bold flex items-center justify-center text-xs shadow-xs">
                    {story.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">{story.name}</h4>
                    <p className="text-[10px] text-slate-400">{story.info} • {story.location}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Emergency Assistance Floating Callout Banner */}
      <section className="w-full max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-12 2xl:px-16">
        <div className="bg-gradient-to-r from-rose-900 via-rose-950 to-slate-950 rounded-3xl p-6 sm:p-8 text-white flex flex-col sm:flex-row items-center justify-between gap-6 border border-rose-800/60 shadow-xl relative overflow-hidden">
          <div className="flex items-center gap-4 relative z-10">
            <div className="w-14 h-14 rounded-2xl bg-rose-600/30 text-rose-300 border border-rose-500/40 flex items-center justify-center shrink-0 animate-red-glow">
              <Ambulance className="w-7 h-7 text-rose-300" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-rose-300 uppercase tracking-wider block">
                24/7 Immediate Medical Response
              </span>
              <h3 className="text-lg sm:text-xl font-black text-white tracking-tight mt-0.5">
                Need Emergency Assistance Or Ambulance?
              </h3>
              <p className="text-xs text-rose-200/80 mt-0.5">
                Level-1 Trauma surgical team standing by. Door-to-doctor time under 6 minutes.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0 relative z-10 w-full sm:w-auto">
            <button
              onClick={openEmergencyModal}
              className="w-full sm:w-auto px-6 py-3.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition shadow-lg shadow-rose-600/30 flex items-center justify-center gap-2 cursor-pointer active:scale-95"
            >
              <PhoneCall className="w-4 h-4 animate-bounce" />
              <span>Call Emergency Desk: 108 / 102</span>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
