import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Mail, 
  Phone, 
  User, 
  Eye, 
  EyeOff, 
  ArrowRight, 
  AlertCircle, 
  CheckCircle2, 
  HeartPulse, 
  X,
  KeyRound,
  ChevronLeft
} from 'lucide-react';
import { useAuth, ADMIN_EMAIL } from '../context/AuthContext';
import { auth } from '../lib/firebase';
import { sendPasswordResetEmail } from 'firebase/auth';

interface LoginPageProps {
  initialTab?: 'login' | 'register';
  redirectReason?: string;
  onLoginSuccess: () => void;
  setActiveTab: (tab: string) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  initialTab = 'login',
  redirectReason,
  onLoginSuccess,
  setActiveTab,
}) => {
  const { signInWithEmailOrPhone, signUpWithEmail } = useAuth();

  const [tab, setTab] = useState<'login' | 'register'>(initialTab);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  // Login Form State
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);

  // Registration Form State (age, gender, blood removed per user request)
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [regAgree, setRegAgree] = useState(true);
  const [regError, setRegError] = useState<string | null>(null);

  // Forgot Password State
  const [isForgotPasswordOpen, setIsForgotPasswordOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotSuccess, setForgotSuccess] = useState(false);
  const [forgotError, setForgotError] = useState<string | null>(null);

  // Registration Success Pop-up Modal State
  const [showRegistrationSuccessModal, setShowRegistrationSuccessModal] = useState(false);
  const [registeredEmail, setRegisteredEmail] = useState('');

  // Reset fields when tab changes
  useEffect(() => {
    if (tab === 'login') {
      setLoginPassword('');
      setLoginError(null);
    } else {
      setRegError(null);
    }
  }, [tab]);

  // Handle Login
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    const cleanIdentifier = loginIdentifier.trim();
    if (!cleanIdentifier || !loginPassword) {
      setLoginError('Invalid email/phone or password.');
      return;
    }

    setLoading(true);
    try {
      await signInWithEmailOrPhone(cleanIdentifier, loginPassword);
      if (cleanIdentifier.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
        setActiveTab('admin');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else {
        onLoginSuccess();
      }
    } catch (err: any) {
      setLoginError('Invalid email/phone or password.');
    } finally {
      setLoading(false);
    }
  };

  // Handle Registration
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegError(null);

    const cleanName = regName.trim();
    const cleanEmail = regEmail.trim();
    const cleanPhone = regPhone.trim();

    if (!cleanName) {
      setRegError('Please enter your full legal name.');
      return;
    }
    if (!cleanEmail) {
      setRegError('Please enter a valid email address.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      setRegError('Please enter a valid email address format.');
      return;
    }
    if (regPassword.length < 6) {
      setRegError('Password must be at least 6 characters.');
      return;
    }
    if (regPassword !== regConfirmPassword) {
      setRegError('Passwords do not match. Please re-enter confirm password.');
      return;
    }
    if (!regAgree) {
      setRegError('Please accept the hospital electronic records agreement to register.');
      return;
    }

    setLoading(true);
    try {
      await signUpWithEmail(cleanEmail, regPassword, {
        name: cleanName,
        phone: cleanPhone || '+91 98220 12345',
        age: 30,
        gender: 'other',
        bloodGroup: 'Not specified',
      });

      // Clear password fields
      setRegPassword('');
      setRegConfirmPassword('');
      setRegName('');
      setRegPhone('');
      setRegEmail('');

      // Prepare login fields and show the celebration popup
      setRegisteredEmail(cleanEmail);
      setLoginIdentifier(cleanEmail);
      setLoginPassword('');
      setShowRegistrationSuccessModal(true);
    } catch (err: any) {
      setRegError(err?.message || 'Registration could not be completed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Handle Forgot Password
  const handleForgotPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError(null);
    setForgotSuccess(false);

    const cleanEmail = forgotEmail.trim() || loginIdentifier.trim();
    if (!cleanEmail) {
      setForgotError('Please enter your registered email address.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      setForgotError('Please enter a valid email address.');
      return;
    }

    setForgotLoading(true);
    try {
      await sendPasswordResetEmail(auth, cleanEmail);
      setForgotSuccess(true);
      setForgotError(null);
    } catch (err: any) {
      const code = err?.code || '';
      if (code === 'auth/user-not-found') {
        setForgotError('No patient account found with this email address.');
      } else if (code === 'auth/invalid-email') {
        setForgotError('Please enter a valid email address.');
      } else {
        setForgotError('Unable to send reset email. Please verify your address and try again.');
      }
    } finally {
      setForgotLoading(false);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 overflow-y-auto bg-black/80 dark:bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 transition-all duration-300 animate-in fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          setActiveTab('home');
        }
      }}
    >
      {/* Floating Aesthetic Modal Card */}
      <div className="relative w-full max-w-md bg-white dark:bg-black rounded-3xl shadow-2xl border border-slate-200/90 dark:border-neutral-800 overflow-hidden my-auto animate-in zoom-in-95 duration-200">
        
        {/* Top Close Button */}
        <button
          type="button"
          onClick={() => setActiveTab('home')}
          className="absolute top-4 right-4 z-20 w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 dark:bg-neutral-900 dark:hover:bg-neutral-800 text-slate-500 hover:text-slate-800 dark:text-neutral-400 dark:hover:text-white flex items-center justify-center transition cursor-pointer shadow-xs border border-transparent dark:border-neutral-800"
          title="Close and return to hospital website"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Brand Header */}
        <div className="p-6 sm:p-7 pb-4 text-center border-b border-slate-100 dark:border-neutral-900 bg-white dark:bg-black">
          <div 
            onClick={() => setActiveTab('home')}
            className="inline-flex items-center justify-center gap-2.5 cursor-pointer group mb-2"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-teal-700 to-teal-500 text-white flex items-center justify-center shadow-md shadow-teal-600/20 group-hover:scale-105 transition-transform">
              <HeartPulse className="w-6 h-6" />
            </div>
            <div className="text-left">
              <div className="flex items-center gap-1">
                <span className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">WeCare</span>
                <span className="text-xl font-light tracking-tight text-teal-600 dark:text-teal-400">Hospital</span>
              </div>
              <span className="text-[9px] text-teal-700 dark:text-teal-400 font-bold uppercase tracking-wider block">
                Secure Patient Portal
              </span>
            </div>
          </div>

          <h2 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">
            {isForgotPasswordOpen 
              ? 'Password Recovery' 
              : tab === 'login' 
              ? 'Patient Account Login' 
              : 'New Patient Registration'}
          </h2>
          <p className="mt-1 text-xs text-slate-500 dark:text-neutral-400 max-w-xs mx-auto">
            {isForgotPasswordOpen
              ? 'Enter your registered email to receive a secure recovery link.'
              : redirectReason || (tab === 'login' 
                ? 'Sign in to access your consultations, prescriptions, and reports.' 
                : 'Create your digital healthcare account to book appointments.')}
          </p>
        </div>

        {/* Tab Switcher (Visible when not in Forgot Password mode) */}
        {!isForgotPasswordOpen && (
          <div className="grid grid-cols-2 p-1.5 bg-slate-100/90 dark:bg-black border-b border-slate-200/80 dark:border-neutral-900 text-xs font-semibold">
            <button
              id="login-tab-btn"
              type="button"
              onClick={() => {
                setTab('login');
                setIsForgotPasswordOpen(false);
              }}
              className={`py-2 rounded-xl transition cursor-pointer text-center ${
                tab === 'login'
                  ? 'bg-white dark:bg-neutral-900 text-teal-700 dark:text-teal-400 shadow-xs font-bold border border-transparent dark:border-neutral-800'
                  : 'text-slate-600 dark:text-neutral-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Patient Login
            </button>
            <button
              id="register-tab-btn"
              type="button"
              onClick={() => {
                setTab('register');
                setIsForgotPasswordOpen(false);
              }}
              className={`py-2 rounded-xl transition cursor-pointer text-center ${
                tab === 'register'
                  ? 'bg-white dark:bg-neutral-900 text-teal-700 dark:text-teal-400 shadow-xs font-bold border border-transparent dark:border-neutral-800'
                  : 'text-slate-600 dark:text-neutral-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              New Registration
            </button>
          </div>
        )}

        {/* Form Body Container */}
        <div className="p-6 sm:p-7 pt-5 bg-white dark:bg-black">
          
          {/* ------------------------------------------------------------- */}
          {/* VIEW: FORGOT PASSWORD RECOVERY */}
          {/* ------------------------------------------------------------- */}
          {isForgotPasswordOpen ? (
            <form onSubmit={handleForgotPasswordSubmit} className="space-y-4 animate-in fade-in duration-150">
              <div className="w-12 h-12 rounded-2xl bg-teal-50 dark:bg-neutral-900 text-teal-700 dark:text-teal-400 flex items-center justify-center mx-auto border border-teal-100 dark:border-neutral-800 shadow-xs">
                <KeyRound className="w-6 h-6" />
              </div>

              {forgotSuccess ? (
                <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 space-y-2 text-center animate-in fade-in">
                  <CheckCircle2 className="w-6 h-6 text-emerald-600 dark:text-emerald-400 mx-auto" />
                  <h4 className="font-bold text-sm text-emerald-950 dark:text-white">
                    Reset Link Dispatched!
                  </h4>
                  <p className="text-xs text-emerald-800 dark:text-emerald-300 leading-relaxed">
                    A password reset link has been sent to <strong>{forgotEmail || loginIdentifier}</strong>. Please check your inbox and follow the instructions to set a new password.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setIsForgotPasswordOpen(false);
                      setTab('login');
                      setForgotSuccess(false);
                    }}
                    className="mt-2 px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold transition cursor-pointer"
                  >
                    Return to Login
                  </button>
                </div>
              ) : (
                <>
                  {forgotError && (
                    <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-300 text-xs flex items-center gap-2 animate-in fade-in">
                      <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 dark:text-rose-400" />
                      <span className="font-medium">{forgotError}</span>
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-neutral-300 uppercase tracking-wider mb-1.5">
                      Registered Email Address *
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 dark:text-neutral-500">
                        <Mail className="w-4 h-4" />
                      </div>
                      <input
                        type="email"
                        required
                        value={forgotEmail || (loginIdentifier.includes('@') ? loginIdentifier : '')}
                        onChange={(e) => {
                          setForgotEmail(e.target.value);
                          setForgotError(null);
                        }}
                        placeholder="name@example.com"
                        className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-300 dark:border-neutral-700 rounded-xl text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-neutral-500 font-medium focus:outline-hidden focus:ring-2 focus:ring-teal-500 dark:focus:ring-teal-400 focus:border-teal-500 dark:focus:border-teal-400 caret-teal-500 dark:caret-teal-400 transition"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={forgotLoading}
                    className="w-full py-2.5 px-4 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-sm rounded-xl shadow-xs transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {forgotLoading ? (
                      <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <span>Send Password Reset Link</span>
                    )}
                  </button>

                  <div className="text-center pt-2">
                    <button
                      type="button"
                      onClick={() => setIsForgotPasswordOpen(false)}
                      className="text-xs text-teal-700 dark:text-teal-400 hover:underline font-semibold inline-flex items-center gap-1 cursor-pointer"
                    >
                      <ChevronLeft className="w-3.5 h-3.5" />
                      <span>Back to Patient Login</span>
                    </button>
                  </div>
                </>
              )}
            </form>
          ) : tab === 'login' ? (
            /* ------------------------------------------------------------- */
            /* VIEW: PATIENT LOGIN */
            /* ------------------------------------------------------------- */
            <form onSubmit={handleLoginSubmit} className="space-y-4 animate-in fade-in duration-150">
              {loginError && (
                <div 
                  id="login-error-banner"
                  className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-300 text-xs flex items-center gap-2.5 animate-in fade-in"
                >
                  <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
                  <span className="font-semibold">{loginError}</span>
                </div>
              )}

              {/* Email / Phone Field */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-neutral-300 uppercase tracking-wider mb-1.5">
                  Email or Mobile Number *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 dark:text-neutral-500">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    id="login-identifier-input"
                    type="text"
                    required
                    autoComplete="username"
                    value={loginIdentifier}
                    onChange={(e) => {
                      setLoginIdentifier(e.target.value);
                      setLoginError(null);
                    }}
                    placeholder="Enter email or mobile number"
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-300 dark:border-neutral-700 rounded-xl text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-neutral-500 font-medium focus:outline-hidden focus:ring-2 focus:ring-teal-500 dark:focus:ring-teal-400 focus:border-teal-500 dark:focus:border-teal-400 caret-teal-500 dark:caret-teal-400 transition"
                  />
                </div>
              </div>

              {/* Password Field with live visibility feedback */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold text-slate-700 dark:text-neutral-300 uppercase tracking-wider">
                    Password *
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setIsForgotPasswordOpen(true);
                      setForgotEmail(loginIdentifier.includes('@') ? loginIdentifier : '');
                    }}
                    className="text-xs text-teal-700 dark:text-teal-400 hover:text-teal-800 dark:hover:text-teal-300 font-semibold hover:underline cursor-pointer"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 dark:text-neutral-500">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    id="login-password-input"
                    type={showPassword ? 'text' : 'password'}
                    required
                    autoComplete="current-password"
                    value={loginPassword}
                    onChange={(e) => {
                      setLoginPassword(e.target.value);
                      setLoginError(null);
                    }}
                    placeholder={showPassword ? 'Enter password' : '••••••••••••'}
                    className={`w-full pl-10 pr-10 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-300 dark:border-neutral-700 rounded-xl text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-neutral-500 font-medium focus:outline-hidden focus:ring-2 focus:ring-teal-500 dark:focus:ring-teal-400 focus:border-teal-500 dark:focus:border-teal-400 caret-teal-500 dark:caret-teal-400 transition ${
                      !showPassword && loginPassword ? 'tracking-wider' : 'tracking-normal'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 dark:text-neutral-300 hover:text-teal-600 dark:hover:text-teal-400 transition cursor-pointer p-1"
                    title={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                {/* Password typing feedback indicator */}
                {loginPassword.length > 0 && (
                  <div className="flex items-center justify-between text-[11px] text-teal-700 dark:text-teal-300 mt-1.5 px-2.5 py-1 rounded-lg bg-teal-50 dark:bg-neutral-900 border border-teal-100 dark:border-neutral-800 animate-in fade-in duration-150">
                    <span className="flex items-center gap-1.5 font-semibold">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                      <span>{loginPassword.length} characters typed</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="text-[11px] font-semibold text-teal-700 dark:text-teal-400 hover:underline cursor-pointer"
                    >
                      {showPassword ? 'Hide password' : 'Show password'}
                    </button>
                  </div>
                )}
              </div>

              <button
                id="btn-login-submit"
                type="submit"
                disabled={loading}
                className="w-full py-2.5 px-4 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-sm rounded-xl shadow-xs transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 active:scale-[0.99]"
              >
                {loading ? (
                  <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <span>Sign In to Dashboard</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          ) : (
            /* ------------------------------------------------------------- */
            /* VIEW: NEW REGISTRATION */
            /* ------------------------------------------------------------- */
            <form onSubmit={handleRegisterSubmit} className="space-y-3.5 animate-in fade-in duration-150">
              {regError && (
                <div 
                  id="register-error-banner"
                  className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-300 text-xs flex items-center gap-2.5 animate-in fade-in"
                >
                  <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
                  <span className="font-semibold">{regError}</span>
                </div>
              )}

              {/* Full Name */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-neutral-300 uppercase tracking-wider mb-1">
                  Full Legal Name *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 dark:text-neutral-500">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    id="register-input-name"
                    type="text"
                    required
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder="Full name"
                    className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-300 dark:border-neutral-700 rounded-xl text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-neutral-500 font-medium focus:ring-2 focus:ring-teal-500 dark:focus:ring-teal-400 focus:border-teal-500 dark:focus:border-teal-400 caret-teal-500 dark:caret-teal-400 transition"
                  />
                </div>
              </div>

              {/* Email & Phone Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-neutral-300 uppercase tracking-wider mb-1">
                    Email Address *
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 dark:text-neutral-500">
                      <Mail className="w-4 h-4" />
                    </div>
                    <input
                      id="register-input-email"
                      type="email"
                      required
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="name@example.com"
                      className="w-full pl-9 pr-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-300 dark:border-neutral-700 rounded-xl text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-neutral-500 font-medium focus:ring-2 focus:ring-teal-500 dark:focus:ring-teal-400 focus:border-teal-500 dark:focus:border-teal-400 caret-teal-500 dark:caret-teal-400 transition"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-neutral-300 uppercase tracking-wider mb-1">
                    Phone Number *
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 dark:text-neutral-500">
                      <Phone className="w-4 h-4" />
                    </div>
                    <input
                      id="register-input-phone"
                      type="tel"
                      required
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                      placeholder="+91 98220 12345"
                      className="w-full pl-9 pr-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-300 dark:border-neutral-700 rounded-xl text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-neutral-500 font-medium focus:ring-2 focus:ring-teal-500 dark:focus:ring-teal-400 focus:border-teal-500 dark:focus:border-teal-400 caret-teal-500 dark:caret-teal-400 transition"
                    />
                  </div>
                </div>
              </div>

              {/* Create Password */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-neutral-300 uppercase tracking-wider mb-1">
                  Create Password (min 6 characters) *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 dark:text-neutral-500">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    id="register-input-password"
                    type={showPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder={showPassword ? 'Enter password' : '••••••••••••'}
                    className={`w-full pl-10 pr-10 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-300 dark:border-neutral-700 rounded-xl text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-neutral-500 font-medium focus:ring-2 focus:ring-teal-500 dark:focus:ring-teal-400 focus:border-teal-500 dark:focus:border-teal-400 caret-teal-500 dark:caret-teal-400 transition ${
                      !showPassword && regPassword ? 'tracking-wider' : 'tracking-normal'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 dark:text-neutral-300 hover:text-teal-600 dark:hover:text-teal-400 transition cursor-pointer p-1"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {regPassword.length > 0 && (
                  <div className="flex items-center justify-between text-[11px] text-teal-700 dark:text-teal-300 mt-1 px-2 py-1 rounded-lg bg-teal-50 dark:bg-neutral-900 border border-teal-100 dark:border-neutral-800">
                    <span className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                      <span>{regPassword.length} characters typed</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="text-[11px] font-semibold text-teal-700 dark:text-teal-400 hover:underline cursor-pointer"
                    >
                      {showPassword ? 'Hide password' : 'Show password'}
                    </button>
                  </div>
                )}
              </div>

              {/* Confirm Password */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-neutral-300 uppercase tracking-wider mb-1">
                  Confirm Password *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 dark:text-neutral-500">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    id="register-input-confirm-password"
                    type={showConfirmPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={regConfirmPassword}
                    onChange={(e) => setRegConfirmPassword(e.target.value)}
                    placeholder={showConfirmPassword ? 'Re-enter password' : '••••••••••••'}
                    className={`w-full pl-10 pr-10 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-300 dark:border-neutral-700 rounded-xl text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-neutral-500 font-medium focus:ring-2 focus:ring-teal-500 dark:focus:ring-teal-400 focus:border-teal-500 dark:focus:border-teal-400 caret-teal-500 dark:caret-teal-400 transition ${
                      !showConfirmPassword && regConfirmPassword ? 'tracking-wider' : 'tracking-normal'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 dark:text-neutral-300 hover:text-teal-600 dark:hover:text-teal-400 transition cursor-pointer p-1"
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {regConfirmPassword.length > 0 && regPassword !== regConfirmPassword && (
                  <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-1 font-medium">
                    Passwords do not match
                  </p>
                )}
                {regConfirmPassword.length > 0 && regPassword === regConfirmPassword && (
                  <p className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1 font-medium flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>Passwords match</span>
                  </p>
                )}
              </div>

              {/* Consent Checkbox */}
              <div className="flex items-start gap-2 pt-1">
                <input
                  id="register-consent-checkbox"
                  type="checkbox"
                  checked={regAgree}
                  onChange={(e) => setRegAgree(e.target.checked)}
                  className="mt-0.5 h-4 w-4 rounded border-slate-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-teal-600 focus:ring-teal-500 cursor-pointer"
                />
                <label htmlFor="register-consent-checkbox" className="text-[11px] text-slate-500 dark:text-neutral-400 leading-tight">
                  I agree to the secure storage of my electronic health profile under HIPAA and WeCare Hospital clinical safety protocols.
                </label>
              </div>

              {/* Register Submit Button */}
              <button
                id="btn-register-submit"
                type="submit"
                disabled={loading}
                className="w-full py-2.5 px-4 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-sm rounded-xl shadow-xs transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {loading ? (
                  <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <span>Create Patient Account</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          )}
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* POPUP: REGISTRATION SUCCESS CELEBRATION MODAL */}
      {/* ------------------------------------------------------------- */}
      {showRegistrationSuccessModal && (
        <div className="fixed inset-0 z-60 overflow-y-auto bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative w-full max-w-sm bg-white dark:bg-black rounded-3xl shadow-2xl border border-emerald-200 dark:border-neutral-800 p-6 text-center space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="w-14 h-14 rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 mx-auto flex items-center justify-center shadow-lg shadow-emerald-500/10 border border-transparent dark:border-emerald-800">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-1.5">
              <span className="px-2.5 py-0.5 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 rounded-full text-[11px] font-bold uppercase tracking-wider inline-block">
                Account Created Successfully
              </span>
              <h3 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
                Welcome to WeCare Hospital!
              </h3>
              <p className="text-xs text-slate-600 dark:text-neutral-400 leading-relaxed">
                Your patient account has been successfully created. Please log in with your credentials to access your dashboard.
              </p>
            </div>

            {registeredEmail && (
              <div className="p-2.5 bg-slate-50 dark:bg-neutral-900 rounded-xl border border-slate-200 dark:border-neutral-800 text-xs text-slate-700 dark:text-slate-300 flex items-center justify-center gap-2 font-mono">
                <Mail className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0" />
                <span>{registeredEmail}</span>
              </div>
            )}

            <button
              type="button"
              onClick={() => {
                setShowRegistrationSuccessModal(false);
                setTab('login');
              }}
              className="w-full py-2.5 px-4 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-md shadow-teal-600/20 transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Proceed to Patient Login</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
