import { 
  db, 
  collection, 
  doc, 
  setDoc, 
  getDocs, 
  updateDoc, 
  deleteDoc,
  query, 
  where, 
  onSnapshot,
  addDoc,
  serverTimestamp,
  handleFirestoreError,
  OperationType 
} from '../lib/firebase';
import { Appointment } from '../types';

export const APPOINTMENTS_COLLECTION = 'appointments';

// Utility to clean undefined values before Firestore persistence
function cleanPayload<T extends Record<string, any>>(obj: T): T {
  const result: any = {};
  for (const [key, val] of Object.entries(obj)) {
    if (val !== undefined) {
      result[key] = val;
    }
  }
  return result;
}

// Convert any Firestore document data into standard normalized Appointment
export function normalizeAppointmentDoc(id: string, raw: any): Appointment {
  const patientId = raw.patientId || raw.userId || '';
  const patientEmail = raw.patientEmail || raw.userEmail || '';
  const patientName = raw.patientName || 'Patient';
  const patientPhone = raw.patientPhone || '';
  const doctorId = raw.doctorId || '';
  const doctorName = raw.doctorName || '';
  const specialization = raw.specialization || (raw.specializations && raw.specializations[0]) || '';
  const department = raw.department || raw.departmentName || '';
  const departmentName = raw.departmentName || raw.department || '';
  const appointmentDate = raw.appointmentDate || raw.date || '';
  const appointmentTime = raw.appointmentTime || raw.timeSlot || '';
  const consultationFee = Number(raw.consultationFee || 0);
  const reason = raw.reason || 'General Consultation';
  const status = raw.status || 'pending';
  const adminNote = raw.adminNote || raw.notes || '';
  
  let createdAtStr = '';
  if (raw.createdAt?.toDate && typeof raw.createdAt.toDate === 'function') {
    createdAtStr = raw.createdAt.toDate().toISOString();
  } else if (typeof raw.createdAt === 'string') {
    createdAtStr = raw.createdAt;
  } else {
    createdAtStr = new Date().toISOString();
  }

  return {
    id,
    patientId,
    patientName,
    patientEmail,
    patientPhone,
    doctorId,
    doctorName,
    specialization,
    department,
    appointmentDate,
    appointmentTime,
    consultationFee,
    reason,
    status,
    adminNote,
    createdAt: createdAtStr,

    // Compatibility fields
    userId: patientId,
    userEmail: patientEmail,
    bookingRef: raw.bookingRef || `WCH-${id.slice(-6).toUpperCase()}`,
    doctorTitle: raw.doctorTitle || 'Specialist Consultant',
    doctorPhoto: raw.doctorPhoto || '',
    departmentId: raw.departmentId || '',
    departmentName: departmentName,
    date: appointmentDate,
    timeSlot: appointmentTime,
    period: raw.period || 'morning',
    consultationType: raw.consultationType || 'in-person',
    paymentMode: raw.paymentMode || 'hospital-counter',
    opdRoom: raw.opdRoom || 'OPD Clinic',
    bookedAt: raw.bookedAt || appointmentDate,
    notes: adminNote,
  };
}

/**
 * Creates appointment in Firestore using exact requested addDoc schema:
 * await addDoc(collection(db, "appointments"), {
 *   patientId: user.uid,
 *   patientName: patientName,
 *   patientEmail: user.email,
 *   patientPhone: patientPhone,
 *   doctorId: doctor.id,
 *   doctorName: doctor.name,
 *   specialization: doctor.specialization,
 *   department: doctor.department,
 *   appointmentDate: selectedDate,
 *   appointmentTime: selectedTime,
 *   consultationFee: doctor.consultationFee,
 *   reason: reason,
 *   status: "pending",
 *   adminNote: "",
 *   createdAt: serverTimestamp()
 * });
 */
export async function createAppointmentWithAddDoc(params: {
  user?: { uid: string; email?: string | null } | null;
  patientName: string;
  patientPhone: string;
  doctor: {
    id: string;
    name: string;
    specialization?: string;
    specializations?: string[];
    department?: string;
    departmentName?: string;
    consultationFee: number;
    title?: string;
    photoUrl?: string;
    opdRoom?: string;
  };
  selectedDate: string;
  selectedTime: string;
  reason: string;
  status?: 'pending' | 'confirmed' | 'rescheduled' | 'cancelled' | 'completed';
  adminNote?: string;
  bookingRef?: string;
  period?: 'morning' | 'afternoon' | 'evening';
  consultationType?: 'in-person' | 'video';
  paymentMode?: 'hospital-counter' | 'online-paid';
}): Promise<{ id: string; appointment: Appointment }> {
  const specialization = 
    params.doctor.specialization || 
    (params.doctor.specializations && params.doctor.specializations[0]) || 
    'Consultant Specialist';
  const department = 
    params.doctor.department || 
    params.doctor.departmentName || 
    'General OPD';
  const status = params.status || 'pending';
  const adminNote = params.adminNote ?? '';
  const bookingRef = params.bookingRef || `WCH-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

  const effectiveUserId = params.user?.uid || `patient_${params.patientPhone.replace(/\D/g, '') || Date.now()}`;
  const effectiveEmail = params.user?.email || '';

  try {
    const rawData = cleanPayload({
      patientId: effectiveUserId,
      patientName: params.patientName,
      patientEmail: effectiveEmail,
      patientPhone: params.patientPhone,

      doctorId: params.doctor.id,
      doctorName: params.doctor.name,
      specialization: specialization,
      department: department,

      appointmentDate: params.selectedDate,
      appointmentTime: params.selectedTime,

      consultationFee: Number(params.doctor.consultationFee) || 0,

      reason: params.reason,
      status: status,
      adminNote: adminNote,
      createdAt: serverTimestamp(),

      // Compatibility fields so existing UI components continue working seamlessly
      userId: effectiveUserId,
      userEmail: effectiveEmail,
      bookingRef: bookingRef,
      doctorTitle: params.doctor.title || 'Specialist Consultant',
      doctorPhoto: params.doctor.photoUrl || '',
      departmentId: department.toLowerCase().replace(/[^a-z0-9]/g, '-'),
      departmentName: department,
      date: params.selectedDate,
      timeSlot: params.selectedTime,
      period: params.period || 'morning',
      consultationType: params.consultationType || 'in-person',
      paymentMode: params.paymentMode || 'hospital-counter',
      opdRoom: params.doctor.opdRoom || 'Room 101, Main Wing',
      bookedAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
    });

    const docRef = await addDoc(collection(db, APPOINTMENTS_COLLECTION), rawData);

    const appointment = normalizeAppointmentDoc(docRef.id, {
      ...rawData,
      createdAt: new Date().toISOString(),
    });

    return { id: docRef.id, appointment };
  } catch (error: any) {
    console.error('Error creating appointment with addDoc:', error);
    try {
      handleFirestoreError(error, OperationType.CREATE, `/${APPOINTMENTS_COLLECTION}`);
    } catch {
      throw error;
    }
    throw error;
  }
}

export async function saveAppointmentToFirestore(appointment: Appointment): Promise<void> {
  const aptRef = doc(db, APPOINTMENTS_COLLECTION, appointment.id);
  const data = cleanPayload({
    patientId: appointment.patientId || appointment.userId,
    patientName: appointment.patientName,
    patientEmail: appointment.patientEmail || appointment.userEmail,
    patientPhone: appointment.patientPhone,
    doctorId: appointment.doctorId,
    doctorName: appointment.doctorName,
    specialization: appointment.specialization || (appointment.departmentName ? `${appointment.departmentName} Specialist` : ''),
    department: appointment.department || appointment.departmentName,
    appointmentDate: appointment.appointmentDate || appointment.date,
    appointmentTime: appointment.appointmentTime || appointment.timeSlot,
    consultationFee: appointment.consultationFee,
    reason: appointment.reason,
    status: appointment.status || 'pending',
    adminNote: appointment.adminNote || appointment.notes || '',
    createdAt: appointment.createdAt || new Date().toISOString(),

    // Extra fields
    userId: appointment.userId || appointment.patientId,
    userEmail: appointment.userEmail || appointment.patientEmail,
    bookingRef: appointment.bookingRef,
    doctorTitle: appointment.doctorTitle,
    doctorPhoto: appointment.doctorPhoto,
    departmentId: appointment.departmentId,
    departmentName: appointment.departmentName,
    date: appointment.date || appointment.appointmentDate,
    timeSlot: appointment.timeSlot || appointment.appointmentTime,
    period: appointment.period,
    consultationType: appointment.consultationType,
    paymentMode: appointment.paymentMode,
    opdRoom: appointment.opdRoom,
    bookedAt: appointment.bookedAt,
  });

  try {
    await setDoc(aptRef, data);
  } catch (error: any) {
    console.error('Error saving appointment to Firestore:', error);
    try {
      handleFirestoreError(error, OperationType.CREATE, `/${APPOINTMENTS_COLLECTION}/${appointment.id}`);
    } catch (loggedErr) {
      throw error;
    }
  }
}

export async function fetchUserAppointments(userId: string): Promise<Appointment[]> {
  if (!userId) return [];

  try {
    const q = query(
      collection(db, APPOINTMENTS_COLLECTION),
      where('patientId', '==', userId)
    );
    const querySnapshot = await getDocs(q);
    const appointments: Appointment[] = [];
    querySnapshot.forEach((docSnap) => {
      appointments.push(normalizeAppointmentDoc(docSnap.id, docSnap.data()));
    });

    // Also check legacy documents with userId
    if (appointments.length === 0) {
      const qLegacy = query(
        collection(db, APPOINTMENTS_COLLECTION),
        where('userId', '==', userId)
      );
      const legacySnap = await getDocs(qLegacy);
      legacySnap.forEach((docSnap) => {
        appointments.push(normalizeAppointmentDoc(docSnap.id, docSnap.data()));
      });
    }

    // Sort descending by date
    appointments.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    return appointments;
  } catch (error: any) {
    console.warn('Could not fetch user appointments from Firestore:', error);
    return [];
  }
}

export function subscribeToAppointments(
  userId: string,
  onUpdate: (appointments: Appointment[]) => void,
  onError?: (error: any) => void
): () => void {
  if (!userId) {
    onUpdate([]);
    return () => {};
  }

  let byPatientId: Record<string, Appointment> = {};
  let byUserId: Record<string, Appointment> = {};

  const notify = () => {
    const map = new Map<string, Appointment>();
    Object.values(byPatientId).forEach((apt) => map.set(apt.id, apt));
    Object.values(byUserId).forEach((apt) => map.set(apt.id, apt));
    const merged = Array.from(map.values());
    merged.sort((a, b) => new Date(b.date || b.appointmentDate || b.bookedAt || '').getTime() - new Date(a.date || a.appointmentDate || a.bookedAt || '').getTime());
    onUpdate(merged);
  };

  // Subscribe by patientId (new exact schema)
  const q1 = query(
    collection(db, APPOINTMENTS_COLLECTION),
    where('patientId', '==', userId)
  );

  // Subscribe by userId (compatibility)
  const q2 = query(
    collection(db, APPOINTMENTS_COLLECTION),
    where('userId', '==', userId)
  );

  const unsub1 = onSnapshot(
    q1,
    (querySnapshot) => {
      byPatientId = {};
      querySnapshot.forEach((docSnap) => {
        byPatientId[docSnap.id] = normalizeAppointmentDoc(docSnap.id, docSnap.data());
      });
      notify();
    },
    (error) => {
      console.warn('Firestore snapshot error on patientId appointments:', error);
      if (onError) onError(error);
    }
  );

  const unsub2 = onSnapshot(
    q2,
    (querySnapshot) => {
      byUserId = {};
      querySnapshot.forEach((docSnap) => {
        byUserId[docSnap.id] = normalizeAppointmentDoc(docSnap.id, docSnap.data());
      });
      notify();
    },
    (error) => {
      console.warn('Firestore snapshot error on userId appointments:', error);
      if (onError) onError(error);
    }
  );

  return () => {
    unsub1();
    unsub2();
  };
}

export async function cancelAppointmentInFirestore(appointmentId: string): Promise<void> {
  const aptRef = doc(db, APPOINTMENTS_COLLECTION, appointmentId);
  try {
    await updateDoc(aptRef, {
      status: 'cancelled',
      cancelledAt: new Date().toISOString()
    });
  } catch (error: any) {
    console.error('Error cancelling appointment in Firestore:', error);
    try {
      handleFirestoreError(error, OperationType.UPDATE, `/${APPOINTMENTS_COLLECTION}/${appointmentId}`);
    } catch {
      throw error;
    }
  }
}

export async function rescheduleAppointmentInFirestore(
  appointmentId: string, 
  newDate: string, 
  newTimeSlot: string,
  newPeriod: 'morning' | 'afternoon' | 'evening'
): Promise<void> {
  const aptRef = doc(db, APPOINTMENTS_COLLECTION, appointmentId);
  try {
    await updateDoc(aptRef, {
      appointmentDate: newDate,
      appointmentTime: newTimeSlot,
      date: newDate,
      timeSlot: newTimeSlot,
      period: newPeriod,
      status: 'rescheduled',
      rescheduledAt: new Date().toISOString()
    });
  } catch (error: any) {
    console.error('Error rescheduling appointment in Firestore:', error);
    try {
      handleFirestoreError(error, OperationType.UPDATE, `/${APPOINTMENTS_COLLECTION}/${appointmentId}`);
    } catch {
      throw error;
    }
  }
}

// -------------------------------------------------------------
// ADMIN METHODS: Manage all appointments across the hospital
// -------------------------------------------------------------

export async function fetchAllAppointments(): Promise<Appointment[]> {
  try {
    const q = query(collection(db, APPOINTMENTS_COLLECTION));
    const querySnapshot = await getDocs(q);
    const appointments: Appointment[] = [];
    querySnapshot.forEach((docSnap) => {
      appointments.push(normalizeAppointmentDoc(docSnap.id, docSnap.data()));
    });
    appointments.sort((a, b) => new Date(b.date || b.appointmentDate || b.bookedAt || '').getTime() - new Date(a.date || a.appointmentDate || a.bookedAt || '').getTime());
    return appointments;
  } catch (error: any) {
    console.warn('Could not fetch all appointments from Firestore:', error);
    return [];
  }
}

export function subscribeToAllAppointments(
  onUpdate: (appointments: Appointment[]) => void,
  onError?: (error: any) => void
): () => void {
  const q = query(collection(db, APPOINTMENTS_COLLECTION));

  const unsubscribe = onSnapshot(
    q,
    (querySnapshot) => {
      const appointments: Appointment[] = [];
      querySnapshot.forEach((docSnap) => {
        appointments.push(normalizeAppointmentDoc(docSnap.id, docSnap.data()));
      });
      appointments.sort((a, b) => new Date(b.date || b.appointmentDate || b.bookedAt || '').getTime() - new Date(a.date || a.appointmentDate || a.bookedAt || '').getTime());
      onUpdate(appointments);
    },
    (error) => {
      console.warn('Firestore snapshot error on all appointments:', error);
      if (onError) onError(error);
    }
  );

  return unsubscribe;
}

export async function adminUpdateAppointment(
  appointmentId: string, 
  updates: Partial<Appointment>
): Promise<void> {
  const aptRef = doc(db, APPOINTMENTS_COLLECTION, appointmentId);
  try {
    const cleaned = cleanPayload({
      ...updates,
      adminNote: updates.adminNote || updates.notes,
      updatedAt: new Date().toISOString()
    });
    await updateDoc(aptRef, cleaned);
  } catch (error: any) {
    console.error('Error in adminUpdateAppointment:', error);
    try {
      handleFirestoreError(error, OperationType.UPDATE, `/${APPOINTMENTS_COLLECTION}/${appointmentId}`);
    } catch {
      throw error;
    }
  }
}

export async function deleteAppointmentInFirestore(appointmentId: string): Promise<void> {
  const aptRef = doc(db, APPOINTMENTS_COLLECTION, appointmentId);
  try {
    await deleteDoc(aptRef);
  } catch (error: any) {
    console.error('Error deleting appointment in Firestore:', error);
    try {
      handleFirestoreError(error, OperationType.DELETE, `/${APPOINTMENTS_COLLECTION}/${appointmentId}`);
    } catch {
      throw error;
    }
  }
}

