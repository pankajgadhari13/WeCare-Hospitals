import { 
  db, 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  handleFirestoreError, 
  OperationType 
} from '../lib/firebase';
import { PatientProfile } from '../types';

export const USERS_COLLECTION = 'users';
export const PHONE_INDEX_COLLECTION = 'phone_index';

export async function saveUserProfile(profile: PatientProfile): Promise<void> {
  const userId = profile.uid || profile.id;
  if (!userId) return;

  const userRef = doc(db, USERS_COLLECTION, userId);
  const dataToSave = {
    ...profile,
    uid: userId,
    updatedAt: new Date().toISOString(),
  };

  try {
    await setDoc(userRef, dataToSave, { merge: true });

    // Also index phone number if present for login lookup
    if (profile.phone && profile.email) {
      const cleanPhone = profile.phone.replace(/[^0-9]/g, '');
      if (cleanPhone.length >= 6) {
        const phoneRef = doc(db, PHONE_INDEX_COLLECTION, cleanPhone);
        await setDoc(phoneRef, {
          uid: userId,
          email: profile.email,
          phone: cleanPhone,
          updatedAt: new Date().toISOString(),
        }, { merge: true });
      }
    }
  } catch (error) {
    console.warn('Failed to save profile to Firestore, syncing locally:', error);
    // Non-blocking fallback for offline resilience
  }
}

export async function getUserProfile(userId: string): Promise<PatientProfile | null> {
  if (!userId) return null;
  const userRef = doc(db, USERS_COLLECTION, userId);

  try {
    const docSnap = await getDoc(userRef);
    if (docSnap.exists()) {
      return docSnap.data() as PatientProfile;
    }
    return null;
  } catch (error) {
    console.warn('Could not fetch user profile from Firestore:', error);
    return null;
  }
}

export async function findUserByPhone(phoneStr: string): Promise<PatientProfile | null> {
  if (!phoneStr) return null;
  const cleanPhone = phoneStr.replace(/[^0-9]/g, '');
  if (!cleanPhone || cleanPhone.length < 5) return null;

  try {
    // Direct index lookup by document key (avoids full collection scan and permission errors)
    const phoneRef = doc(db, PHONE_INDEX_COLLECTION, cleanPhone);
    const snap = await getDoc(phoneRef);
    if (snap.exists()) {
      const indexData = snap.data();
      if (indexData?.email) {
        return {
          id: indexData.uid || 'usr-phone',
          uid: indexData.uid,
          name: 'Patient',
          email: indexData.email,
          phone: cleanPhone,
        } as PatientProfile;
      }
    }
    return null;
  } catch (err) {
    console.warn('Error finding user by phone index:', err);
    return null;
  }
}

export async function updateUserVitals(
  userId: string, 
  vitals: PatientProfile['vitals']
): Promise<void> {
  if (!userId) return;
  const userRef = doc(db, USERS_COLLECTION, userId);

  try {
    await updateDoc(userRef, {
      vitals,
      updatedAt: new Date().toISOString()
    });
  } catch (error) {
    console.warn('Could not update vitals in Firestore:', error);
  }
}
