export interface Department {
  id: string;
  name: string;
  slug: string;
  shortDescription: string;
  fullDescription: string;
  iconName: string;
  headOfDepartment: string;
  totalDoctors: number;
  opdHours: string;
  floor: string;
  emergencyAvailable: boolean;
  treatments: string[];
  equipment: string[];
  bannerImage: string;
}

export interface DoctorSlot {
  id: string;
  time: string;
  period: 'morning' | 'afternoon' | 'evening';
  totalCapacity: number;
  bookedCount: number;
  isAvailable: boolean;
}

export interface Doctor {
  id: string;
  name: string;
  title: string;
  departmentId: string;
  departmentName: string;
  qualifications: string;
  experienceYears: number;
  rating: number;
  reviewCount: number;
  photoUrl: string;
  bio: string;
  specializations: string[];
  languages: string[];
  consultationFee: number;
  availableDays: string[];
  opdRoom: string;
  isAvailableToday: boolean;
  nextAvailableSlot: string;
  currentWaitTimeMin: number;
  slots: DoctorSlot[];
}

export interface Appointment {
  id: string;
  patientId?: string;
  patientName: string;
  patientEmail: string;
  patientPhone: string;
  doctorId: string;
  doctorName: string;
  specialization?: string;
  department?: string;
  appointmentDate?: string;
  appointmentTime?: string;
  consultationFee: number;
  reason: string;
  status: 'pending' | 'confirmed' | 'rescheduled' | 'cancelled' | 'completed';
  adminNote?: string;
  createdAt?: string | any;

  // Compatibility fields with existing components
  userId?: string;
  userEmail?: string;
  bookingRef: string;
  doctorTitle?: string;
  doctorPhoto?: string;
  departmentId?: string;
  departmentName?: string;
  patientAge?: number;
  patientGender?: 'male' | 'female' | 'other';
  date: string;
  timeSlot: string;
  period?: 'morning' | 'afternoon' | 'evening';
  consultationType?: 'in-person' | 'video';
  bookedAt?: string;
  paymentMode?: 'hospital-counter' | 'online-paid';
  opdRoom?: string;
  notes?: string;
}

export interface MedicalRecord {
  id: string;
  date: string;
  testName: string;
  category: 'Laboratory' | 'Radiology' | 'Cardiology' | 'Pathology';
  doctorName: string;
  status: 'Normal' | 'Follow-up Recommended' | 'Pending Review';
  fileSize: string;
  summary: string;
}

export interface Prescription {
  id: string;
  date: string;
  doctorName: string;
  departmentName: string;
  medications: {
    name: string;
    dosage: string;
    frequency: string;
    duration: string;
    instructions: string;
  }[];
  refillAvailable: boolean;
}

export interface PatientProfile {
  id: string;
  uid?: string;
  role?: 'patient' | 'admin';
  name: string;
  email: string;
  phone: string;
  age: number;
  gender: string;
  bloodGroup: string;
  emergencyContact: {
    name: string;
    relation: string;
    phone: string;
  };
  vitals: {
    bloodPressure: string;
    heartRate: number;
    oxygenSaturation: number;
    bloodSugar: number;
    weightKg: number;
    lastUpdated: string;
  };
  allergies: string[];
  chronicConditions: string[];
}
